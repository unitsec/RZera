from .monitor import get_monitor_counts
from rongzai.algSvc.base import get_sample_properties
from rongzai.algSvc.neutron import (mask_neutron_data,crop_neutron_data,
                            focus_neutron_data,smooth_neutron_data,
                            strip_peaks_neutron_data,convert_unit_elastic,
                                    calculate_neutron_data,correct_carpenter)
from rongzai.dataSvc import (read_cal,read_mask,save_dataset,load_histogram_data)
from rongzai.utils import (get_all_from_detector,find_group_from_module,generate_x)
import os
import numpy as np
from .timefocus_correction import correct_tof_to_d

'''
跟衍射相关的函数，可以在CSNS文件夹直接调用
get_image:获取2D探测器热图和对应的pixelID，应该放别的地方！！！
time_focusing：截波长，做吸收修正，做mask，做offset，最后focusing
time_focusing_online:直接转d做focus
diffraction_main_workflow：将某个探测器组的所有module做focusing后合并，并且存monitor counts,最后生成一个dataset的nc文件,存到data_save路径
'''

def get_image(dataset,merge_num,pixel_info):
    hist = dataset["histogram"].values
    # module = dataset.attrs.get("name")
    data = hist.sum(axis=1)
    x = pixel_info["xpixels"]
    y = pixel_info["ypixels"]
    # print(f"y_pids={y}")
    IDstart = pixel_info["start"]

    if pixel_info["stepbyrow"] == "y":
        y = int(y / merge_num)
        pixelData = np.arange(IDstart, int(IDstart + x * y))
        # print(f"merge_num={merge_num},newy={y}")
        data = data.reshape((y, x), order="F")
        pixelData = pixelData.reshape((y,x),order="F")
    else:
        x = int(x / merge_num)
        data = data.reshape((y, x), order="C")
        pixelData = np.arange(IDstart, int(IDstart + x * y))
        pixelData = pixelData.reshape((y, x), order="C")
    return data,pixelData


def time_focusing(dataset, runno, config, correction_conf,dvalue):
    ### 只保存time-focussing的数据，不包含monitor
    module = dataset.attrs["name"]
    processed = convert_unit_elastic(dataset, "wavelength")
    processed = crop_neutron_data(processed, config["wave_min"], config["wave_max"])
    try:
        if correction_conf["do_correction"]:
            info = get_sample_properties(correction_conf)
            processed = correct_carpenter(processed, info)
    except:
        pass
    if config.get("mask"):
        mask_file = os.path.join(config["mask_path"], f"{module}_mask.txt")
        processed = mask_neutron_data(processed, read_mask(mask_file)["mask_list"])

    if config["has_cal"]:
        processed = convert_unit_elastic(processed, "tof")
        cal_file = os.path.join(config["cal_path"], f"{module}_offset.cal")
        processed = correct_tof_to_d(
            processed, read_cal(cal_file)
        )
    unit = processed.attrs.get("x_unit")
    if unit != "dspacing":
        processed = convert_unit_elastic(processed, "dspacing")
    # if isSave:
    #     save_path = os.path.join(config["save_path"], runno, f"{runno}_{module}_d.nc")
    #     save_dataset(processed, save_path)
    processed = focus_neutron_data(processed,dvalue)
    return processed


def time_focusing_online(dataset,config):
    ### online不需要crop wavelength
    processed = convert_unit_elastic(dataset, "dspacing")
    if config["is_rebin_d"]:
        module = dataset.attrs["name"]
        group = find_group_from_module(module,config["group_info"],config["bank_info"])
        param = config["d_rebin"][group]
        dvalue = generate_x(param[0], param[1], param[2], "uniform")
    else:
        dvalue = None
    processed = focus_neutron_data(processed,dvalue)
    return processed


# ---------- 主流程 ----------
def diffraction_main_workflow(fns, detector,runno, config, correction_conf, peaks=[],ranges=[],isV=False,isRebin=True):
    ### 最后会保存带有monitor总数的dataset
    group, modules = get_all_from_detector(detector, config["group_info"], config["bank_info"])
    if isRebin:
        param = config["d_rebin"][group]
        dvalue = generate_x(param[0], param[1], param[2], "uniform")
    else:
        dvalue = None
    result = None
    for module in modules:
        txt_path = os.path.join(config['param_path'], f"{module}.txt")
        data = load_histogram_data(
            fns, txt_path, module,
            config['first_flight_distance'], config['T0_offset']
        )
        processed = time_focusing(data, runno, config, correction_conf, dvalue)##是否存单个模块的I-d
        result = calculate_neutron_data('add', result, processed) if result else processed

    if len(peaks):
        result = strip_peaks_neutron_data(result, peaks, ranges)

    if isV:
        smooth_config = config["v_smooth"][group]
        result = smooth_neutron_data(result, smooth_config['npoint'], smooth_config['order'])
        result["error"].values = np.zeros_like(result["error"].values)

    result.attrs["name"] = detector
    name = config["normalization_monitor"]
    txt_path = os.path.join(config['param_path'], name+".txt")
    data_mon = load_histogram_data(
        fns, txt_path, name,
        config['first_flight_distance'], config['T0_offset']
    )
    mc = get_monitor_counts(data_mon, (config["wave_min"],config["wave_max"]))
    result["monitor_counts"] = mc


    fn = f"{config['save_path']}/{runno}/{runno}_{detector}_d.nc"
    save_dataset(result, fn)
    return result