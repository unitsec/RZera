import matplotlib.pyplot as plt

from rongzai.dataSvc import (merge_datasets,load_histogram_data)
from rongzai.algSvc.base.core_unitconvert import *
from rongzai.algSvc.base import fit_multiple_peaks
from rongzai.algSvc.neutron import (plot_line,
                                crop_neutron_data,extract_neutron_data,rebin_neutron_data,focus_neutron_data,
                                    convert_unit_elastic,convert_unit_inelastic,sum_tof)
# from rongzai.algSvc.neutron.unitconvert_nd import UnitConvertNeutronData
from rongzai.utils import (get_all_modules_from_instrument,generate_x,
                           change_point_to_boundary,get_all_from_detector)
# from rongzai.utils.defined_functions import gaussian,asymmetric_gaussian
import os




####### extract tof range from multi Ei for BL05
def get_tof_range_from_Ei_for_detector(ei,l1,l2):
    t_min = energy_to_tof(ei,None,l1,0, "elastic",False)
    emin = 0.5 * ei
    return [t_min, energy_to_tof(float(emin), None,l1, l2,"elastic",False)]


### correction for elastic
# def correct_kikf(dataset,ei):
#     x = dataset["xvalue"].values
#     y = dataset["histogram"].values
#     e = dataset["error"].values
#     ef = ei - x
#     ycorr = y * np.sqrt(ei / ef)
#     ecorr = e * np.sqrt(ei / ef)
#     dataset["histogram"].values = ycorr
#     dataset["error"].values = ecorr
#     return dataset
#### show detector 2D


## show monitor 2D


#### 处理 roi 单晶点衍射谱
def process_single_crystal(dataset,pid_list):
    data = extract_neutron_data(dataset,pid_list)
    data = convert_unit_elastic(data,"dspacing")
    data = focus_neutron_data(data,None)
    return data


# ---------- 主流程 ----------
def inelastic_main_workflow(config,detector,mon_corr_ei = False):
    ### convert raw data into spe with corrected Ei
    if mon_corr_ei:
        ei_list_corr = correct_ei_from_monitors(config,400,False)
    else:
        ei_list_corr = correct_ei_from_detector(config, detector, check=False)

    data_list,data_merge = inelastic_load_data(config,detector)
    result_spe = {}
    # result_sqw = {}
    for i in range(len(ei_list_corr)):
        ei = ei_list_corr[i]
        print("corrected Ei= ",ei)
        ei_name = str(round(ei,1))
        data_spe = calculate_spe(config, data_list, detector, ei)
        result_spe[ei_name] = data_spe
        # data_sqw = calculate_sqw(config,data_spe)
        # result_sqw[ei_name] = data_sqw
    return result_spe

def calculate_spe(config, data_list,detector,ei):
    tof_range = get_tof_range_from_Ei_for_detector(ei,float(config["first_flight_distance"]),
                                               float(config["second_flight_distance"]))
    dErebin = generate_x(-0.5 * ei, 0.99 * ei, 149, mode="uniform")
    data_list_processed = []
    for j in range(len(data_list)):
        data = data_list[j]
        data = crop_neutron_data(data, tof_range[0], tof_range[1])
        data = convert_unit_inelastic(data, ei, "deltaE")
        data = rebin_neutron_data(data, dErebin)
        # data = correct_kikf(data, ei)
        data_list_processed.append(data)
    processed_data = merge_datasets(data_list_processed, detector)
    processed_data["energy"] = ei
    return processed_data

def calculate_sqw(config,dataset):
    q_arr = generate_x(config["q_rebin"][0], config["q_rebin"][1], config["q_rebin"][2])
    q_edge = change_point_to_boundary(q_arr)
    result = []
    ei = dataset["energy"].values
    hist = dataset["histogram"].values
    dE = dataset["xvalue"].values[0]
    two_theta = dataset["positions"].values[:, 4].flatten()/180*np.pi

    for i in range(hist.shape[1]):
        final_sq = np.zeros_like(q_arr)
        weight = np.zeros_like(q_arr)
        value = hist[:, i]
        for j in range(hist.shape[0]):
            q = spe_to_sqw(ei, dE[i], two_theta[j])
            k = np.searchsorted(q_edge, q, side='right') - 1
            if k < 0 or k >= len(q_arr):
                continue
            weight[k] += 1
            final_sq[k] += value[j]
        result.append(np.where(weight != 0, final_sq / weight, 0))
    sqw = np.array(result)
    return sqw, q_arr, dE

def inelastic_monitor_process(dataset,target="energy"):
    data = sum_tof(dataset)
    return convert_unit_elastic(data,target)

#### 导入所有数据
def inelastic_load_data(config,detector="all"):
    if detector[:3] == "mon":
        txt_path = os.path.join(config['param_path'], f"{detector}.txt")
        dataset = load_histogram_data(config["sample_fns"],txt_path, detector,
                                   config['first_flight_distance'], config['T0_offset'])
        # print(detector,dataset)
        return [dataset], dataset
    else:
        if detector == "all":
            modules = get_all_modules_from_instrument(config["group_info"],config["bank_info"])
            merge_name = config["beamline_name"]
        else:
            group_name, modules = get_all_from_detector(detector,config["group_info"],config["bank_info"])
            merge_name = detector
        # print("load data ",modules,merge_name)
        data_list = []
        for module in modules:
            txt_path = os.path.join(config['param_path'], f"{module}.txt")
            data = load_histogram_data(config["sample_fns"], txt_path, module,
                                   config['first_flight_distance'], config['T0_offset'])
            data_list.append(data)

        return data_list, merge_datasets(data_list,merge_name)



def get_detector_2D_BL05(config,dataset_list,tof_range):
    y_total = int(300/config["group_pixel_num"])
    result = np.zeros((y_total,144))
    result_pid = np.zeros((y_total,144))
    sta = 0
    for i in range(len(dataset_list)):
        data = dataset_list[i]
        data = crop_neutron_data(data, tof_range[0], tof_range[1])
        name = data.attrs.get("name",None)
        xnum = int(config["pixel_info"][name]["xpixels"])
        ynum = int(config["pixel_info"][name]["ypixels"]/config["group_pixel_num"])
        IDstart = config["pixel_info"][name]["start"]
        pixelData = np.arange(IDstart,int(IDstart+xnum*ynum))
        hist = data["histogram"].values.sum(axis=1)
        image = hist.reshape((ynum,xnum),order = "F")
        pixelData = pixelData.reshape((ynum, xnum), order="F")
        if name == "module10203":
            y_total = int(120/config["group_pixel_num"])
            result[:y_total,sta:sta+8] = image
            result_pid[:y_total, sta:sta + 8] = pixelData
        elif name == "module10204":
            y_total = int(y_total + 60/config["group_pixel_num"])
            result[y_total:,sta:sta+8] = image
            result_pid[y_total:, sta:sta + 8] = pixelData
            sta = sta + 8
        else:
            result[:,sta:sta+8] = image
            result_pid[:, sta:sta + 8] = pixelData
            sta = sta + 8
    return result, result_pid

def get_monitor_2D_BL05(config,dataset):
    name = dataset.attrs.get("name", None)
    xnum = config["pixel_info"][name]["xpixels"]
    ynum = config["pixel_info"][name]["ypixels"]
    IDstart = config["pixel_info"][name]["start"]
    pixelData = np.arange(IDstart,int(IDstart+xnum*ynum))

    hist = dataset["histogram"].values.sum(axis=1)
    image = hist.reshape((ynum, xnum), order="C")
    return image,pixelData



################ ei 的修正，分为监视器修正和探测器修正两种 ####################
def correct_ei_from_monitors(config,step,check=False):
    ### get tof range
    en_list = config["multi_ei"]
    corr_ei = []
    for k in range(len(en_list)):
        ei = en_list[k]
        tof = []
        l = []
        for monitor in ["monitor02","monitor03"]:
            _,dataset = inelastic_load_data(config,monitor)
            dataset = sum_tof(dataset)
            l1 = dataset["l1"].values
            l2 = dataset["positions"].values[0][3]
            t = energy_to_tof(ei, None, l1, l2, "elastic", True)
            dataset = crop_neutron_data(dataset,t-step,t+step)
            # plot_line(dataset)
            tof.append(_fit_monitor_tof(ei,dataset,check))
            l.append(l2)
        delta_distance = l[1] - l[0]
        delta_tof = tof[1] - tof[0]
        corr_ei.append(tof_to_energy(delta_tof,None,delta_distance,0,"elastic",True))
    return corr_ei

def _fit_monitor_tof(ei,dataset,check):
    l1 = dataset.get("l1")
    l2 = dataset["positions"].values[0][3]
    tof = dataset["xvalue"].values[0]
    hist = dataset["histogram"].values[0]
    hist = hist/hist.max()
    peaks_tof = energy_to_tof(ei,None,l1,l2,"elastic",True)
    peak_pos, fit_peaks, tof_peak,I_peak = fit_multiple_peaks(tof,hist,[peaks_tof],high_width_para=[[0.5,50,50]],
                                                              fit_function="asymmetric_gaussian",goodness_bottom=0.85)
    if check:
        plt.plot(tof_peak[0],I_peak[0],label="raw")
        plt.plot(fit_peaks[0][0],fit_peaks[0][1],label="fit")
        plt.legend()
        plt.show()
    return peak_pos[0]

### 通过探测器修正ei
def correct_ei_from_detector(config,detector,check=False):
    ### get tof range
    en_list = config["multi_ei"]
    data_list, data_merge = inelastic_load_data(config,detector)

    corr_ei = []
    for k in range(len(en_list)):
        ei = en_list[k]
        step = int(ei/2)
        # print("ei: ",ei)
        tof_range = get_tof_range_from_Ei_for_detector(ei, float(config["first_flight_distance"]),
                                                float(config["second_flight_distance"]))
        erebin = generate_x(0,2*ei, 1000,"uniform")

        data = crop_neutron_data(data_merge, tof_range[0], tof_range[1])
        data = convert_unit_elastic(data, "energy")
        data = focus_neutron_data(data, erebin)
        fit_ei = _fit_detecotr_energy(data, ei, step, check)
        corr_ei.append(fit_ei)
    return corr_ei
def _fit_detecotr_energy(dataset,ei,step,check):
    x = dataset["xvalue"].values[0]
    hist = dataset["histogram"].values[0]

    idx1 = np.searchsorted(x,ei-step)
    idx2 = np.searchsorted(x, ei+step)
    hist = hist[idx1:idx2]
    x = x[idx1:idx2]
    hist = hist / hist.max()
    peak_pos, fit_peaks, x_peak,I_peak = fit_multiple_peaks(x,hist,[ei],high_width_para=[[0.5,50,50]],
                                                              fit_function="gaussian",goodness_bottom=0.85)
    if check:
        plt.plot(x_peak[0],I_peak[0],label="raw")
        plt.plot(fit_peaks[0][0],fit_peaks[0][1],label="fit")
        plt.legend()
        plt.show()
    return peak_pos[0]