from rongzai.algSvc.neutron import convert_unit_elastic, focus_neutron_data, crop_neutron_data

def get_monitor_wavelength(dataset, wave_range):
    data = convert_unit_elastic(dataset, "wavelength")
    if len(wave_range) == 2:
        data = crop_neutron_data(data, *wave_range)
    return focus_neutron_data(data,None)

def get_monitor_counts(dataset,wave_range):
    data = get_monitor_wavelength(dataset,wave_range)
    return data["histogram"].values[0].sum()


def normalize_data_by_counts(dataset,conf):
    if conf["norm_by_pc"]:
        scale = (dataset["proton_charge"].values / conf["pc_factor"])
    else:
        scale = dataset["monitor_counts"].values
    dataset["histogram"].values /= scale
    dataset["error"].values /= scale
    return dataset