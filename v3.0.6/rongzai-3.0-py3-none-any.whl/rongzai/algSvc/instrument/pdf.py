import numpy as np
from scipy.integrate import simpson
from rongzai.algSvc.base import (cal_integral_normlization, interpolate, data_expansion,
                                fit_chebyshev,convolve_instr_hermite_parallel,
                                 convolve_box_function,lorch_filter,get_sample_properties)
from rongzai.algSvc.neutron import convert_unit_elastic
from rongzai.utils import merge_all_curves,chebyshev,fockstate
from rongzai.dataSvc import HermiteLoader
import copy,sys
import matplotlib.pyplot as plt

def convert_sq(dataset, q_arr, conf):
    dataset = convert_unit_elastic(dataset,"q")
    x, y, e = dataset["xvalue"].values[0], dataset["histogram"].values[0], dataset["error"].values[0]
    start_idx = np.searchsorted(q_arr, x[0], side='right')
    end_idx = np.searchsorted(q_arr, x[-1], side='left')
    q_arr = q_arr[start_idx:end_idx]
    iq_new, e_new = interpolate(x, y, e, q_arr)
    sample_info = get_sample_properties(conf["sample_correction"])
    v_info = get_sample_properties(conf["v_correction"])
    factor = v_info["v_factor"] / sample_info["atom_num"]
    # bsqa = sample_info["b_sqrd_avg"]
    # basq = sample_info["b_avg_sqrd"]
    # laue = bsqa / basq
    iq_new *= factor
    # sq = iq_new * (1 / basq) - laue + 1
    # norm = cal_integral_normlization(q_arr, sq)
    norm = cal_integral_normlization(q_arr, iq_new)
    sq = iq_new / norm
    err = e_new / norm
    return q_arr, sq, err

def calculate_sq_from_PDF(r, dr, q):
    qiq = np.zeros_like(q)
    for i in range(q.size):
        tmp = dr*np.sin(q[i]*r)
        qiq[i] = simpson(tmp, r, axis=0)
    return qiq

def calculate_PDF_from_sq(q, sq, r,conf):
    qcut = q.max()
    if conf['data_type'].lower() == "s(q)":
        qiq = q * (sq - conf['self_term'])
    elif conf['data_type'].lower() == "i(q)":
        qiq = q * sq
    else:
        qiq = sq
    # 计算 PDF
    integrand = qiq[:, np.newaxis] * np.sin(q[:, np.newaxis] * r)  # 向量化计算
    if conf['lorch']:
        factor = np.sin(np.pi * q / qcut) / (np.pi * q / qcut)
        integrand *= factor[:, np.newaxis]

    dr = (2 / np.pi) * simpson(integrand, q, axis=0)
    # 根据 PDF 类型返回结果
    if conf['PDF_type'] == "G_r":
        return dr
    elif conf['PDF_type'] == "g_r":
        return dr / (4 * np.pi * r * conf['rho0']) + 1
    elif conf['PDF_type'] == "RDF":
        return r * dr + 4 * np.pi * conf['rho0'] * r ** 2
    else:
        raise ValueError("PDF_type must be one of 'G_r', 'g_r', 'RDF'")

def stitch_modules(data_pairs,q,conf):
    cleaned_data_pairs = []
    for (x,y,e) in data_pairs:
        # negative_idxs = np.where(y <= 0)[0]
        # if negative_idxs.size > 0:
        #     last_idx = negative_idxs[-1]
            # if last_idx > len(y) / 4:
            #     raise Exception("error data, please check again")
            # else:
            # x, y, e = x[last_idx + 1:], y[last_idx + 1:], e[last_idx + 1:]
        cleaned_data_pairs.append((x, y, e))
    x,y,e = merge_all_curves(cleaned_data_pairs,conf["overlap"])
    start_idx = np.searchsorted(q, x[0], side='right')
    end_idx = np.searchsorted(q, x[-1], side='left')
    q = q[start_idx:end_idx]
    final_sq, final_e = interpolate(x, y, e, q)
    norm = cal_integral_normlization(q,final_sq)
    return q, final_sq/norm, final_e/norm

class PDF():
    def __init__(self,conf):
        self.conf = conf
        self.save_path =self.conf["save_path"] + "/" + self.conf["sample_run"][0]

    def apply_chebyshev_sq(self,q,sq):
        qiq = (sq - self.conf["self_term"]) * q
        cheby, npuse = chebyshev(q,self.conf['q_rebin']["merge"][1],self.conf["chebyshev"])
        qiq_cheby, background = fit_chebyshev(q,qiq,self.conf['q_rebin']["merge"][0],cheby)
        # print(f"chebyshev order = {npuse} for direct")
        return ( qiq_cheby / q ) + self.conf["self_term"] , background

    ########################################
    ########## for hermite fitting ############
    ########################################

    def _get_data4hermite(self):
        dataLoader = HermiteLoader(self.conf)
        return dataLoader.load_data_files(self.save_path)

    def _setup_hermite(self):
        self.rmax = self.conf["r_rebin"][1]
        self.nh = self._get_nhermites()
        self.qp = np.sqrt(self.conf["q_rebin"]["merge"][1] / self.rmax)
        self.dr = (self.rmax - self.conf["r_rebin"][0]) / self.conf["r_rebin"][2]
        print(f"after setup for hermite: nh = {self.nh}")

    def _apply_chebyshev_hermite(self,data_hermite):
        y_fit = {}
        for i in range(len(data_hermite["group_order"])):
            group_name = data_hermite["group_order"][i]
            cheby, npuse = chebyshev(data_hermite["q"][group_name],
                                           self.conf['q_rebin']["merge"][1],
                                           self.conf['chebyshev'])
            data_hermite["qiq"][group_name], y_fit[group_name] = fit_chebyshev(
                                            data_hermite["q"][group_name],
                                            data_hermite["qiq"][group_name],
                                            self.conf['q_rebin']["merge"][0], cheby)
            # print(data_hermite["qiq"][group_name].shape, y_fit[group_name].shape)
            print(f"chebyshev order = {npuse} for {group_name}")
        return data_hermite, y_fit

    def _expand2zero(self,data_hermite):
        group_name = data_hermite["group_order"][0]
        new_q,new_qiq = data_expansion(data_hermite["q"][group_name],data_hermite["qiq"][group_name])
        data_hermite["q"][group_name] = new_q
        data_hermite["qiq"][group_name] = new_qiq
        return data_hermite

    def _check_chebyshev(self,data,data_ori,backgroup):
        for i in range(len(data_ori["group_order"])):
            plt.figure()
            group_name = data_ori["group_order"][i]
            plt.plot(data_ori["q"][group_name],
                     data_ori["qiq"][group_name]/data_ori["q"][group_name],
                     label=f"original data")
            plt.plot(data["q"][group_name],
                     data["qiq"][group_name]/data["q"][group_name],
                     label=f"chebyshev fitting data")
            plt.plot(data["q"][group_name], backgroup[group_name], '--', label="cheby curve")
            plt.legend()
            plt.xlabel("Q")
            plt.ylabel("Qi(Q)")
            plt.title(f"{group_name}")
        plt.show()
        # while True:
        #     user_input = input("拟合结果是否满意？(输入 'yes' 继续，输入 'no' 重新拟合): ").strip().lower()
        #     if user_input == 'yes':
        #         return True  # 继续程序
        #     elif user_input == 'no':
        #         return False  # 重新拟合
        #     else:
        #         print("输入无效，请输入 'yes' 或 'no'。")

    def _check_qiq(self,reconstr_data,data_hermite):
        for i in range(len(data_hermite["group_order"])):
            plt.figure()
            group_name = data_hermite["group_order"][i]
            plt.plot(data_hermite["q"][group_name],
                     data_hermite["qiq"][group_name],
                     label=f"qiq data after preprocess")
            plt.plot(reconstr_data["q"][group_name],
                     reconstr_data["qiq"][group_name],
                     label=f"reconstruct qiq data by hermite")
            plt.legend()
            plt.xlabel("Q")
            plt.ylabel("Qi(Q)")
            plt.title(f"{group_name}")
        plt.show()
        # while True:
        #     user_input = input("拟合结果是否满意？(输入 'yes' 继续，输入 'no' 重新拟合): ").strip().lower()
        #     if user_input == 'yes':
        #         return True  # 继续程序
        #     elif user_input == 'no':
        #         return False  # 重新拟合
        #     else:
        #         print("输入无效，请输入 'yes' 或 'no'。")


    def _get_nhermites(self):
        if self.conf["nhermites"] == 'default':
            nh = int(np.round(self.rmax * self.conf['q_rebin']["merge"][1] / 4))
        else:
            nh = int(self.conf['nhermites'])
            self.rmax = np.round(4 * nh / self.conf['q_rebin']["merge"][1])
            print(f"new rmax = {self.rmax}")
        return nh

    def _apply_box_function(self,data_hermite):
        for i in range(len(data_hermite["group_order"])):
            group_name = data_hermite["group_order"][i]
            data_hermite["qiq"][group_name] = convolve_box_function(self.rmax, data_hermite["q"][group_name],
                                                              data_hermite["qiq"][group_name])
        return data_hermite

    def _apply_lorch(self,data_hermite):
        for i in range(len(data_hermite["group_order"])):
            group_name = data_hermite["group_order"][i]
            data_hermite["qiq"][group_name] = lorch_filter(data_hermite["q"][group_name],
                                                             self.conf["q_rebin"]["merge"][1],
                                                             data_hermite["qiq"][group_name])
        return data_hermite


    def _create_hermite_qiq(self,data_hermite):
        hermite_matrix_qiq = {}
        for i in range(len(data_hermite["group_order"])):
            group_name = data_hermite["group_order"][i]
            q = data_hermite["q"][group_name]
            new_xh = np.zeros((len(q),self.nh))
            x = q / self.qp
            for ih in range(1, self.nh + 1):
                k = 2 * ih - 1
                new_xh[:, ih - 1] = fockstate(k, x)
            hermite_matrix_qiq[group_name] = new_xh
        return hermite_matrix_qiq

    def _apply_instr_hermite(self,hermite_matrix,data_hermite):
        for i in range(len(data_hermite["group_order"])):
            group_name = data_hermite["group_order"][i]
            hermite_matrix[group_name] = convolve_instr_hermite_parallel(
                                                    self.conf["resolution_information"][group_name]["a"],
                                                    self.conf["resolution_information"][group_name]["c"],
                                                    hermite_matrix[group_name], self.nh, data_hermite["q"][group_name])
        return hermite_matrix

    def _apply_hermite_fit(self,hermite_matrix,data_hermite):
        qiq_val = []
        h_val = []
        for i in range(len(data_hermite["group_order"])):
            group_name = data_hermite["group_order"][i]
            qiq_val.append(data_hermite["qiq"][group_name])
            h_val.append(hermite_matrix[group_name])
        merge_qiq = np.concatenate(qiq_val, axis=0)
        merge_hermite = np.concatenate(h_val, axis=0)
        coef = np.linalg.lstsq(merge_hermite, merge_qiq, rcond=None)[0]
        if np.any(np.isnan(coef)):
            print("can't fit, there is nan, please check your data")
            sys.exit()
        else:
            return coef

    def _reconstruct_qiq(self, coef, hermite_matrix,data_hermite):
        fit_qiq = copy.deepcopy(data_hermite)
        for i in range(len(fit_qiq["group_order"])):
            group_name = fit_qiq["group_order"][i]
            fit_qiq["qiq"][group_name] = hermite_matrix[group_name] @ coef
        return fit_qiq

    def _reconstruct_pdf(self,coef):
        xxx = np.arange(self.dr, self.conf["q_rebin"]["merge"][1], self.dr) / self.qp
        hermite_matrix_dr = np.zeros((len(xxx), self.nh))
        for ih in range(self.nh):
            k = 2 * ih + 1
            hermite_matrix_dr[:, ih] = fockstate(k, xxx)
        data = np.zeros_like(xxx)
        for ih in range(self.nh):
            data += (-1)**ih * coef[ih] * hermite_matrix_dr[:, ih]
        data *= self.qp * np.sqrt(2/np.pi)
        # if self.conf["lorch"]:
        #     data = lorch_filter(xxx/self.qp,self.conf["r_rebin"][1],data)
        return xxx / self.qp, data


    def preprocess_qiq(self):
        self._setup_hermite()
        data_hermite = self._get_data4hermite()
        data_original = copy.deepcopy(data_hermite)
        ## 是否做切比雪芙拟合
        if self.conf["pre_fitting"]:
            print("start chebysev")
            data_hermite, background = self._apply_chebyshev_hermite(data_hermite)
            # self._check_chebyshev(data_hermite,data_original,background)

        ## 最小bank的q扩展到0
        print("start expand to zero")
        data_hermite = self._expand2zero(data_hermite)
        ## 是否晶体，做卷积
        if self.conf["convolution"]:
            print("start convolve box function")
            data_hermite = self._apply_box_function(data_hermite)
        ## 是否做 lorch 过滤
        if self.conf["lorch"]:
            print("start lorch")
            data_hermite = self._apply_lorch(data_hermite)
        return data_hermite,data_original


    def preprocess_hermite(self,data_hermite):
        print("create hermite")
        hermite_matrix_qiq = self._create_hermite_qiq(data_hermite)
        hermite_matrix_qiq_original = copy.deepcopy(hermite_matrix_qiq)
        ## 是否卷积仪器参数
        if self.conf["fit_with_instrument_resolution"]:
            print("convolve instr res for hermite")
            hermite_matrix_qiq = self._apply_instr_hermite(hermite_matrix_qiq,data_hermite)
        return hermite_matrix_qiq, hermite_matrix_qiq_original


    def hermite_fitting(self):
        data_hermite, data_ori = self.preprocess_qiq()
        print("finish qiq")
        hermite_qiq, hermite_qiq_ori = self.preprocess_hermite(data_hermite)
        print("finish hermite")
        coef = self._apply_hermite_fit(hermite_qiq, data_hermite)
        # reconstruct_qiq = self._reconstruct_qiq(coef, hermite_qiq, data_hermite)
        # self._check_qiq(reconstruct_qiq,data_hermite)
        r, dr = self._reconstruct_pdf(coef)
        return r, dr







