import glob,h5py
import numpy as np
import traceback
from rongzai.utils import (check_dir,find_group_from_module,generate_x)
from rongzai.dataSvc import load_event_data,save_dataset
from .diffraction import time_focusing
from .monitor import get_monitor_counts,get_monitor_wavelength
from abc import ABC, abstractmethod

##### 从配置文件读取需要切割的时间信息 #######
def _get_start_pulseID_from_pc(config):
    flist = glob.glob(config["data_path"] + "/" + config["sample_run"][0] + "/pc*.nxs")
    pc_fn = flist[0]
    with h5py.File(pc_fn, "r") as hf:
        try:
            return hf["/csns/logs/proton_charge/pulse_time"][0]
        except:
            return hf["/csns/logs/pulse_time"][0]

def generate_slice_pulseID_list(config):
    result = []
    t0 = config["slice_part"]['start_pulseID']
    if t0 == 0:
        t0 = _get_start_pulseID_from_pc(config)
        # print(f"find t0 from pc: {t0}")
    slice_info = config["slice_part"]["slice_info"]
    for start, end, num in slice_info:
        pulse_start = t0 + start * 60 * 25
        step = (end - start) / num
        for _ in range(num):
            pulse_end = pulse_start + step * 60 * 25
            result.append([pulse_start, pulse_end])
            pulse_start = pulse_end
    return result

##### buffer 各种处理 ###########
def _update_buffer(buffer, f, module):
    """更新缓冲区"""
    buffer['event_pulse_time'] = np.concatenate(
        (buffer['event_pulse_time'], f[f'/csns/instrument/{module}/event_pulse_time'][:]))
    buffer['event_pixel_id'] = np.concatenate(
        (buffer['event_pixel_id'], f[f'/csns/instrument/{module}/event_pixel_id'][:]))
    buffer['event_time_of_flight'] = np.concatenate(
        (buffer['event_time_of_flight'], f[f'/csns/instrument/{module}/event_time_of_flight'][:]))
    return buffer

def _reset_buffer():
    """重置缓冲区"""
    return {
        'event_pulse_time': np.array([]),
        'event_pixel_id': np.array([]),
        'event_time_of_flight': np.array([])
    }

def _trim_buffer(buffer, end_idx):
    """修剪缓冲区"""
    return {
        'event_pulse_time': buffer['event_pulse_time'][end_idx:],
        'event_pixel_id': buffer['event_pixel_id'][end_idx:],
        'event_time_of_flight': buffer['event_time_of_flight'][end_idx:]
    }

####### 做slice过程，切割pc和切割event ######
def get_slice_pc(config,pulse_time_ranges):
    flist = glob.glob(config["data_path"] + "/" + config["sample_run"][0] + "/pc*.nxs")
    pc_fn = flist[0]
    pc_data = np.ones(len(pulse_time_ranges))
    with h5py.File(pc_fn, "r") as hf:
        try:
            pulse = hf["/csns/logs/proton_charge/pulse_time"]
            pc = hf["/csns/logs/proton_charge/value"]
        except:
            pulse = hf["/csns/logs/pulse_time"]
            pc = hf["/csns/logs/proton_charge"]

        for i in range(len(pulse_time_ranges)):
            t1, t2 = pulse_time_ranges[i]
            idx1 = np.searchsorted(pulse, t1, side='left')
            idx2 = np.searchsorted(pulse, t2, side='right')
            tmp = pc[idx1:idx2]
            pc_data[i] = tmp.sum()
        return pc_data

def get_slice_module(module,config,pulse_time_ranges,save_chunk):
    data_path = config["data_path"] + "/" + config["sample_run"][0]
    check_dir(data_path + "/tmp/" + module)
    try:
        chunk_counter = 0
        buffer = _reset_buffer()
        for i in range(config["slice_part"]['evt_file_num']):

            if chunk_counter > len(pulse_time_ranges) - 1:
                break

            evt_file = data_path + "/" + module + "_evt_" + str(i) + ".nxs"
            with h5py.File(evt_file, "r") as f:
                buffer = _update_buffer(buffer,f,module)
                while chunk_counter <= len(pulse_time_ranges) - 1:
                    start_time, end_time = pulse_time_ranges[chunk_counter]
                    start_idx = np.searchsorted(buffer["event_pulse_time"], start_time, side="left")
                    if start_idx == len(buffer['event_pulse_time']):
                        print("start_time > buffer max, jump to next file")
                        buffer = _reset_buffer()
                        break
                    end_idx = np.searchsorted(buffer["event_pulse_time"], end_time, side="right")
                    if end_idx == 0 or end_idx == start_idx:
                        print("end_idx < buffer min, go to next pulse_time_range")
                        save_chunk(_reset_buffer(), chunk_counter, module,config)
                        chunk_counter += 1
                        continue
                    if end_idx == len(buffer['event_pulse_time']):
                        print("end_time > buffer max, jump to next file")
                        break
                    if start_idx < end_idx:
                        num = len(buffer['event_pulse_time'][start_idx:end_idx])
                        print(f"save chunk for {chunk_counter},nc = {num},start = {start_idx}, end = {end_idx}")
                        save_chunk({'event_pulse_time': buffer['event_pulse_time'][start_idx:end_idx],
                                         'event_pixel_id': buffer['event_pixel_id'][start_idx:end_idx],
                                         'event_time_of_flight': buffer['event_time_of_flight'][start_idx:end_idx]},
                                        chunk_counter, module,config)
                        buffer = _trim_buffer(buffer,end_idx)
                        num = len(buffer['event_pulse_time'])
                        print(f"after save chunk for {chunk_counter}, left nc = {num}")
                        chunk_counter += 1
        if len(buffer['event_pulse_time']) > 0 and chunk_counter < len(pulse_time_ranges):
            print(f"最后一组数据不足 {pulse_time_ranges[chunk_counter]} 个。最后一组数据是 {len(buffer['event_pulse_time'])} 个")
            save_chunk(buffer, chunk_counter, module,config)
            chunk_counter += 1
        while chunk_counter < len(pulse_time_ranges):
            print(f"save empty chunk for {chunk_counter}")
            save_chunk(_reset_buffer(), chunk_counter, module,config)
            chunk_counter += 1
    except:
        traceback.print_exc()

#### 各种处理chunk数据的方法 ####
def save_chunk_for_diffraction(data_dict,counter,module,config):
    group = find_group_from_module(module,config["group_info"], config["bank_info"])
    param = config["d_rebin"][group]
    dvalue = generate_x(param[0], param[1], param[2], "uniform")

    txt_file_path = config["param_path"] + "/" + module + ".txt"
    data = load_event_data(data_dict["event_pixel_id"], data_dict["event_time_of_flight"],
                    config["slice_part"]["tof_step"], 1, txt_file_path, module, config["first_flight_distance"],
                    config["T0_offset"])

    result = time_focusing(data, config["sample_run"][0], config, config["sample_correction"], dvalue, False)  ##是否存单个模块的I-d
    data_path = config["data_path"] + "/" + config["sample_run"][0]
    fn = data_path + "/tmp/" + module + "/" + str(counter) + ".nc"
    save_dataset(result, fn)
    print("save, ",fn)
    # return result

def save_chunk_for_monitor(data_dict,counter,monitor,config):
    ### 存 I- wave
    txt_file_path = config["param_path"] + "/" +  monitor + ".txt"
    data = load_event_data(data_dict["event_pixel_id"], data_dict["event_time_of_flight"],
                    config["slice_part"]["tof_step"], 1, txt_file_path, monitor, config["first_flight_distance"],
                    config["T0_offset"])
    result = get_monitor_wavelength(data,[config["wave_min"],config["wave_max"]])
    data_path = config["data_path"] + "/" + config["sample_run"][0]
    fn = data_path + "/tmp/" + monitor + "/" + str(counter) + ".nc"
    save_dataset(result, fn)
    # return result


# class TimeSliceProcessorBase(ABC):
#     def setup_timeslice(self):
#         self.data_path = os.path.join(self.conf["data_path"], self.conf["sam_run"][0])
#         self.pulse_time_ranges = self.__generate_slice_pulseID_list()
#         self.tot_num = len(self.pulse_time_ranges)
#         self.slice_data = {}
#         check_dir(os.path.join(self.data_path, "tmp"))

    # def __generate_slice_pulseID_list(self):
    #     result = []
    #     t0 = self.conf["slice_part"]['start_pulseID']
    #     if t0 == 0:
    #         t0 = self.__get_start_pulseID_from_pc()
    #         print(f"find t0 from pc: {t0}")
    #     slice_info = self.conf["slice_part"]["slice_info"]
    #     for start, end, num in slice_info:
    #         pulse_start = t0 + start * 60 * 25
    #         step = (end - start) / num
    #         for _ in range(num):
    #             pulse_end = pulse_start + step * 60 * 25
    #             result.append([pulse_start, pulse_end])
    #             pulse_start = pulse_end
    #     return result
    #
    # def __get_start_pulseID_from_pc(self):
    #     flist = glob.glob(self.data_path + "/pc*.nxs")
    #     pc_fn = flist[0]
    #     with h5py.File(pc_fn, "r") as hf:
    #         try:
    #             return hf["/csns/logs/proton_charge/pulse_time"][0]
    #         except:
    #             return hf["/csns/logs/pulse_time"][0]


    # def get_slice_module(self, module):
    #     check_dir(self.data_path + "/tmp/" + module)
    #     try:
    #         chunk_counter = 0
    #         buffer = self.__reset_buffer()
    #         for i in range(self.conf["slice_part"]['evt_file_num']):
    #
    #             if chunk_counter > len(self.pulse_time_ranges) - 1:
    #                 break
    #
    #             evt_file = self.data_path + "/" + module + "_evt_" + str(i) + ".nxs"
    #             with h5py.File(evt_file, "r") as f:
    #                 buffer = self.__update_buffer(buffer,f,module)
    #                 while chunk_counter <= len(self.pulse_time_ranges) - 1:
    #                     start_time, end_time = self.pulse_time_ranges[chunk_counter]
    #                     start_idx = np.searchsorted(buffer["event_pulse_time"], start_time, side="left")
    #                     if start_idx == len(buffer['event_pulse_time']):
    #                         print("start_time > buffer max, jump to next file")
    #                         buffer = self.__reset_buffer()
    #                         break
    #                     end_idx = np.searchsorted(buffer["event_pulse_time"], end_time, side="right")
    #                     if end_idx == 0 or end_idx == start_idx:
    #                         print("end_idx < buffer min, go to next pulse_time_range")
    #                         self.save_chunk(self.__reset_buffer(), chunk_counter, module)
    #                         chunk_counter += 1
    #                         continue
    #                     if end_idx == len(buffer['event_pulse_time']):
    #                         print("end_time > buffer max, jump to next file")
    #                         break
    #                     if start_idx < end_idx:
    #                         num = len(buffer['event_pulse_time'][start_idx:end_idx])
    #                         print(f"save chunk for {chunk_counter},nc = {num},start = {start_idx}, end = {end_idx}")
    #                         self.save_chunk({'event_pulse_time': buffer['event_pulse_time'][start_idx:end_idx],
    #                                          'event_pixel_id': buffer['event_pixel_id'][start_idx:end_idx],
    #                                          'event_time_of_flight': buffer['event_time_of_flight'][start_idx:end_idx]},
    #                                         chunk_counter, module)
    #                         buffer = self.__trim_buffer(buffer,end_idx)
    #                         num = len(buffer['event_pulse_time'])
    #                         print(f"after save chunk for {chunk_counter}, left nc = {num}")
    #                         chunk_counter += 1
    #         if len(buffer['event_pulse_time']) > 0 and chunk_counter < len(self.pulse_time_ranges):
    #             print(f"最后一组数据不足 {self.pulse_time_ranges[chunk_counter]} 个。最后一组数据是 {len(buffer['event_pulse_time'])} 个")
    #             self.save_chunk(buffer, chunk_counter, module)
    #             chunk_counter += 1
    #         while chunk_counter < len(self.pulse_time_ranges):
    #             print(f"save empty chunk for {chunk_counter}")
    #             self.save_chunk(self.__reset_buffer(), chunk_counter, module)
    #             chunk_counter += 1
    #     except:
    #         traceback.print_exc()

    # @abstractmethod
    # def save_chunk(self, buffer, chunk_counter, module):
    #     """保存切片数据块（由子类实现）"""
    #     pass


    # def get_slice_pc(self):
    #     flist = glob.glob(self.data_path + "/pc*.nxs")
    #     pc_fn = flist[0]
    #     pc_data = np.ones(self.tot_num)
    #     with h5py.File(pc_fn, "r") as hf:
    #         try:
    #             pulse = hf["/csns/logs/proton_charge/pulse_time"]
    #             pc = hf["/csns/logs/proton_charge/value"]
    #         except:
    #             pulse = hf["/csns/logs/pulse_time"]
    #             pc = hf["/csns/logs/proton_charge"]
    #
    #         for i in range(self.tot_num):
    #             t1, t2 = self.pulse_time_ranges[i]
    #             idx1 = np.searchsorted(pulse, t1, side='left')
    #             idx2 = np.searchsorted(pulse, t2, side='right')
    #             tmp = pc[idx1:idx2]
    #             pc_data[i] = tmp.sum()
    #         return pc_data


