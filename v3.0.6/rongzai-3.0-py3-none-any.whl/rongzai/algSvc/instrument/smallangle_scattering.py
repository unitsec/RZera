import os
import numpy as np
from rongzai.utils import generate_x
from rongzai.dataSvc import load_histogram_data,merge_datasets,write_ascii
from rongzai.algSvc.base.core_unitconvert import *
from rongzai.algSvc.base import find_interval
from rongzai.algSvc.neutron import (get_roi_from_detector,extract_neutron_data,
                                    convert_unit_elastic,focus_neutron_data,
                                    rebin_neutron_data_2D)
'''
## sans_load_data：导入sans的数据
## get_detector_2D_BL14:对vsans计算探测器2D，目前只做了bank3
## process_wavelength: 处理成波长，用于透过率的

##############主流程########
## calculate_trans_BL14：vsans计算透过率，通过bank3来
## calculate_incident_BL14: vsans计算入射谱，通过bank3

'''

def sans_load_data(config,bank,data_type):
    modules = config["bank_info"][bank]
    data_list = []
    for name in modules:
        txt_path = os.path.join(config['param_path'], f"{name}.txt")
        data = load_histogram_data(config[data_type + "_fns"], txt_path, name,
                                      config['first_flight_distance'], config['T0_offset'])
        data_list.append(data)
    return data_list, merge_datasets(data_list, bank)


def get_detector_2D_BL14(config,data_list, bank):
    # y_total = int(300/config["group_pixel_num"])
    if bank == "bank3":
        result = np.zeros((250, 128))
        result_pid = np.zeros((250, 128))
        for i in range(len(data_list)):
            data =data_list[i]
            name = data.attrs.get("name")
            ynum = config["pixel_info"][name]["ypixels"]
            xnum = config["pixel_info"][name]["xpixels"]
            IDstart = config["pixel_info"][name]["start"]
            pixelData = np.arange(IDstart, int(IDstart + xnum * ynum))

            hist = data["histogram"].values.sum(axis=1)
            image = hist.reshape((ynum, xnum), order="F")
            print(image.shape)
            pixelData = pixelData.reshape((ynum, xnum), order="F")
            print(pixelData)
            result[:,i*64:(i+1)*64] = image
            result_pid[:, i*64:(i + 1) * 64] = pixelData
    else:
        raise Exception("please enter right bank name")

    return result, result_pid

def process_wavelength(dataset,pid_list,wave):
    data = extract_neutron_data(dataset,pid_list)
    data = convert_unit_elastic(data,"wavelength")
    data = focus_neutron_data(data,wave)
    return data



### ==============计算透过率
def calculate_trans_BL14(config,data_type):
    ### 得到样品的波长谱和直通光的波长谱，其中，air_trans可以当做入射谱。后面自行计算透过率
    wave = generate_x(config["wave_rebin"][0],config["wave_rebin"][1],config["wave_rebin"][2],"uniform")
    data_list, data_merge = sans_load_data(config,"bank3",data_type)
    image, image_pid = get_detector_2D_BL14(config,data_list,"bank3")
    pid_list = get_roi_from_detector(image, image_pid, "BL14")
    data_sam = process_wavelength(data_merge,pid_list,wave)
    pc = data_sam["proton_charge"].values
    data_sam["histogram"].values /= pc
    data_sam["error"].values /= pc

    data_list, data_merge = sans_load_data(config, "bank3", "air_trans")
    data_air = process_wavelength(data_merge, pid_list, wave)
    pc = data_air["proton_charge"].values
    data_air["histogram"].values /= pc
    data_air["error"].values /= pc
    # trans = data_sam["histogram"].values[0]/data_air["histogram"].values[0]
    return data_sam, data_air

def calculate_scat_BL14(config,bank,data_type,data_sam_tran,data_air_tran):
    data_list, data_merge = sans_load_data(config, bank, data_type)
    dataset = convert_unit_elastic(data_merge,"wavelength")
    wave = generate_x(config["wave_rebin"][0], config["wave_rebin"][1], config["wave_rebin"][2], "uniform")
    dataset = rebin_neutron_data_2D(dataset,wave)
    ##计算透过率
    trans = data_sam_tran["histogram"].values[0]/data_air_tran["histogram"].values[0]
    dataset["histogram"].values /= trans
    dataset["histogram"].values /= data_air_tran["histogram"].values[0]
    if bank == "bank1":
        q_rebin = generate_x(0.28,1,200)
    elif bank == "bank2":
        q_rebin = generate_x(0.065,0.6,200)
    else:
        q_rebin = generate_x(0.003,0.12,200)


def test_q1d(config):
    data_list, data_merge = sans_load_data(config,"bank3", "sample_scat")
    dataset = convert_unit_elastic(data_merge, "wavelength")
    wave = generate_x(config["wave_rebin"][0], config["wave_rebin"][1], config["wave_rebin"][2], "uniform")
    dataset = rebin_neutron_data_2D(dataset, wave)
    q_arr = generate_x(0.003,0.12,100)
    print(dataset["xvalue"].values[0])
    # sys.exit()
    result = []
    # ei = data_merge["energy"].values
    hist = dataset["histogram"].values
    wave_arr = dataset["xvalue"].values
    theta = dataset["positions"].values[:, 4].flatten() / 360 * np.pi
    final_iq = np.zeros_like(q_arr)
    for i in range(hist.shape[0]):
        # weight = np.zeros_like(q_arr)
        # value = hist[i, :]
        for j in range(hist.shape[1]):
            q = wavelength_to_q(wave_arr[i,j],theta[i])
            # print(q,wave_arr[i,j],theta[i])
            # if j == 10:
            #     sys.exit()
            k = find_interval(q_arr, q)
            # weight[k] += 1
            final_iq[k] += hist[i,j]
        # result.append(np.where(weight != 0, final_sq / weight, 0))
    # sqw = np.array(result)
    fn = "/Users/kobude/q1d.txt"
    write_ascii(fn,q_arr,final_iq)
    return q_arr, final_iq







# from rongzai.algSvc.neutron import (mask_neutron_data,offset_neutron_data,
#                 crop_neutron_data,focus_neutron_data,
#                 units_convert_neutron_data,divide_dataset)

# class SmallAngleScattering():
#     def __init__(self):
#         pass#self.pc_factor = 1E5
#
#     #def cal_trans(self,dataset,)
#
#     # def tof2d(self,dataset,wavemin,wavemax,cal_dict):
#     #     data = units_convert_neutron_data(dataset,"tof","wavelength",False)
#     #     data = crop_neutron_data(data,wavemin,wavemax)
#     #     data = units_convert_neutron_data(dataset,"wavelength","dspacing",False)
#     #     if cal_dict["has_cal"]:
#     #         data = mask_neutron_data(data,cal_dict["mask_list"])
#     #         data = offset_neutron_data(data,cal_dict["offset_list"])
#     #     return data
#
#     def time_focusing_sample(self,dataset,wavemin,wavemax,cal_dict):
#         data = units_convert_neutron_data(dataset,"tof","wavelength",False)
#         data = crop_neutron_data(data,wavemin,wavemax)
#         data = units_convert_neutron_data(dataset,"wavelength","dspacing",False)
#         if cal_dict["has_cal"]:
#             data = mask_neutron_data(data,cal_dict["mask_list"])
#             data = offset_neutron_data(data,cal_dict["offset_list"])
#         #data = self.tof2d(dataset,wavemin,wavemax,cal_dict)
#         data = focus_neutron_data(data)
#         #return data["xvalue"].values[0], data["histogram"].values[0],data["error"].values[0]
#         return data
#
#     def time_focusing_vanadium(self,dataset,wavemin,wavemax,cal_dict,correct_dict):
#         data = units_convert_neutron_data(dataset,"tof","wavelength",False)
#         data = crop_neutron_data(data,wavemin,wavemax)
#         task = AbsMsCorrNeutronData(data)
#         data = task.run_carpenter(correct_dict)
#         data = units_convert_neutron_data(dataset,"wavelength","dspacing",isMonitor=False)
#         if cal_dict["has_cal"]:
#             data = mask_neutron_data(data,cal_dict["mask_list"])
#             data = offset_neutron_data(data,cal_dict["offset_list"])
#         data = focus_neutron_data(data)
#         return data
#         #return data["xvalue"].values[0], data["histogram"].values[0],data["error"].values[0]
#
#     def get_monitor_wave(self,dataset,wavemin,wavemax):
#         data = units_convert_neutron_data(dataset,"tof","wavelength",isMonitor=True)
#         data = crop_neutron_data(data,wavemin,wavemax)
#         data = focus_neutron_data(data)
#         return data
#
#     def get_monitor_nc(self,dataset,wavemin,wavemax):
#         data = self.get_monitor_wave(dataset,wavemin,wavemax)
#         return data["histogram"].values.sum()
#
#     def normalization_by_wave(self,detdataset,mondataset,unit):
#         detdata = units_convert_neutron_data(detdataset,unit,"wavelength",isMonitor=False)
#         detdata = divide_dataset(detdata,mondataset)
#         detdata = units_convert_neutron_data(detdata,"wavelength",unit)
#         return detdata
