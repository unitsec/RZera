from rongzai.dataSvc import write_cal
from rongzai.algSvc.base import (baseline_alg,smooth,fit_multiple_peaks,goodness_of_fit,
                                 linear_fit_offset,quadratic_fit_offset)
from rongzai.utils import check_dir,find_group_from_module,generate_x
from rongzai.utils.constants import *
from rongzai.algSvc.neutron import group_neutron_data,convert_unit_elastic,rebin_neutron_data_2D
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor, as_completed


def tof2d(tof, C0, C1, C2):
    if C2 != 0:
        d = (- C1 + np.sqrt(C1 ** 2 - 4 * C2 * (C0 - tof))) / (2 * C2)
    else:
        d = (tof - C0) / C1
    return d

def correct_tof_to_d(dataset, cal_dict):
    ### using c0 c1, c2 to get dspcing from tof
    if cal_dict["group_along_tube_tof"] > 1 or cal_dict["group_cross_tube_tof"] > 1:
        dataset = group_neutron_data(dataset, cal_dict["pixels_per_tube"],
                                     cal_dict["group_along_tube_tof"], cal_dict["group_cross_tube_tof"])
    if cal_dict["group_along_tube_d"] > 1 or cal_dict["group_cross_tube_d"] > 1:
        dataset = convert_unit_elastic(dataset, "dspacing")
        dataset = group_neutron_data(dataset, cal_dict["pixels_per_tube"],
                                     cal_dict["group_along_tube_d"], cal_dict["group_cross_tube_d"])
        dataset = convert_unit_elastic(dataset, "tof")
    c2 = np.array(cal_dict["c2_list"])
    c1 = np.array(cal_dict["c1_list"])
    c0 = np.array(cal_dict["c0_list"])
    x = dataset["xvalue"].values
    c2_zero_indices = (c2 == 0)
    c2_nonzero_indices = ~c2_zero_indices
    a = np.full((len(c2), x.shape[1]), np.nan)
    if np.any(c2_zero_indices):
        a[c2_zero_indices] = (x[c2_zero_indices, :] - c0[c2_zero_indices, np.newaxis]) / c1[c2_zero_indices, np.newaxis]
    if np.any(c2_nonzero_indices):
        c2_nonzero = c2[c2_nonzero_indices, np.newaxis]
        c1_nonzero = c1[c2_nonzero_indices, np.newaxis]
        c0_nonzero = c0[c2_nonzero_indices, np.newaxis]
        x_nonzero = x[c2_nonzero_indices, :]
        a[c2_nonzero_indices] = (-c1_nonzero + np.sqrt(c1_nonzero**2 - 4 * c2_nonzero * (c0_nonzero - x_nonzero))) / (2 * c2_nonzero)
    if np.isnan(a).any():
        raise ValueError("有NAN值存在，请重新拟合，程序退出")
    dataset["xvalue"].values = a
    dataset["xvalue"].attrs.update({"units": units_match["dspacing"]})
    dataset.attrs["x_unit"] = "dspacing"
    return dataset

#### 私有函数
def _get_pixel_info(module,conf):
    if conf["pixel_info"][module]["stepbyrow"] == "x":
        return conf["pixel_info"][module]["xpixels"]
    else:
        return conf["pixel_info"][module]["ypixels"]

### 看是否需要group原始数据，从tof和d两个单位考虑，最终转成d的histogram,另外需要对tof进行rebin再试试
def _group_dataset_to_d(dataset,conf):
    if conf["tof_rebin"]["do_rebin"]:
        new_tof = generate_x(conf["tof_rebin"]["params"][0],conf["tof_rebin"]["params"][1],conf["tof_rebin"]["params"][2])
        dataset = rebin_neutron_data_2D(dataset,new_tof)
    module = dataset.attrs.get("name")
    pixel_per_tube = _get_pixel_info(module, conf)
    group = find_group_from_module(module,conf["group_info"],conf["bank_info"])
    group_tof_conf = conf["group_para_tof"][group]
    group_d_conf = conf["group_para_d"][group]
    if group_tof_conf["group_along_tube"] > 1 or group_tof_conf["group_cross_tube"] > 1:
        data = group_neutron_data(dataset,pixel_per_tube,group_tof_conf["group_along_tube"],
                                  group_tof_conf["group_cross_tube"])
    data = convert_unit_elastic(dataset,"dspacing")
    if group_d_conf["group_along_tube"] > 1 or group_d_conf["group_cross_tube"] > 1:
        data = group_neutron_data(data,pixel_per_tube,group_d_conf["group_along_tube"],
                                  group_d_conf["group_cross_tube"])
    return data

def _filter_valid_peaks(tof_position_exp, peaks_position):
    # return peak position in tof, and standard peak position in dspacing
    exp_tof = []
    std_d = []
    for idx, value in enumerate(tof_position_exp):
        if value != 0.0:
            exp_tof.append(value)
            std_d.append(peaks_position[idx])
    return exp_tof[::-1], std_d[::-1]


#######################   各种所需画图   ##############################
## _plot_fitted_peaks： 检查拟合峰的情况
## _plot_fitted_offset： 检查tof与d的拟合情况，即C0,C1,C2对不对
## _plot_corrected_data: 检查offset修正后的衍射谱情况
####################################################################
def _plot_fitted_peaks(name, x, y, smoothed_y, peak, all_d_peak, all_I_peak, peaks_position):
    fig, ax = plt.subplots()
    ax.plot(x, y, 'g-', label='intensity')
    ax.plot(x, smoothed_y, 'b-', label='smoothed_intensity')
    for i in range(len(peak)):
        ax.plot(peak[i][0], peak[i][1], 'r-', label='Fitted Gaussian')
        ax.plot(all_d_peak[i], all_I_peak[i], 'rx')
    for j in peaks_position:
        ax.axvline(x=j, color='black', linestyle='--', linewidth=1,
                   label='Standard Peak Position' if j == peaks_position[0] else "")
    plt.grid(True)
    plt.title(name)
    plt.legend()
    plt.show()

def _plot_fitted_offset(std_d, exp_tof, fitted_tof, order):
    std4plot = [0] + std_d
    if order == 'linear':
        plt.title('Linear Fit: tof = C0 + C1 * d')
    elif order == 'quadratic':
        plt.title('Quadratic Fit: tof = C0 + C1 * d + C2 * d^2')
    plt.scatter(std_d, exp_tof, color='blue', label='Original Data')
    plt.plot(std4plot, fitted_tof, color='red', label='Fitted Curve')
    plt.xlabel('d_std')
    plt.ylabel('Time-of-Flight (tof_exp)')
    plt.legend()
    plt.grid()
    plt.show()

def _plot_corrected_data(x, y, corrected_x, smoothed_y, peaks_position):
    fig, ax = plt.subplots()
    ax.plot(x, y, 'g-', label='Original Data')
    ax.plot(x, smoothed_y, 'b-', label='Original Data (smoothed)')
    ax.plot(corrected_x, smoothed_y, 'r-', label='Offset Data (smoothed)')
    for j in peaks_position:
        ax.axvline(x=j, color='black', linestyle='--', linewidth=1,
                   label='Standard Peak Position' if j == peaks_position[0] else "")
    # ax.legend()
    plt.grid(True)
    plt.legend()
    plt.show()


def process_pixel_multiple_samples(idx, x_arrays,y_arrays, c1_unoffset, peaks_position_list,
                                   high_width_para_list, fit_function_list,goodness_bottom_list,
                                   is_c0_0,anchor_point, mode, check_point, sub_background_list,
                                   is_smooth_list,smooth_para_list,least_peaks_num_list,order_list,name,ui=False):
    """
    处理多个样品的像素数据，进行联合拟合
    """
    C0 = 0
    C1 = c1_unoffset
    C2 = 0
    mask = 1
    plot_info = []

    if mode == 'check' and idx != check_point:
        return C0, C1, C2, mask, plot_info

    # 处理所有样品的数据
    all_exp_tof = []
    all_std_d = []

    for sample_idx, (x, y, peaks_position, high_width_para, fit_function,
                     goodness_bottom, sub_background, is_smooth, smooth_para) in enumerate(
        zip(x_arrays, y_arrays, peaks_position_list, high_width_para_list,
            fit_function_list, goodness_bottom_list, sub_background_list, is_smooth_list, smooth_para_list)):
        y = y.astype(np.float64)
        x = x.astype(np.float64)
        ### 是否扣背底
        if sub_background:
            background = baseline_alg(y, lam=1e5, p=0.01)
            y -= background

        ### 是否归一
        if y.max() > 0:
            y /= y.max()

        y_raw = y.copy()

        ### 是否光滑
        if is_smooth and smooth_para is not None:
            y = smooth(y, smooth_para[0], smooth_para[1])
        ### 拟合多个峰，确定多个峰的d值
        d_position_exp, peak, all_d_peak, all_I_peak = fit_multiple_peaks(x, y, peaks_position, high_width_para,
                                                                          fit_function, goodness_bottom)
        ### 检查的内容
        if mode == 'check' and idx == check_point:
            print(f'pixel: {idx}, sample: {sample_idx}')
            if ui is True:
                plot_info.append(
                    [f"{name}_sample{sample_idx}", x, y_raw, y, peak, all_d_peak, all_I_peak, peaks_position])
            else:
                print(f"goodness of peaks for sample {sample_idx}:")
                for i in range(len(peak)):
                    if d_position_exp[i] == 0:
                        pass
                    else:
                        print(f"peak in {d_position_exp[i]:.3f}:", goodness_of_fit(peak[i][1], all_I_peak[i]))
                _plot_fitted_peaks(f"{name}_sample{sample_idx}", x, y_raw, y, peak, all_d_peak, all_I_peak,
                                   peaks_position)

        #### 将实验的峰的d值转为tof,获取实验的tof与标准的d的一一对应的点用于拟合
        tof_position_exp = np.array(d_position_exp) * c1_unoffset
        exp_tof, std_d = _filter_valid_peaks(tof_position_exp, peaks_position)

        # 收集所有样品的峰值数据
        all_exp_tof.extend(exp_tof)
        all_std_d.extend(std_d)

        if mode == 'check' and idx == check_point:
            print(f"Sample {sample_idx} - peaks for fitting: {len(exp_tof)}")

    # 检查总的峰值数量是否足够
    total_peaks = len(all_exp_tof)

    # 使用所有样品中最小的least_peaks_num要求
    min_least_peaks = min(least_peaks_num_list) if least_peaks_num_list else 2

    if total_peaks < min_least_peaks:
        mask = 0
        if mode == 'check' and idx == check_point:
            print(f"Total peaks ({total_peaks}) less than required ({min_least_peaks})")
        return C0, C1, C2, mask, plot_info

    # 使用所有样品的峰值数据进行拟合
    all_exp_tof = np.array(all_exp_tof)
    all_std_d = np.array(all_std_d)

    # 确定拟合阶数（使用第一个样品的order，或者可以自定义逻辑）
    # 这里使用第一个样品的order，您可以根据需要修改
    fit_order = order_list[0] if order_list else 'quadratic'

    if mode == 'check' and idx == check_point:
        print(f"Total peaks from all samples: {total_peaks}")
        print(f"Using {fit_order} fit with data from {len(x_arrays)} samples")
        print(f"Minimum required peaks: {min_least_peaks}")

    if fit_order == 'linear':
        C0, C1, C2, mask, fitted_tof = linear_fit_offset(all_std_d, all_exp_tof, C1, is_c0_0, anchor_point)
    elif fit_order == 'quadratic':
        C0, C1, C2, mask, fitted_tof = quadratic_fit_offset(all_std_d, all_exp_tof, C1, is_c0_0, anchor_point)

    if mode == 'check' and idx == check_point:
        # 绘制所有样品的原始数据和修正后的数据
        for sample_idx, (x, y_raw, y) in enumerate(zip(x_arrays,[y_arr.astype(np.float64) for y_arr in y_arrays],
                                                                [y_arr.astype(np.float64) for y_arr in y_arrays],
                                                                    )):
            # 重新处理原始数据用于绘图（因为之前的处理可能修改了y）
            y_plot = y_arrays[sample_idx].astype(np.float64)
            x_plot = x_arrays[sample_idx].astype(np.float64)

            if sub_background_list[sample_idx]:
                background = baseline_alg(y_plot, lam=1e5, p=0.01)
                y_plot -= background
            if y_plot.max() > 0:
                y_plot /= y_plot.max()
            if is_smooth_list[sample_idx] and smooth_para_list[sample_idx] is not None:
                y_plot = smooth(y_plot, smooth_para_list[sample_idx][0], smooth_para_list[sample_idx][1])

            tof_raw = x_plot * c1_unoffset
            corrected_d = tof2d(tof_raw, C0, C1, C2)

            if ui is True:
                # 为每个样品添加修正后的数据
                if sample_idx == 0:  # 只在第一个样品时添加拟合参数
                    plot_info.append([all_std_d, all_exp_tof, [C0, C1, C2], fit_order])
                plot_info.append([x_plot, y_plot, corrected_d, peaks_position_list[sample_idx], f"sample{sample_idx}"])
            else:
                # 绘制拟合结果和修正后的数据
                if sample_idx == 0:  # 只绘制一次拟合结果
                    _plot_fitted_offset(all_std_d, all_exp_tof, fitted_tof, fit_order)
                _plot_corrected_data(x_plot, y_plot, corrected_d, y_plot, peaks_position_list[sample_idx])

    return C0, C1, C2, mask, plot_info

# def process_pixel(idx, x, y, c1_unoffset,peaks_position, high_width_para,
#                         fit_function, goodness_bottom, is_c0_0, anchor_point, mode, check_point, sub_background,
#                         is_smooth, smooth_para, least_peaks_num, order, name,ui=False):
#     ### 传入的x是dspacing
#     C0 = 0
#     C1 = c1_unoffset
#     C2 = 0
#     mask = 1
#     plot_info = []
#     if mode == 'check' and idx != check_point:
#
#         return C0,C1,C2,mask,plot_info
#
#     y = y.astype(np.float64)
#     x = x.astype(np.float64)
#     ###是否扣背底
#     if sub_background:
#         background = baseline_alg(y, lam=1e5, p=0.01)
#         y -= background
#     ###是否归一
#     if y.max() > 0:
#         y /= y.max()
#
#     y_raw = y.copy()
#     ###是否光滑
#     if is_smooth and smooth_para is not None:
#         y = smooth(y, smooth_para[0], smooth_para[1])
#
#     ### 拟合多个峰，确定多个峰的d值
#     d_position_exp, peak, all_d_peak, all_I_peak = fit_multiple_peaks(x,y,peaks_position,high_width_para,
#                                                                       fit_function,goodness_bottom)
#
#     ### 检查的内容
#     if mode == 'check' and idx == check_point:
#         print('pixel:' + str(idx))
#         if ui is True:
#             # pass
#             plot_info.append([name, x, y_raw, y, peak, all_d_peak, all_I_peak, peaks_position])
#         else:
#             # 在check模式下打印出各个峰的拟合优度
#             print("goodness of peaks:")
#             for i in range(len(peak)):
#                 if d_position_exp[i] == 0:
#                     pass
#                     # print(peak[i])
#                     # print(f"peak:", goodness_of_fit(peak[i][1], all_I_peak[i]))
#                 else:
#                     print(f"peak in {d_position_exp[i]:.3f}:", goodness_of_fit(peak[i][1], all_I_peak[i]))
#             _plot_fitted_peaks(name, x, y_raw, y, peak, all_d_peak, all_I_peak, peaks_position)
#
#     #### 继续运行，将实验的峰的d值转为tof,获取实验的tof与标准的d的一一对应的点用于拟合
#     # print("c1_unoffset:",c1_unoffset)
#     tof_position_exp = np.array(d_position_exp) * c1_unoffset
#     exp_tof, std_d = _filter_valid_peaks(tof_position_exp, peaks_position)
#     # print("peaks for fitting: ",len(exp_tof))
#     if len(exp_tof) < least_peaks_num:
#         mask = 0
#         return C0,C1,C2,mask,plot_info
#     else:
#         if order == 'linear':
#             C0,C1,C2,mask,fitted_tof = linear_fit_offset(std_d, exp_tof,c1_unoffset, is_c0_0, anchor_point)
#         elif order == 'quadratic':
#             C0,C1,C2,mask,fitted_tof = quadratic_fit_offset(std_d,exp_tof, c1_unoffset, is_c0_0, anchor_point)
#
#         if mode == 'check' and idx == check_point:
#             tof_raw = x * c1_unoffset
#             corrected_d = tof2d(tof_raw, C0, C1, C2)
#             if ui is True:
#                 plot_info.append([std_d, exp_tof, [C0,C1,C2], order])
#                 plot_info.append([x, y_raw, y, corrected_d, peaks_position])
#             else:
#                 _plot_fitted_offset(std_d, exp_tof, fitted_tof, order)
#                 _plot_corrected_data(x, y_raw, corrected_d, y, peaks_position)
#     return C0,C1,C2,mask,plot_info





### 对module进行offset修正
def run_module_offset(dataset_list,conf,ui):
    info = {}

    module = dataset_list[0].attrs["name"]
    check_dir(conf['save_path'])
    save_file = conf['save_path'] + "/" + module + "_offset.cal"
    info["save_file"] = save_file

    pixel_per_tube = _get_pixel_info(module, conf)
    group = find_group_from_module(module, conf["group_info"], conf["bank_info"])
    group_tof_conf = conf["group_para_tof"][group]
    group_d_conf = conf["group_para_d"][group]

    info["group_along_tube_tof"] = group_tof_conf["group_along_tube"]
    info["group_cross_tube_tof"] = group_tof_conf["group_cross_tube"]
    info["group_along_tube_d"] = group_d_conf["group_along_tube"]
    info["group_cross_tube_d"] = group_d_conf["group_cross_tube"]
    info["pixels_per_tube"] = pixel_per_tube

    ##处理所有样品的数据
    all_data = []
    all_peaks_position = []
    all_high_width_para = []
    all_fit_para =[]
    all_smooth_para =[]

    for i,dataset in enumerate(dataset_list):
        sample_run = conf["sample_run"][i][0]
        sample_params = conf["sample_parameters"][sample_run]
        #原始数据转到dspacing
        data = _group_dataset_to_d(dataset, conf)
        if i == 0:
            l = data["l1"].values + data["positions"].values[:, 3]
            theta = data["positions"].values[:, 4] / 360 * np.pi
            c1_unoffset = l * np.sin(theta) * FACTOR_MP
        all_data.append(data)

        # 获取每个样品的特定参数
        all_peaks_position.append(sample_params["d_std"][group])
        all_high_width_para.append(sample_params["high_width_para"][group])
        all_fit_para.append(sample_params["fit_para"][group])
        all_smooth_para.append(sample_params["smooth_para"][group])

    ## 初始化offset文件内容
    info["pixel"] = all_data[0].coords["pixel"].values
    info["index"] = np.arange(0, len(info["pixel"]))
    info["group"] = np.ones(len(info["pixel"]))
    info["mask"] = np.ones(len(info["pixel"]))
    info['offset'] = np.zeros((len(info["pixel"]), 3))

    if conf['mode'] == 'check':
       print(module)

    all_x_matrix = [data["xvalue"].values for data in all_data]
    all_y_matrix = [data["histogram"].values for data in all_data]

    # plt.plot(all_x_matrix[0][0,:],all_y_matrix[0][0,:],label = "tset")
    # plt.legend()
    # plt.show()
    # print("============")
    # print(all_x_matrix[0].shape,all_x_matrix[1].shape)
    # print(all_y_matrix[0].shape, all_y_matrix[1].shape)
    plot_info_module = []

    if conf['parallel']:
        max_workers = conf.get("max_workers", 4)
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [
                executor.submit(process_pixel_multiple_samples,
                                idx,
                                [x_matrix[idx, :] for x_matrix in all_x_matrix],
                                [y_matrix[idx, :] for y_matrix in all_y_matrix],
                                c1_unoffset[idx],
                                all_peaks_position,
                                all_high_width_para,
                                [fit_para["fit_function"] for fit_para in all_fit_para],
                                [fit_para["goodness_bottom"] for fit_para in all_fit_para],
                                conf["is_c0_0"],
                                conf['anchor_point'],
                                conf['mode'],
                                conf['check_point'],
                                [fit_para['sub_background'] for fit_para in all_fit_para],
                                [smooth_para['is_smooth'] for smooth_para in all_smooth_para],
                                [smooth_para['smooth_para'] for smooth_para in all_smooth_para],
                                [fit_para['least_peaks_num'] for fit_para in all_fit_para],
                                [fit_para['order'] for fit_para in all_fit_para],
                                module,
                                ui) for idx in range(len(c1_unoffset))]

            for idx, future in enumerate(as_completed(futures)):
                try:
                    info["offset"][idx, 0], info["offset"][idx, 1], info["offset"][idx, 2], info["mask"][
                        idx], _ = future.result()
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    print(f"Error processing pixel {idx}: {e}")

    else:
        for idx in range(len(c1_unoffset)):
            # print(f"start with {idx}")

            info["offset"][idx, 0], info["offset"][idx, 1], info["offset"][idx, 2], info["mask"][
                idx], plot_info = process_pixel_multiple_samples(
                idx,
                [x_matrix[idx, :] for x_matrix in all_x_matrix],
                [y_matrix[idx, :] for y_matrix in all_y_matrix],
                c1_unoffset[idx],
                all_peaks_position,
                all_high_width_para,
                [fit_para["fit_function"] for fit_para in all_fit_para],
                [fit_para["goodness_bottom"] for fit_para in all_fit_para],
                conf["is_c0_0"],
                conf['anchor_point'],
                conf['mode'],
                conf['check_point'],
                [fit_para['sub_background'] for fit_para in all_fit_para],
                [smooth_para['is_smooth'] for smooth_para in all_smooth_para],
                [smooth_para['smooth_para'] for smooth_para in all_smooth_para],
                [fit_para['least_peaks_num'] for fit_para in all_fit_para],
                [fit_para['order'] for fit_para in all_fit_para],
                module,
                ui)
            plot_info_module.append(plot_info)
    if ui is True and conf['mode'] == "check":
        pass
    else:
        write_cal(info)
        print(f'offset file has been saved in {info["save_file"]} successfully')
        print('the number of masked pixels:', np.sum(info["mask"] == 0))
        print('the masking rate:', np.sum(info["mask"] == 0) / len(info["mask"]))
    return plot_info_module

