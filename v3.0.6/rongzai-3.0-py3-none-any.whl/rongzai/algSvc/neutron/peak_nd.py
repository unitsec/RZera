from rongzai.algSvc.base import (strip_peaks,smooth)
import numpy as np
def strip_peaks_neutron_data(dataset,peaks,ranges):
    if dataset["histogram"].values.shape[0] > 1:
        raise Exception("input dataset should be 1D")
    y = strip_peaks(dataset["xvalue"].values[0],
                    dataset["histogram"].values[0],
                    peaks, ranges)
    y = np.expand_dims(y,axis = 0)
    dataset["histogram"].values = y
    return dataset

def smooth_neutron_data(dataset,npoint,order):
    if dataset["histogram"].values.shape[0] > 1:
        raise Exception("input dataset should be 1D")
    y = smooth(dataset["histogram"].values[0],
                npoint,order)
    y = np.expand_dims(y, axis=0)
    dataset["histogram"].values = y
    return dataset
