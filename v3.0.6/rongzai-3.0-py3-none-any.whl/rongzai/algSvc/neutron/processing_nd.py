import numpy as np
from rongzai.dataSvc import create_dataset

# ==================== Crop, Extraction and Mask ====================
def crop_neutron_data(dataset,xmin,xmax):
    xarr = dataset["xvalue"].values
    indices = [np.argmax(row > xmin) for row in xarr]
    idx1 = max(indices)
    indices = [np.argmax(row > xmax) if np.any(row > xmax) else len(row) for row in xarr]
    idx2 = min(indices)

    histogram_data = dataset["histogram"].values
    error_data = dataset["error"].values
    new_xvalue_data = xarr[:, idx1:idx2]
    new_histogram_data = histogram_data[:, idx1:idx2]
    new_error_data = error_data[:,idx1:idx2]

    pos = dataset["positions"].values
    pixel = dataset['positions'].coords['pixel'].values
    l1 = dataset.get("l1", None)
    proton_charge = dataset.get("proton_charge", None)
    module = dataset.attrs.get("name", None)
    unit = dataset.attrs.get("x_unit", None)
    data = create_dataset(new_histogram_data,new_error_data,new_xvalue_data,
                        pixel,pos,proton_charge,l1,module=module,unit=unit)
    return data

def extract_neutron_data(dataset, pixel_id_list):
    ### 根据给定的 pixel ID 列表提取对应像素的数据，生成新的 Dataset
    all_pixel_ids = dataset['positions'].coords['pixel'].values
    valid_ids = [pid for pid in pixel_id_list if pid in all_pixel_ids]
    if not valid_ids:
        raise ValueError("No valid pixel IDs found in the dataset")
    valid_indices = [np.where(all_pixel_ids == pid)[0][0] for pid in valid_ids]
    extracted_hist = dataset['histogram'].values[valid_indices, :]
    extracted_error = dataset['error'].values[valid_indices, :]
    extracted_x = dataset['xvalue'].values[valid_indices, :]
    extracted_pos = dataset['positions'].values[valid_indices, :]
    extracted_pixel = dataset['positions'].coords['pixel'].values[valid_indices]
    l1 = dataset.get("l1", None)
    pc = dataset.get("proton_charge", None)
    module = dataset.attrs.get("name", None)
    unit = dataset.attrs.get("x_unit", None)
    return create_dataset(extracted_hist, extracted_error, extracted_x,
                        extracted_pixel,extracted_pos,pc,l1, module=module,unit=unit)

def mask_neutron_data(dataset,mask_list):
    dataset["histogram"].values[mask_list==0,:] = 0
    dataset["error"].values[mask_list==0,:] = 0
    return dataset




def check_reverse_neutron_data(dataset):
    x = dataset["xvalue"].values
    if x[0, 0] > x[0, -1]:
        x = x[:, ::-1]
        dataset["xvalue"].values = x
        y = dataset["histogram"].values
        y = y[:, ::-1]
        dataset["histogram"].values = y
        e = dataset["error"].values
        e = e[:, ::-1]
        dataset["error"].values = e
    return dataset

def get_position_by_pixel_id(dataset,target_pixel_id):
    try:
        position = dataset["positions"].sel(pixel=target_pixel_id).values
        l1 = dataset["l1"].values
        return l1,position
    except:
        raise Exception("error in neutron_data")


def sum_tof(dataset):
    unit = dataset.attrs.get("x_unit")
    if unit == "tof":
        hist = dataset["histogram"].values
        x = dataset["xvalue"].values[0]
        hist = hist.sum(axis = 0)
        err = np.sqrt(hist)
        z = dataset['positions'].values[0][2]
        pos = dataset["positions"].values[0]
        pos[0] = 0
        pos[1] = 0
        pos[3] = z
        pos[4] = 0
        pixel = dataset['positions'].coords['pixel'].values[0]
        l1 = dataset["l1"].values
        pc = dataset["proton_charge"].values
        module = dataset.attrs.get("name", None)
        data = create_dataset(hist, err, x,
                              pixel, pos, pc, l1, module=module, unit=unit)
        return data
    else:
        raise Exception(f"unit should be tof, but it's {unit}")



