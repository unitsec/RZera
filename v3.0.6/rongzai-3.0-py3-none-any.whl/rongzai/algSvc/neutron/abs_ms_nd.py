import numpy as np
from rongzai.dataSvc import create_dataset
from rongzai.utils.helper import getRZeraLib
from ctypes import *

def correct_carpenter(dataset,conf):
    unit = dataset.attrs.get("x_unit", None)
    if unit != "wavelength":
        raise ValueError(f"unit should be wavelength, not {unit}")
    task = AbsMsCorrNeutronData(dataset)
    return task.run_carpenter(conf)

def calculate_carpenter(dataset,conf):
    unit = dataset.attrs.get("x_unit", None)
    if unit != "wavelength":
        raise ValueError(f"unit should be wavelength, not {unit}")
    task = AbsMsCorrNeutronData(dataset)
    data_abs, data_ms = task.get_carpenter(conf)
    return data_abs, data_ms

def correct_bkg_abs_psd(dataset,conf):
    unit = dataset.attrs.get("x_unit", None)
    if unit != "wavelength":
        raise ValueError(f"unit should be wavelength, not {unit}")
    task = AbsMsCorrNeutronData(dataset)
    return task.run_bkg_abs_psd(conf)

def calculate_bkg_abs_psd(dataset,conf):
    unit = dataset.attrs.get("x_unit", None)
    if unit != "wavelength":
        raise ValueError(f"unit should be wavelength, not {unit}")
    task = AbsMsCorrNeutronData(dataset)
    return task.get_bkg_abs_psd(conf)

class AbsMsCorrNeutronData():
    def __init__(self,dataset):
        position = dataset["positions"].values
        self.theta = position[:,4] / 360 * np.pi

        self.nd = dataset
        self.rzlib = getRZeraLib()

    def run_carpenter(self,conf):
        new_abs = np.zeros(self.nd["histogram"].shape)
        new_ms = np.zeros(self.nd["histogram"].shape)
        if self.nd["xvalue"].values.ndim == 2:
            for i in range(self.nd["xvalue"].values.shape[0]):

                wave_arr = self.nd["xvalue"].values[i,:]
                input_size = len(wave_arr)
                input_array = (c_double * input_size)(*wave_arr)
                output_abs =  (c_double * input_size)()
                output_ms =  (c_double * input_size)()

                self.rzlib.calculate_abs_correction(
                    c_double(2*self.theta[i]), c_double(conf["radius"]),
                    c_double(conf['atten_xs']), c_double(conf['density_num']*conf["scale"]),
                    c_double(conf['scatt_xs']),input_array,
                    c_size_t(input_size), output_abs)
                yabs = np.array(output_abs)
                new_abs[i,:]=yabs
                self.rzlib.calculate_ms_correction(
                    c_double(2*self.theta[i]), c_double(conf["radius"]),
                    c_double(conf['atten_xs']), c_double(conf['density_num']),
                    c_double(conf['scatt_xs']),input_array,
                    c_size_t(input_size), output_ms)
                yms = np.array(output_ms)

                new_ms[i,:]=yms

        new_data = self.nd["histogram"].values* (1 / new_abs - new_ms)
        err_data = self.nd["error"].values * (1 / new_abs - new_ms)

        module = self.nd.attrs.get("name", None)
        unit = self.nd.attrs.get("x_unit", None)
        dataset = create_dataset(new_data,err_data,self.nd["xvalue"].values,
                                self.nd["positions"].coords["pixel"].values,
                                self.nd["positions"].values,
                                self.nd['proton_charge'],self.nd['l1'],module,unit)

        return dataset

    def get_carpenter(self,conf):
        new_abs = np.zeros(self.nd["histogram"].shape)
        new_ms = np.zeros(self.nd["histogram"].shape)
        if self.nd["xvalue"].values.ndim == 2:
            for i in range(self.nd["xvalue"].values.shape[0]):

                wave_arr = self.nd["xvalue"].values[i,:]
                input_size = len(wave_arr)
                input_array = (c_double * input_size)(*wave_arr)
                output_abs =  (c_double * input_size)()
                output_ms =  (c_double * input_size)()

                self.rzlib.calculate_abs_correction(
                    c_double(2*self.theta[i]), c_double(conf["radius"]),
                    c_double(conf['atten_xs']), c_double(conf['density_num']*conf["scale"]),
                    c_double(conf['scatt_xs']),input_array,
                    c_size_t(input_size), output_abs)
                yabs = np.array(output_abs)
                new_abs[i,:]=yabs
                self.rzlib.calculate_ms_correction(
                    c_double(2*self.theta[i]), c_double(conf["radius"]),
                    c_double(conf['atten_xs']), c_double(conf['density_num']),
                    c_double(conf['scatt_xs']),input_array,
                    c_size_t(input_size), output_ms)
                yms = np.array(output_ms)

                new_ms[i,:]=yms

        module = self.nd.attrs.get("name", None)
        unit = self.nd.attrs.get("x_unit", None)
        err_data = np.zeros(new_abs.shape)
        dataset_abs = create_dataset(new_abs,err_data,self.nd["xvalue"].values,
                                self.nd["positions"].coords["pixel"].values,
                                self.nd["positions"].values,
                                self.nd['proton_charge'],self.nd['l1'],module,unit)
        err_data = np.zeros(new_ms.shape)
        dataset_ms = create_dataset(new_ms,err_data,self.nd["xvalue"].values,
                                self.nd["positions"].coords["pixel"].values,
                                self.nd["positions"].values,
                                self.nd['proton_charge'],self.nd['l1'],module,unit)
        return dataset_abs,dataset_ms

    def get_bkg_abs_psd(self, conf):
        bkg_abs = np.zeros(self.nd["histogram"].shape)
        if self.nd["xvalue"].values.ndim == 2:
            for i in range(self.nd["xvalue"].values.shape[0]):
                wave_arr = self.nd["xvalue"].values[i, :]
                mu = conf['holder_attenXs'] * conf["holder_densityNum"] * wave_arr + conf['holder_incXs'] * conf[
                    'holder_densityNum']
                trans_ratio = np.array(np.exp(-mu * conf['holder_thickness']))
                bkg_abs[i, :] = trans_ratio

        module = self.nd.attrs.get("name", None)
        unit = self.nd.attrs.get("x_unit", None)
        err_data = np.zeros(bkg_abs.shape)
        dataset_bkg_abs = create_dataset(bkg_abs, err_data, self.nd["xvalue"].values,
                                        self.nd["positions"].coords["pixel"].values,
                                        self.nd["positions"].values,
                                        self.nd['proton_charge'], self.nd['l1'], module, unit)
        return dataset_bkg_abs

    def run_bkg_abs_psd(self, conf):
        bkg_abs = np.zeros(self.nd["histogram"].shape)
        if self.nd["xvalue"].values.ndim == 2:
            for i in range(self.nd["xvalue"].values.shape[0]):
                wave_arr = self.nd["xvalue"].values[i, :]
                mu = conf['holder_attenXs'] * conf["holder_densityNum"] * wave_arr + conf['holder_incXs'] * conf[
                    'holder_densityNum']
                trans_ratio = np.array(np.exp(-mu * conf['holder_thickness']))
                bkg_abs[i, :] = trans_ratio

        new_data = self.nd["histogram"].values * bkg_abs
        err_data = self.nd["error"].values * bkg_abs

        module = self.nd.attrs.get("name", None)
        unit = self.nd.attrs.get("x_unit", None)
        dataset = create_dataset(new_data, err_data, self.nd["xvalue"].values,
                                        self.nd["positions"].coords["pixel"].values,
                                        self.nd["positions"].values,
                                        self.nd['proton_charge'], self.nd['l1'], module, unit)
        return dataset