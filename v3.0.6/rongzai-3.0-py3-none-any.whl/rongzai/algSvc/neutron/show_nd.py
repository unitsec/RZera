from rongzai.dataSvc.data_plot import ScientificPlots
import matplotlib.pyplot as plt

def get_roi_from_detector(image,image_pixel,name,vmin=None,vmax=None):
    task = ScientificPlots()
    task.plot_heatmap(image,vmin,vmax,title=name, xlabel='X-axis', ylabel='Y-axis')
    try:
        selected_range = task.get_selected_range()
        x1, x2, y1, y2 = selected_range[0][0], selected_range[0][1], selected_range[1][0], selected_range[1][1]
        print(f"Selected x1, x2: {x1}, {x2}")
        print(f"Selected y1, y2: {y1}, {y2}")
        roi = image_pixel[y1:y2+1,x1:x2+1].flatten()
        if roi is None:
            raise ValueError("No roi has been selected yet.")
        return roi
    except ValueError as e:
        print(e)

def plot_line(dataset,idx=0):
    x = dataset["xvalue"].values[idx]
    y = dataset["histogram"].values[idx]
    task = ScientificPlots()
    task.plot_line(x,y,title = dataset.attrs.get("name", None),xlabel=dataset.attrs.get("x_unit"),ylabel="Intensity")

def plot_heatmap(dataset,vmin=None,vmax=None):
    image = dataset["histogram"].values
    task = ScientificPlots()
    task.plot_heatmap(image, vmin, vmax, title=dataset.attrs.get("name", None), xlabel='X-axis', ylabel='Y-axis')