'''
#### 跟dataset相关的计算，类似于操作workspae
abs_ms_nd：用于吸收与多级散射修正AbsMsCorrNeutronData类，用carpenter修正，可以得到ms和abs，也可以得到修正后结果
calculate_nd: 用于两个dataset的加减除的CalculateNeutronData类，需要rebin
group_nd: group探测器的GroupNeutronData类，给定合并像素按照长方形来group
pixel_offset_nd: 做time-focussing的修正PixelOffsetCalNeutronData类，主要是tof到d参数的修正，二次或者一次修正
unit_convert_nd: 做单位转换的UnitConvertNeutronData类，可能需要修改，因为新版的txt_file里面theta，l2都已经给出存到dataset里面！！！
show2D_nd:
processing_nd:各种操作，里面有点混乱，可能需要分类
####
'''
from .processing_nd import (crop_neutron_data,extract_neutron_data,
                            mask_neutron_data,
                            get_position_by_pixel_id,
                            check_reverse_neutron_data,
                            sum_tof)

from .show_nd import get_roi_from_detector,plot_line,plot_heatmap
from .unitconvert_nd import convert_unit_elastic,convert_unit_inelastic
from .calculate_nd import calculate_neutron_data
from .cppkernels_nd import (group_neutron_data,rebin_neutron_data_2D,
                            rebin_neutron_data,focus_neutron_data)
from .abs_ms_nd import correct_carpenter,calculate_carpenter
from .peak_nd import strip_peaks_neutron_data,smooth_neutron_data




# def offset_neutron_data(dataset,offset_list):
#     dataset["xvalue"] = (dataset["xvalue"].dims,dataset["xvalue"].values*(offset_list[:,np.newaxis]+1))
#     return dataset
#
# def corr_solid_angle(dataset,px,py):
#     #from dataSvc.write_format import write_cal,write_ascii
#     pos = dataset["positions"].values
#     weights=np.zeros([pos.shape[0]])
#     #print("pos size: ",pos.shape[0])
#     for i in range(pos.shape[0]):
#         l2 = np.sqrt(pos[i,0]**2+pos[i,1]**2+pos[i,2]**2)
#         # two_theta = np.arcos(pos[i,2]/l2)
#         weights[i] = px*py*pos[i,2]/l2**3
#         #print("weight: ",weight)
#         #print(dataset["histogram"].values[i,:])
#     #print(weights)
#     #write_ascii("/Users/kobude/solid_dr.txt",weights,format="%.12f")
#     weights = weights/np.max(weights)
#     #print(weights.shape)
#     dataset["histogram"].values = dataset["histogram"].values/weights[:, np.newaxis]
#     return dataset
#
# def corr_radial_weight(dataset,q_new):
#     #import matplotlib.pyplot as plt
#     x_arr = dataset["xvalue"].values
#     hist = dataset["histogram"].values
#     #x_arr = x_arr[:,1:]
#     #hist = hist[:,1:]
#     for i in range(x_arr.shape[1]):
#         q_arr = x_arr[:,i]
#         image = hist[:,i]
#         #q_arr = x_arr[i,:]
#         #image = hist[i,:]
#         tbin,edge = np.histogram(q_arr,bins=q_new,weights=image)
#         nr,edge = np.histogram(q_arr,bins=q_new)
#         radialprofile = tbin/nr
#         # sys.exit()
#         if i == 0:
#             data_tbin = tbin.copy()
#             data_nr = nr.copy()
#             # data = radialprofile.copy()
#         else:
#             data_tbin += tbin.copy()
#             data_nr += nr.copy()
#     radialprofile = data_tbin/data_nr
#     q_real = edge[:-1]
#     return edge[:-1]+0.5*(edge[1]-edge[0]),data_tbin, radialprofile
#
#
#
#
#
# def move_instrument(dataset, x_offset=0, y_offset=0, z_offset=0):
#     pos = dataset["positions"].values
#     pos[:,0] += x_offset/1000
#     pos[:,1] += y_offset/1000
#     pos[:,2] += z_offset/1000
#     return dataset
#
# def cal_trans_neutron_data(data_sam,data_eb,useM2=True):
#     x = data_sam["xvalue"].values
#     if np.array_equal(x[0,:],x[1,:]):
#         y_sam = data_sam["histogram"].values
#         y_eb = data_eb["histogram"].values
#         if useM2:
#             trans_sam = y_sam[1,:]/y_sam[0,:]
#             trans_eb = y_eb[1,:]/y_eb[0,:]
#         else:
#             trans_sam = y_sam[1,:]/data_sam["proton_charge"].values
#             trans_eb = y_eb[1,:]/data_eb["proton_charge"].values
#         trans = trans_sam/trans_eb
#         #x_new,trans_new = mask_nan(x[0,:],trans)
#         return trans
#
#     else:
#         raise ValueError("dataset should be rebinned first")
#
# def corr_transimission(dataset,trans):
#     mask = ~np.isnan(trans)  # 创建一个布尔掩码，标记非NaN值的位置
#     #x_filtered = x[mask]  # 应用掩码，
#     pos = dataset["positions"].values
#     # pos = dataset["positions"].values
#     pixel = dataset['positions'].coords['pixel'].values
#     l,theta =get_l_theta(dataset["l1"].values,pos[:,0],
#                         pos[:,1],pos[:,2],False)
#     xold = dataset["xvalue"].values[0][mask]
#     xnew = pos = dataset["positions"].values
#     pixel = dataset['positions'].coords['pixel'].values
#     y = dataset["histogram"].values
#     e = dataset["error"].values
#     correctY = np.zeros([y.shape[0],xold.size])
#     correctE = np.zeros([e.shape[0],xold.size])
#     for i in range(theta.size):
#         exp_term = 0.5/(np.cos(2*theta[i]))+0.5
#         tmp = trans**(-1*exp_term)
#         correctY[i,:] = tmp[mask]
#         #correctE[i,:] = abs()
#
#     xnew = np.tile(xold,(y.shape[0],1))
#     print(correctY.shape,correctE.shape,xnew.shape)
#     new_dataset = create_dataset(correctY,correctE,xnew,pixel,pos,
#                         dataset['proton_charge'],dataset['l1'])
#     return new_dataset
