import numpy as np

from rongzai.utils.constants import *
from rongzai.algSvc.base.core_unitconvert import *
from rongzai.algSvc.neutron import check_reverse_neutron_data
from rongzai.utils import generate_x
from .cppkernels_nd import rebin_neutron_data


def convert_unit_elastic(dataset, target_unit,align_bin = False):
    """通用单位转换函数"""
    current_unit = dataset.attrs.get("x_unit")
    if not current_unit:
        raise ValueError("No unit in neutron data")
    if current_unit == target_unit:
        return dataset
    converter = UnitConvertNeutronData()
    dataset = converter.run(dataset, target_unit)
    if align_bin:
        x = dataset["xvalue"].values
        max_x = np.max(x)
        min_x = np.min(x)
        num = x.shape[1]
        x_new = generate_x(min_x,max_x,num)
        return rebin_neutron_data(dataset,x_new)
    else:
        return dataset

def convert_unit_inelastic(dataset, ei, target_unit):
    """通用单位转换函数"""
    current_unit = dataset.attrs.get("x_unit")
    if not current_unit:
        raise ValueError("No unit in neutron data")

    if current_unit == target_unit:
        return dataset

    converter = UnitConvertNeutronData("inelastic",ei)
    return converter.run(dataset, target_unit)

class UnitConvertNeutronData():
    def __init__(self, mode='elastic',Efix = 0):
        self.mode = mode
        self.efix = Efix

    def run(self, dataset, unit_out):
        self.l1 = dataset["l1"].values
        # print(self.l1,type(self.l1))
        pos = dataset["positions"].values
        self.l2 = pos[:,3]
        # print(self.l2,type(self.l2))
        self.theta = pos[:,4] / 360 * np.pi
        name = dataset.attrs.get("name",None)
        self.isMonitor = False
        if name[:7].lower() == "monitor":
            self.isMonitor = True

        unit_in = dataset.attrs.get("x_unit",None)
        if unit_in == unit_out:
            raise Exception("Error: same units")
        method_name = f"{unit_in}_to_{unit_out}"
        method = getattr(self,method_name)
        x_old = dataset["xvalue"].values
        x_new = method(x_old)
        result = dataset.copy()
        result["xvalue"].values = x_new
        result.attrs["x_unit"] = unit_out
        result["xvalue"].attrs.update({"unit": units_match[unit_out]})

        return check_reverse_neutron_data(result)


    def tof_to_dspacing(self,x):
        return tof_to_dspacing(x, self.l1, self.l2[:,np.newaxis], self.theta[:,np.newaxis], self.mode)

    def tof_to_wavelength(self, x):
        return tof_to_wavelength(x,self.l1, self.l2[:,np.newaxis], self.mode, self.efix,self.isMonitor)

    def wavelength_to_tof(self, x):
        return wavelength_to_tof(x, self.l1, self.l2[:,np.newaxis], self.mode, self.efix, self.isMonitor)


    def tof_to_deltaE(self,x):
        return tof_to_deltaE(x, self.efix,self.l1, self.l2[:,np.newaxis], self.mode)

    def tof_to_energy(self,x):
        return tof_to_energy(x, self.efix,self.l1, self.l2[:,np.newaxis], self.mode, self.isMonitor)

    def energy_to_tof(self,x):
        return energy_to_tof(x,self.l1, self.l2[:,np.newaxis], self.mode, self.efix,self.isMonitor)

    def dspacing_to_q(self,x):
        return dspacing_to_q(x)

    def dspacing_to_tof(self, x):
        return dspacing_to_tof(x,self.l1,self.l2[:,np.newaxis],self.theta[:,np.newaxis],self.mode)

    def q_to_dspacing(self,x):
        return q_to_dspacing(x)

    def wavelength_to_dspacing(self, x):
        return wavelength_to_dspacing(x,self.theta[:,np.newaxis])
    #     if self.mode == "elastic":
    #         return x / (2 * np.sin(self.theta[:,np.newaxis]))
    # #
    # def dspacing_to_q(self,x):
    #     if self.mode == "elastic":
    #         return 2*np.pi/x
    #
    # def dspacing_to_wavelength(self, x):
    #     if self.mode == "elastic":
    #         return x * 2 * np.sin(self.theta[:,np.newaxis])
    #
    # def tof_to_energy(self,x):
    #     if self.mode == "elastic":
    #         return half_neutron_mass_factor*self.l[:,np.newaxis]**2/x**2
    #     else:
    #         l2 = self.l[:,np.newaxis] - self.l1
    #         t1 = np.sqrt(half_neutron_mass_factor*self.l1**2/self.efix)*1e6
    #         t2 = x-t1
    #         return half_neutron_mass_factor*l2**2/t2**2
    #
    # def tof_to_deltaE(self,x):
    #     if self.mode == "elastic":
    #         raise Exception("error for the mode")
    #     else:
    #         l2 = self.l - self.l1
    #         t1 = np.sqrt(half_neutron_mass_factor*self.l1**2/self.efix) * 1e6
    #         t2 = x - t1
    #         e2 = half_neutron_mass_factor*l2[:,np.newaxis]**2/(t2 * 1e-6)**2
    #         return self.efix - e2

    #
    # def tof_to_energy(self,time_of_flight):
    #     #unit is meV
    #     #print(time_of_flight,self.flight_distance)
    #     tof = time_of_flight/1000
    #     #for i in range()
    #     return 10*1.675/3.2*(self.flight_distance/tof)**2
    #     #return 10*neutron_mass*1e27/3.2*(self.flight_distance/tof)**2
    #
    # def velocity_to_wavelength(self, velocity):
    #     """将速度转换为波长。"""
    #     return self.h_m_n / velocity
