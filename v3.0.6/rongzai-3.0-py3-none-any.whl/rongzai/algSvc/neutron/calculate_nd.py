import numpy as np
from rongzai.algSvc.base import rebin
from rongzai.dataSvc import create_dataset

def calculate_neutron_data(op, dataset1, dataset2):
    operations = {
        'add': CalculateNeutronData.add,
        'subtract': CalculateNeutronData.subtract,
        'divide': CalculateNeutronData.divide
    }
    return operations[op](CalculateNeutronData(dataset1, dataset2))

class CalculateNeutronData:
    def __init__(self, dataset_left, dataset_right):
        self.dataset_left = dataset_left
        self.dataset_right = dataset_right
        self._check_units()
        self._check_shape()

    def _check_units(self):
        unit_left = self.dataset_left.attrs.get("x_unit", None)
        unit_right = self.dataset_right.attrs.get("x_unit", None)

        if unit_left is None or unit_right is None:
            raise ValueError("数据集中的 x_unit 为 None，数据有问题，程序终止。")
        if unit_left != unit_right:
            raise ValueError(f"单位不一致：左侧数据集的单位为 '{unit_left}'，右侧数据集的单位为 '{unit_right}'。数据有问题，程序终止。")

    def _check_shape(self):
        shape_left = self.dataset_left["histogram"].shape
        shape_right = self.dataset_right["histogram"].shape
        if shape_left[0] != shape_right[0]:
            raise ValueError(f"数据集探测器形状不一样，左侧数据集为{shape_left[0]}, 右侧数据集为{shape_right[0]}")

    def _remove_nan_inf(self, data, error, x_value):
        mask = ~(np.isnan(data) | np.isinf(data))
        clean_data = data[mask]
        clean_error = error[mask]
        clean_x = x_value[mask]
        return clean_data, clean_error, clean_x
    def add(self):
        return self._operation(np.add)
    def subtract(self):
        return self._operation(np.subtract)

    def divide(self):
        return self._operation(np.divide)

    def _operation(self, operation):
        y_right = self.dataset_right["histogram"].values
        e_right = self.dataset_right["error"].values
        x_right = self.dataset_right["xvalue"].values

        y_left = self.dataset_left["histogram"].values
        e_left = self.dataset_left["error"].values
        x_left = self.dataset_left["xvalue"].values

        # 初始化结果数组
        data_new = np.zeros_like(y_left)
        error_new = np.zeros_like(data_new)
        x_arr_new = np.zeros_like(data_new)

        # 对每一行数据进行运算
        for i in range(x_left.shape[0]):
            x_old_left = x_left[i, :]
            y_old_left = y_left[i, :]
            e_old_left = e_left[i, :]

            x_old_right = x_right[i, :]
            y_old_right = y_right[i, :]
            e_old_right = e_right[i, :]
            # 判断是否需要 rebin
            if not np.array_equal(x_old_left, x_old_right):
                y_rebin_left, e_rebin_left = y_old_left, e_old_left
                y_rebin_right, e_rebin_right = rebin(x_old_right, y_old_right, e_old_right, x_old_left)
            else:
                y_rebin_left, e_rebin_left = y_old_left, e_old_left
                y_rebin_right, e_rebin_right = y_old_right, e_old_right

            data_new[i, :] = operation(y_rebin_left, y_rebin_right)
            x_arr_new[i, :] = x_old_left

            # 计算误差（根据运算类型不同，误差计算方式可能不同）
            if operation == np.divide:
                error_new[i, :] = data_new[i, :] * np.sqrt(
                    (e_rebin_left / y_rebin_left) ** 2 + (e_rebin_right / y_rebin_right) ** 2)
            else:
                error_new[i, :] = np.sqrt(e_rebin_left ** 2 + e_rebin_right ** 2)

            # 去除 NaN 和 Inf
        clean_data, clean_error, clean_x = self._remove_nan_inf(data_new, error_new, x_arr_new)

        # 创建新的 dataset
        pos = self.dataset_left["positions"].values
        pixel = self.dataset_left['positions'].coords['pixel'].values
        proton_charge = self.dataset_left['proton_charge'].values
        l1 = self.dataset_left['l1'].values
        name = self.dataset_left.attrs.get("name")
        unit = self.dataset_left.attrs.get("x_unit")

        dataset = create_dataset(clean_data, clean_error, clean_x, pixel, pos, proton_charge, l1, name, unit)
        return dataset

