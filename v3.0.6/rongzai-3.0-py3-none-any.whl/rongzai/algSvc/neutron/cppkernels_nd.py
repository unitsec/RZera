import numpy as np
import ctypes
from rongzai.dataSvc import create_dataset
from rongzai.utils.helper import getRZeraLib
from rongzai.algSvc.base import rebin,rebin_2D

def group_neutron_data(dataset,pixels_per_tube,group_along_tube,group_cross_tube):
    rzlib = getRZeraLib()
    group_data = rzlib.group_nd
    group_data.argtypes = [
        ctypes.c_size_t, ctypes.c_size_t,
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),
        ctypes.c_int, ctypes.c_int, ctypes.c_int,ctypes.POINTER(ctypes.c_size_t),
        np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
        np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS')
    ]
    position = dataset["positions"].values.astype(np.float64, order='C')
    pixels = dataset["positions"].coords["pixel"].values.astype(np.float64, order='C')
    x_array = dataset["xvalue"].values.astype(np.float64, order='C')
    y_array = dataset["histogram"].values.astype(np.float64, order='C')
    e_array = dataset["error"].values.astype(np.float64, order='C')
    name = dataset.attrs.get('name', None)
    x_unit = dataset.attrs.get("x_unit", None)
    l1 = dataset["l1"]
    pc = dataset["proton_charge"]

    rows, cols = x_array.shape
    final_x = np.zeros((rows, cols), dtype=np.float64, order='C')
    final_y = np.zeros((rows, cols), dtype=np.float64, order='C')
    final_e = np.zeros((rows, cols), dtype=np.float64, order='C')
    final_pos = np.zeros((rows, 8), dtype=np.float64, order='C')
    final_pixel = np.zeros(rows, dtype=np.float64, order='C')
    final_size = ctypes.c_size_t(0)
    group_data(rows,cols,
        x_array,y_array, e_array, position, pixels,
       pixels_per_tube, group_along_tube, group_cross_tube,ctypes.byref(final_size),
        final_x, final_y, final_e, final_pos, final_pixel
    )

    final_x = final_x[:final_size.value, :]
    final_y = final_y[:final_size.value, :]
    final_e = final_e[:final_size.value, :]
    final_pos = final_pos[:final_size.value, :]
    final_pixel = final_pixel[:final_size.value]

    dataset = create_dataset(final_y, final_e, final_x, final_pixel, final_pos, pc, l1, module=name, unit=x_unit)
    return dataset

def rebin_neutron_data(dataset,xnew):
    ## process 1D and 2D
    xarr = dataset["xvalue"].values
    yarr = dataset["histogram"].values
    earr = dataset["error"].values
    ynew_2d = np.zeros((yarr.shape[0], len(xnew)))
    enew_2d = np.zeros_like(ynew_2d)

    for i in range(yarr.shape[0]):
        ynew_2d[i], enew_2d[i] = rebin(xarr[i],yarr[i],earr[i],xnew)
    xnew_2d = np.tile(xnew, (ynew_2d.shape[0],1))
    pos = dataset["positions"].values
    pixel = dataset['positions'].coords['pixel'].values
    module = dataset.attrs.get("name", None)
    unit = dataset.attrs.get("x_unit", None)
    return create_dataset(
        ynew_2d, enew_2d, xnew_2d, pixel, pos,
        dataset['proton_charge'], dataset['l1'],
        module=module, unit=unit
    )

def rebin_neutron_data_2D(dataset,xnew):
    ## only process 2D
    xarr = dataset["xvalue"].values
    yarr = dataset["histogram"].values
    earr = dataset["error"].values
    y_new, e_new = rebin_2D(xarr,yarr,earr,xnew)
    x_data = np.tile(xnew, (y_new.shape[0], 1))
    pos = dataset["positions"].values
    pixel = dataset['positions'].coords['pixel'].values
    module = dataset.attrs.get("name", None)
    unit = dataset.attrs.get("x_unit", None)
    return create_dataset(
        y_new, e_new, x_data, pixel, pos,
        dataset['proton_charge'], dataset['l1'],
        module=module, unit=unit
    )

def focus_neutron_data(dataset,xnew):
    # import time
    # be = time.time()
    if dataset["histogram"].values.ndim != 2:
        raise ValueError("input data histogram must be 2D")
    xarr = dataset["xvalue"].values
    if xnew is None:
        x_min = np.nanmin(xarr[:,0])
        x_max = np.nanmax(xarr[:,-1])
        step = xarr[0,1] - xarr[0,0]
        xnew = np.arange(x_min,x_max,step)

    yarr = dataset["histogram"].values
    earr = dataset["error"].values
    # print(xnew.size)
    y_new, e_new = rebin_2D(xarr,yarr,earr,xnew)
    y_sum = np.sum(y_new, axis=0)
    e_sum = np.sqrt(np.sum(e_new**2, axis=0))

    pos = dataset["positions"].values[0]
    pixel = dataset['positions'].coords['pixel'].values[0]
    name = dataset.attrs.get("name")
    unit = dataset.attrs.get("x_unit")
    data = create_dataset(y_sum,e_sum,xnew,pixel,pos,
                        dataset['proton_charge'],dataset['l1'],name,unit=unit)
    # print("time focus:",time.time()-be,"seconds")
    return data