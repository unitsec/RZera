import numpy as np
from rongzai.utils.constants import FACTOR_MP, half_neutron_mass_factor
'''
单位： tof = us, energy = meV, theta=散射角一半，rad单位

tof --> wavelength: 需要判断monitor
wavelength --> tof: 需要判断monitor
tof --> energy: 需要判断monitor
energy --> tof: 需要判断monitor


'''

def tof_to_wavelength(tof, l1, l2, mode, ei, isMonitor):
    l = l1 + abs(l2)
    if isMonitor:
        l = l1 + l2
    if mode == "elastic":
        return 2 / FACTOR_MP * tof / l
    elif mode == "inelastic":
        t1 = np.sqrt(half_neutron_mass_factor * l1**2 / ei) * 1e6
        t2 = tof - t1
        return 2 / FACTOR_MP * t2 / l2
    else:
        raise Exception(f"Error in Mode {mode}")

def wavelength_to_tof(wave,l1,l2, mode, ei, isMonitor):
    l = l1 + abs(l2)
    if isMonitor:
        l = l1 + l2
    if mode == "elastic":
        return l * wave * 0.5 * FACTOR_MP
    elif mode == "inelastic":
        pass
    else:
        raise Exception(f"Error in Mode {mode}")

def tof_to_energy(tof,ei,l1, l2 , mode, isMonitor):
    if isMonitor:
        ##监视器有l2 < 0和l2 >0 两种情况
        l_total = l1 + l2
    else:
        l_total = l1 + abs(l2)
    if mode == "elastic":
        t_s = tof * 1e-6 #单位转换成s
        # print(l_total,tof)
        # print("v=",l_total/tof)
        return half_neutron_mass_factor * l_total**2 / t_s**2
    elif mode == "inelastic":
        t1 = np.sqrt(half_neutron_mass_factor * l1**2 / ei) * 1e6
        # print("cal t1: ",t1)
        # print("v1=",l1/t1)
        t2 = tof - t1
        # print("t2: ",t2)
        # print("l2:",l2)
        # print("v=", l2 / t2)
        t_s = t2 * 1e-6
        # print("t_s:",t_s)

        # print("hf:",half_neutron_mass_factor)
        a = half_neutron_mass_factor * l2**2 / t_s**2
        # print("res: ",a)
        return half_neutron_mass_factor * l2**2 / t_s**2
    else:
        raise Exception(f"Error in Mode {mode}")

def energy_to_tof(en,ei,l1, l2, mode,isMonitor):
    '''
    参数:
    - l1: 第一段路径长度（单位：米）
    - l2: 第二段路径长度（单位：米），在非弹性散射模式下使用
    - ei: 入射能量（单位：meV），在非弹性散射模式下使用
    - en: 出射能量（单位：meV）
    - mode: 模式，"elastic"
    或
    "inelastic"
    - isMonitor: 是否是监视器
    '''

    #计算飞行总路径
    if isMonitor:
        ##监视器有l2 < 0和l2 >0 两种情况
        l_total = l1 + l2
    else:
        l_total = l1 + abs(l2)

    ###计算飞行时间
    if mode == "elastic":
        return np.sqrt(half_neutron_mass_factor * l_total**2 / en) * 1e6
    elif mode == "inelastic":
        t2 = np.sqrt(half_neutron_mass_factor * l2**2 / en) * 1e6
        t1 = np.sqrt(half_neutron_mass_factor * l1**2 / ei) * 1e6
        return t1 + t2
    else:
        raise Exception(f"Error in Mode {mode}")

def tof_to_dspacing(tof, l1, l2,theta,mode):
    if mode == "elastic":
        # print("param:",tof,l1,l2[0],theta[0])
        return tof / FACTOR_MP / (l1 + l2) / np.sin(theta)
    elif mode == "inelastic":
        pass
    else:
        raise Exception(f"Error in Mode {mode}")

def dspacing_to_tof(d,l1,l2,theta, mode):
    if mode == "elastic":
        return d * FACTOR_MP * (l1+l2) * np.sin(theta)
    elif mode == "inelastic":
        pass
    else:
        raise Exception(f"Error in Mode {mode}")

def dspacing_to_q(d):
    return 2 * np.pi / d

def q_to_dspacing(q):
    return 2 * np.pi / q


def wavelength_to_dspacing(wave, theta):
    return 0.5 * wave / np.sin(theta)


def wavelength_to_q(wave,theta):
    return 4 * np.pi * np.sin(theta) / wave

def tof_to_deltaE(tof, ei, l1, l2, mode):
    if mode == "elastic":
        raise Exception(" mode must be inelastic")
    elif mode == "inelastic":
        en = tof_to_energy(tof,ei,l1,l2,"inelastic",False)
        return ei - en
    else:
        raise Exception(f"Error in Mode {mode}")

def spe_to_sqw(ei, delta_e, theta):
    ef = ei - delta_e
    wave_i = np.sqrt(81.81 / ei)
    wave_o = np.sqrt(81.81 / ef)
    ki = 2*np.pi/wave_i
    kf = 2*np.pi/wave_o
    q = np.sqrt(ki ** 2 + kf ** 2 - 2 * ki * kf * np.cos(theta))
    return q