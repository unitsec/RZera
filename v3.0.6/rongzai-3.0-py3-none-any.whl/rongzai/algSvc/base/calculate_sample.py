# import numpy as np
import re
from rongzai.utils.constants import *

def get_sample_properties(conf):
    #### when calculate atten_xs, it will divide 1.81 in the class!!!
    task = CalSampleProperty(conf)
    task.cal_all()
    return {attr: getattr(task, attr) for attr in [
        "atten_xs", "scatt_xs", "coh_xs", "inc_xs", "b_avg_sqrd",
        "b_sqrd_avg", "density_num", "atom_num", "v_factor", "radius", "scale"
    ]}


class CalSampleProperty:
    #计算该样品的中子相关的属性值
    def __init__(self, samConf=None):
        self.samConf = samConf
        self.set_params_zero()

    def set_params_zero(self):
        self.atten_xs = 0.0
        self.scatt_xs = 0.0
        self.coh_xs = 0.0
        self.inc_xs = 0.0
        self.b_avg_sqrd = 0.0
        self.b_sqrd_avg = 0.0
        self.density_num = 0.0
        self.atom_num = 0.0
        self.v_factor = 0.0
        self.radius = self.samConf["volume"]["radius"] if self.samConf["volume"]["thickness"] == 0 else self.samConf["volume"]["thickness"]*0.5
        self.scale = self.samConf["scale"]

    def cal_beam_volume(self):
        if self.samConf["volume"]["type"]=="cylinder":
            height = self.samConf["volume"]["height"]
            radius = self.samConf["volume"]["radius"]
            if self.samConf["volume"]["beam_height"]>height:
                volume = np.pi*radius**2*height
            else:
                volume = np.pi*radius**2*self.samConf["volume"]['beam_height']
            return volume
        else:
            height = self.samConf["volume"]["height"]
            thickness = self.samConf["volume"]["thickness"]
            width = self.samConf["volume"]["width"]
            if self.samConf["volume"]["beam_height"]>height:
                volume = width * thickness * height
            else:
                volume = width * thickness * self.samConf["volume"]['beam_height']
            return volume

    def cal_sample_volume(self):
        if self.samConf["volume"]["type"] == "cylinder":
            height = self.samConf["volume"]["height"]
            radius = self.samConf["volume"]["radius"]
            volume = np.pi * radius ** 2 * height
            return volume
        else:
            height = self.samConf["volume"]["height"]
            thickness = self.samConf["volume"]["thickness"]
            width = self.samConf["volume"]["width"]
            volume = width * thickness * height
            return volume

    def cal_density(self):
        v = self.cal_sample_volume()
        return self.samConf["mass"]/v

    def cal_element_ratio(self):
        sample = self.samConf["sample_name"].split('-')
        data = {}
        numbers = re.findall(r'[-+]?\d*\.\d+|\d+', self.samConf["sample_name"])
        total_sum = sum(float(number) for number in numbers)
        for i in range(len(sample)):
            tmp = sample[i].split(":")
            data[tmp[0]] = float(tmp[1])/total_sum
        return data

    def cal_molar_mass(self):
        ele_ratio = self.cal_element_ratio()
        molar_mass = 0.0
        for key in ele_ratio:
            molar_mass += float(elements_nist[key]["molarMass"])*ele_ratio[key]
        return molar_mass

    def cal_v_factor(self):
        volume = self.cal_beam_volume()
        return self.density_num * volume /4 /np.pi * self.scatt_xs


    def cal_all(self):
        self.set_params_zero()
        ele_ratio = self.cal_element_ratio()
        for key in ele_ratio:
            self.atten_xs += float(elements_nist[key]["Abs_xs"])/1.81 * ele_ratio[key]
            self.scatt_xs += float(elements_nist[key]["Scatt_xs"])*ele_ratio[key]
            self.coh_xs += float(elements_nist[key]["Coh_xs"])*ele_ratio[key]
            self.inc_xs += float(elements_nist[key]["Inc_xs"])*ele_ratio[key]
        self.b_avg_sqrd = self.inc_xs/4./np.pi
        self.b_sqrd_avg = self.coh_xs/4./np.pi
        if self.samConf.get("density_num",None) is None:
            self.density_num = 0.1*self.cal_density()/self.cal_molar_mass()*6.02
        else:
            self.density_num = self.samConf["density_num"]
        self.atom_num = self.density_num*self.cal_beam_volume()
        if "V" in self.samConf["sample_name"]:
            self.v_factor = self.cal_v_factor()
