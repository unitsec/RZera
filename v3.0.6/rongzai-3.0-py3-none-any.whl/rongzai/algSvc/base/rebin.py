from rongzai.utils.helper import getRZeraLib
from rongzai.utils.array_utils import (change_point_to_boundary_2D,
                               change_point_to_boundary)
from scipy.interpolate import interp1d
import numpy as np
import ctypes
from ctypes import c_double, c_size_t, POINTER


def rebin_2D(x_old, y_old, e_old, x_new):
    rzlib = getRZeraLib()
    rebin_2D = rzlib.rebin_2D
    rebin_2D.argtypes = [
        ctypes.c_size_t,  # rows
        ctypes.c_size_t,  # old_cols
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # x_old
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # y_old
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # e_old
        ctypes.c_size_t,  # new_cols
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # x_new
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # y_new
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS')  # e_new
    ]

    x_old_boundary = change_point_to_boundary_2D(x_old)

    rows = y_old.shape[0]
    input_size = y_old.shape[1]

    input_x = np.ascontiguousarray(x_old_boundary, dtype=np.float64)
    input_y = np.ascontiguousarray(y_old, dtype=np.float64)
    input_e = np.ascontiguousarray(e_old, dtype=np.float64)

    x_new_boundary = change_point_to_boundary(x_new)
    output_size = len(x_new)
    output_x = np.ascontiguousarray(x_new_boundary, dtype=np.float64)
    output_y = np.ascontiguousarray(np.zeros((rows, output_size), dtype=np.float64))
    output_e = np.ascontiguousarray(np.zeros((rows, output_size), dtype=np.float64))

    # print(f"input_size:{input_size},x_old:{x_old.shape},input_x:{input_x.shape}")
    # print(f" output_y: {output_y.shape}, output_e:{output_e.shape} input_y:{input_y.shape}, input_e:{input_e.shape}")
    # print(f"output_size:{output_size},x_new:{x_new.shape},output_x:{output_x.shape}")
    # # 调用rebin_2D
    rebin_2D(
        ctypes.c_size_t(rows),
        ctypes.c_size_t(input_size),
        input_x,
        input_y,
        input_e,
        ctypes.c_size_t(output_size),
        output_x,
        output_y,
        output_e
    )
    # print(f"finsih rebin_2D: output_e:{output_e.shape}")
    return np.array(output_y), np.sqrt(np.array(output_e))

def rebin(x_old, y_old, e_old, x_new):
    rzlib = getRZeraLib()
    rzlib.rebin.argtypes = [
        ctypes.c_size_t,  # input_size
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # input_x
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # input_y
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # input_e
        ctypes.c_size_t,  # output_size
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # output_x
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # output_y
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS')  # output_e
    ]

    x_old_boundary = change_point_to_boundary(x_old)
    input_size = len(x_old_boundary)
    input_x = np.ascontiguousarray(x_old_boundary, dtype=np.float64)
    input_y = np.ascontiguousarray(y_old, dtype=np.float64)
    input_e = np.ascontiguousarray(e_old, dtype=np.float64)

    x_new_boundary = change_point_to_boundary(x_new)
    output_size = len(x_new_boundary)
    output_x = np.ascontiguousarray(x_new_boundary, dtype=np.float64)
    output_y = np.zeros(output_size - 1, dtype=np.float64)
    output_e = np.zeros(output_size - 1, dtype=np.float64)

    rzlib.rebin(
        ctypes.c_size_t(input_size),
        input_x,
        input_y,
        input_e,
        ctypes.c_size_t(output_size),
        output_x,
        output_y,
        output_e
    )
    '''
    ##注意c++里面误差是这样算的：
    e_new[inew] += e_old[iold] * e_old[iold] * delta / width;
    数值稳定性更好（方差累加更精确）
    所以python在返回中需要np.sqrt
    '''
    return np.array(output_y), np.sqrt(np.array(output_e))


def interpolate(x_old, y_old, e_old, x_new, kind='linear'):
    """
    对数据进行插值，并计算插值后的误差。

    参数:
        x_old (np.array): 原始数据的 x 值。
        y_old (np.array): 原始数据的 y 值。
        e_old (np.array): 原始数据的误差。
        x_new (np.array): 插值点的 x 值。
        kind (str): 插值方法，默认为 'linear'。

    返回:
        y_new (np.array): 插值后的 y 值。
        e_new (np.array): 插值后的误差。
    """
    # 插值函数
    f = interp1d(x_old, y_old, kind=kind, fill_value='extrapolate')
    y_new = f(x_new)

    # 计算插值后的误差
    e_new = np.zeros_like(x_new)
    for i, x in enumerate(x_new):
        # 找到插值点的相邻点
        idx = max(0, min(np.searchsorted(x_old, x) - 1, len(x_old) - 2))
        x0, x1 = x_old[idx], x_old[idx + 1]
        y0_err, y1_err = e_old[idx], e_old[idx + 1]

        # 计算插值权重
        w0 = (x1 - x) / (x1 - x0)
        w1 = (x - x0) / (x1 - x0)

        # 计算插值后的误差
        e_new[i] = np.sqrt((w0 * y0_err) ** 2 + (w1 * y1_err) ** 2)

    return y_new, e_new
