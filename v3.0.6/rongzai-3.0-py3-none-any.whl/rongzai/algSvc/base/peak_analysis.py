from scipy.signal import find_peaks
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve
import numpy as np
from scipy.optimize import minimize,curve_fit
# from .fit import fit_single_peak
from rongzai.utils.defined_functions import gaussian,asymmetric_gaussian

def __sst(y_no_fitting):
    """
    计算SST(total sum of squares) 总平方和
    :param y_no_predicted: List[int] or array[int] 待拟合的y
    :return: 总平方和SST
    """
    y_mean = sum(y_no_fitting) / len(y_no_fitting)
    s_list =[(y - y_mean)**2 for y in y_no_fitting]
    sst = sum(s_list)
    return sst

def __ssr(y_fitting, y_no_fitting):
    """
    计算SSR(regression sum of squares) 回归平方和
    :param y_fitting: List[int] or array[int]  拟合好的y值
    :param y_no_fitting: List[int] or array[int] 待拟合y值
    :return: 回归平方和SSR
    """
    y_mean = sum(y_no_fitting) / len(y_no_fitting)
    s_list =[(y - y_mean)**2 for y in y_fitting]
    ssr = sum(s_list)
    return ssr


def __sse(y_fitting, y_no_fitting):
    """
    计算SSE(error sum of squares) 残差平方和
    :param y_fitting: List[int] or array[int] 拟合好的y值
    :param y_no_fitting: List[int] or array[int] 待拟合y值
    :return: 残差平方和SSE
    """
    s_list = [(y_fitting[i] - y_no_fitting[i])**2 for i in range(len(y_fitting))]
    sse = sum(s_list)
    return sse

def goodness_of_fit(y_fitting, y_no_fitting):
    """
    计算拟合优度R^2
    :param y_fitting: List[int] or array[int] 拟合好的y值
    :param y_no_fitting: List[int] or array[int] 待拟合y值
    :return: 拟合优度R^2
    """
    SSR = __ssr(y_fitting, y_no_fitting)
    SST = __sst(y_no_fitting)
    rr = SSR /SST
    return rr


def strip_peaks(x,y,peaks,range):
    data = y.copy()
    for i, peak in enumerate(peaks):
        index = np.argmin(np.abs(x - peak))
        left_edge = x[index] - range[i][0] #确定左侧边缘的d值
        right_edge = x[index] + range[i][1] #确定右侧边缘的d值

        # 找到数据点中离左侧边缘值最近的数据点
        left = np.argmin(np.abs(x - left_edge))
        x0, y0 = x[left], y[left]
        # 找到数据点中离右侧边缘值最近的数据点
        right = np.argmin(np.abs(x - right_edge))
        x1, y1 = x[right], y[right]

        m = (y1 - y0) / (x1 - x0)
        b = y0 - m * x0
        x_interp = x[left:right+1]
        y_interp = m * x_interp + b
        data[left:right+1] = y_interp
    return data
def baseline_alg(y, lam=1e5, p=0.01, niter=10):
    L = len(y)
    D = diags([1, -2, 1], [0, -1, -2], shape=(L, L-2))
    w = np.ones(L)
    for i in range(niter):
        W = diags(w, 0, shape=(L, L))
        Z = W + lam * D.dot(D.transpose())
        z = spsolve(Z, w * y)
        w = p * (y > z) + (1 - p) * (y < z)
    return z
def auto_extract_peak_data(x, y, peak_center_approx, rel_height,manual_width,search_range):
    peaks, properties = find_peaks(y, height=rel_height)
    kept_peaks = []
    for peak in peaks:
        if np.abs(x[peak] - peak_center_approx) < search_range:
            kept_peaks.append(peak)
    if len(kept_peaks) == 0:
        return False, np.array([]), np.array([])

    target_peak = kept_peaks[np.argmax(y[kept_peaks])] # find the highest peak
    left_ips = x[target_peak]-manual_width
    right_ips = x[target_peak]+manual_width
    peak_indices =  (x >= left_ips) & (x <= right_ips)
    x_peak = x[peak_indices]
    y_peak = y[peak_indices]
    return True, x_peak, y_peak

def fit_single_peak(x_peak, y_peak, fit_function):
    if fit_function == 'asymmetric_gaussian':
        A_guess = max(y_peak)
        x0_guess = x_peak[np.argmax(y_peak)]
        sigma1_guess = (x0_guess - x_peak[np.where(y_peak > A_guess / 2)[0][0]]) / 2
        sigma2_guess = (x_peak[np.where(y_peak > A_guess / 2)[0][-1]] - x0_guess) / 2
        initial_guess = [A_guess, x0_guess, sigma1_guess, sigma2_guess]
        try:
            popt, _ = curve_fit(asymmetric_gaussian, x_peak, y_peak, p0=initial_guess, maxfev=10000)
            x_exp = popt[1]
            return True, x_exp,popt
        except:
            return False, None,None
        #
    elif fit_function == 'gaussian':
        initial_guess = [x_peak[np.argmax(y_peak)], np.std(x_peak), max(y_peak) - min(y_peak), min(y_peak)]
        try:
            popt, _ = curve_fit(gaussian, x_peak, y_peak, p0=initial_guess)
            x_exp = popt[0]
            return True, x_exp, popt
        except:
            return False, None,None
    else:
        return False, None,None

def fit_multiple_peaks(x, y, peaks_position, high_width_para,
                fit_function, goodness_bottom):
    peak = []
    d_position_exp = []
    all_d_peak = []
    all_I_peak = []
    import matplotlib.pyplot as plt

    for idx, d in enumerate(peaks_position):
        is_peak, d_peak, I_peak = auto_extract_peak_data(x, y, d,
                                                         high_width_para[idx][0],
                                                         high_width_para[idx][1],high_width_para[idx][2])
        if is_peak:
            # print(is_peak)
            # plt.plot(d_peak,I_peak,label=str(d))
            # plt.legend()
            # plt.title("extract peaks")
            # plt.show()
            fit_result, d_exp, popt = fit_single_peak(d_peak,I_peak,fit_function)
            if fit_result:
                if popt is None or d_exp <= d_peak.min() or d_exp >= d_peak.max():
                    d_position_exp.append(0)
                    continue

                y_fitted = asymmetric_gaussian(d_peak, *popt) if fit_function == 'asymmetric_gaussian' else gaussian(d_peak, *popt)
                peak.append([d_peak, y_fitted])
                all_d_peak.append(d_peak)
                all_I_peak.append(I_peak)
                if goodness_of_fit(y_fitted, I_peak) > goodness_bottom:
                    d_position_exp.append(d_exp)
                else:
                    d_position_exp.append(0)
            else:
                print(f"An error occurred during fitting:, so skip this peak")
                continue
        else:
            d_position_exp.append(0)
            peak.append([d_peak, I_peak])
            all_d_peak.append(d_peak)
            all_I_peak.append(I_peak)
    return d_position_exp, peak, all_d_peak, all_I_peak