import numpy as np
from scipy.optimize import minimize,curve_fit
from rongzai.utils import mask_nan
from rongzai.utils.defined_functions import linear_func,quadratic_func


def calculate_mse(p, y, x, xfitmin, ycal):
    yfit = np.sum(p * ycal, axis=1)
    chi = y - yfit
    chi = chi[x > xfitmin]
    fitcurve = np.mean(chi**2)
    return fitcurve

def fit_chebyshev(q,qiq,qfitmin,cheby):
    npuse = cheby.shape[1]
    p0 = np.full(npuse,0.1)
    options = {'maxfun': 10000, 'maxiter': 30000}
    result = minimize(
        lambda p: calculate_mse(p, qiq, q, qfitmin, cheby),
        p0, method='Nelder-Mead', options=options)
    p = result.x
    y_fit = np.sum(p * cheby, axis=1)
    fit_result = qiq - y_fit
    return fit_result, y_fit

def linear_fit(x,y):
    x_filtered,y_filtered = mask_nan(x,y)
    coefficients = np.polyfit(x_filtered, y_filtered, 1)
    polynomial = np.poly1d(coefficients)
    y_fit = polynomial(x_filtered)
    return x_filtered,y_fit


def _check_anchor(anchor_point, std, threshold=0.1):
    for i, d in enumerate(std):
        res = np.abs(anchor_point - d)
        if res < threshold:
            return True, i
    print(f'the anchor point {anchor_point} does not exist with the threshold {threshold}.')
    return False, None
def linear_fit_offset(x, y, c1_unoffset, is_c0_0, anchor_point):
    initial_guess = [1, 1]
    mask = 1
    C0 = 0
    C1 = c1_unoffset
    C2 = 0
    std4plot = [0] + x
    if anchor_point is not None and isinstance(anchor_point, float):
        isanchor, anchor_id = _check_anchor(anchor_point, x, threshold=0.1)
        if isanchor is False:
            mask = 0
            y_fitted = linear_func(std4plot, C0, C1)
            return C0,C1,C2,mask, y_fitted
        else:
            if is_c0_0 is True:
                C1 = y[anchor_id] / x[anchor_id]
                C0 = 0.0
            else:
                popt, _ = curve_fit(lambda d, C1: y[anchor_id] + C1 * (d - x[anchor_id]), x, y, p0=initial_guess[1])
                C1 = popt[0]
                C0 = y[anchor_id] - C1 * x[anchor_id]
    else:
        if is_c0_0 is True:
            popt, _ = curve_fit(lambda d, C1: C1 * d, x, y, p0=initial_guess[1])
            C1 = popt[0]
            C0 = 0
        else:
            popt, _ = curve_fit(lambda d, C0, C1: C0 + C1 * d, x,y, p0=initial_guess)
            C0, C1 = popt
    y_fitted = linear_func(std4plot, C0, C1)
    return C0,C1,C2,mask, y_fitted

def quadratic_fit_offset(x, y, c1_unoffset, is_c0_0, anchor_point):
    initial_guess = [1, 40000, 1]
    mask = 1
    C0 = 0
    C1 = c1_unoffset
    C2 = 0
    std4plot = [0] + x
    if anchor_point is not None and isinstance(anchor_point, float):
        isanchor, anchor_id = _check_anchor(anchor_point, x, threshold=0.1)
        if isanchor is False:
            mask_line = 0
            y_fitted = quadratic_func(std4plot, 0.0, c1_unoffset, 0.0)
            return C0,C1,C2,mask, y_fitted
        else:
            if is_c0_0 is True:
                popt, _ = curve_fit(lambda d, c1: c1 * d + ((y[anchor_id] - c1 * x[anchor_id]) / x[anchor_id] ** 2) * d ** 2,x,y, p0=initial_guess[1], maxfev=100000)
                C2 = (y[anchor_id] - popt[0] * x[anchor_id]) / x[anchor_id] ** 2
                C1 = popt[0]
                C0 = 0.0
            else:
                popt, _ = curve_fit(lambda d, c1, c2: (y[anchor_id] - c1 * x[anchor_id] - c2 * x[anchor_id] ** 2) + c1 * d + c2 * d ** 2, x, y, p0=initial_guess[1:3], maxfev=100000)
                C2 = popt[1]
                C1 = popt[0]
                C0 = y[anchor_id] - C2 * (x[anchor_id] ** 2) - C1 * x[anchor_id]
    else:
        if is_c0_0 is True:
            popt, _ = curve_fit(lambda d, c1, c2: c1 * d + c2 * (d ** 2), x, y, p0=initial_guess[1:3])
            C0, C1, C2 = 0.0, popt[0], popt[1]
        else:
            popt, _ = curve_fit(lambda d, C0, C1, C2: C0 + C1 * d + C2 * (d ** 2), x, y, p0=initial_guess)
            C0, C1, C2 = popt
    y_fitted = quadratic_func(std4plot, C0, C1, C2)
    return C0,C1,C2,mask, y_fitted