'''
####### 跟x,y相关的计算，类似于操作numpy.array  ###########
calculate_sample: 计算样品相关信息，包括各种截面与数密度，调用函数get_sample_properties(conf)即可
hermite_prcess: 包括做hermite拟合所需的对data的操作
fit: 各种函数拟合，包括线性非线性，高斯，chebyshev等
peak_analysis: 扣峰，计算背底，自动提取峰
rebin：调用C++库，包括rebin,rebin_2D,interpolate
core_unitconvert:只针对一个pixel的，全部是函数,包括弹性与非弹的转换，还有判断monitor，只写了部分，有需要会继续添加
'''
from .calculate_sample import get_sample_properties
from .hermite_process import (smooth, cal_integral_normlization,
                              data_expansion, convolve_box_function,
                              convolve_instr_hermite_parallel, lorch_filter)
from .rebin import rebin,rebin_2D,interpolate
from .peak_analysis import (baseline_alg,auto_extract_peak_data,strip_peaks,
                            fit_single_peak,fit_multiple_peaks,goodness_of_fit)
from .fit import (quadratic_fit_offset,linear_fit_offset,fit_chebyshev)