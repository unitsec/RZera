from scipy.signal import savgol_filter,convolve
import numpy as np


def data_expansion(x,y):
    dx = x[1]-x[0]
    new_x = np.arange(0, x[0] - dx, dx)
    new_y = new_x * y[0] / x[0]
    ans_x = np.concatenate((new_x, x))
    ans_y = np.concatenate((new_y, y))
    return ans_x, ans_y

def smooth(data,npoint,order):
    return savgol_filter(data, window_length=npoint, polyorder=order)


def cal_integral_normlization(x,y):
    integral = np.trapz(y, x)
    norm = integral / (x[-1] - x[0])
    if norm < 0:
        print("error in cal_integral_normlization")
        norm = 1.0
    return norm


def convolve_box_function(rmax, q, qiq):
    new_qiq = np.zeros_like(qiq)
    for m in range(len(q)):
        for n in range(len(q)):
            b = abs(q[n] - q[m])
            t = q[n] + q[m]
            if n == len(q) - 1:
                dq = abs(q[len(q) - 1] - q[len(q) - 2])
            else:
                dq = abs(q[n + 1] - q[n])
            if b == 0:
                if t == 0:
                    pass
                else:
                    new_qiq[m] += qiq[n] * (rmax - np.sin(t * rmax) / t) * dq
            else:
                new_qiq[m] += qiq[n] * (np.sin(b * rmax) / b - np.sin(t * rmax) / t) * dq
        new_qiq[m] /= np.pi
    return new_qiq

def process_ih(ih,a,c,hermite_matrix,q):
    num = len(q)
    dq = q[1] - q[0]
    sigma = a * np.arange(num) * dq + c
    z = np.zeros((num, num))
    for j in range(num):
        if sigma[j] < 0.01:
            z[:,j] = hermite_matrix[:, ih]
        else:
            qlim = np.floor(10 * sigma[j] / dq) * dq  # 卷积范围，10倍sigma
            x = np.arange(-qlim, qlim + dq, dq)
            y1 = np.exp(-(x ** 2) / (2 * sigma[j] ** 2)) / np.sqrt(2 * np.pi) / sigma[j]
            z[:,j] = convolve(hermite_matrix[:, ih], y1, mode="same") * dq
    result_ih = np.diag(z[:num, :num])
    return result_ih

def convolve_instr_hermite_parallel(a,c,hermite_matrix,nh,q):
    from multiprocessing import Pool
    with Pool() as pool:
        results = pool.starmap(process_ih,[(ih, a, c, hermite_matrix, q) for ih in range(nh)])
    return np.array(results).T

def lorch_filter(x, xfitmax, data):
    lorch_fun = np.sinc(x / xfitmax)
    if data.ndim == 1:
        result = data * lorch_fun
    else:
        result = data * lorch_fun[:, np.newaxis]
    return result