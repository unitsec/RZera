import numpy as np
from numpy.polynomial.chebyshev import chebval
def chebyshev(x, xfitmax, npoly):
    npuse = int(round(npoly * x[-1] / xfitmax))
    ycheb = []
    for n in range(1, npuse + 1):
        cheb_coeff = np.zeros(2 * n)
        cheb_coeff[2 * n - 1] = 1
        ycheb_n = chebval(x / xfitmax, cheb_coeff)
        if n == 1:
            ycheb = ycheb_n[:, np.newaxis]
        else:
            ycheb = np.hstack((ycheb, ycheb_n[:, np.newaxis]))
    return ycheb, npuse


def gaussian(x,center,sigma,height,base):
        #p[0]: center of peak
        #p[1]: sigma
        #p[2]: maximum of peak
        # FWHM = 2*np.sqrt(2*math.log(2))*sigma = 2.35482*sigma
    return (base+height*np.exp(-(x-center)**2.0/(2*sigma**2)))

def lorentzian(x, center, gamma,amplitude, base):
    #gamma is half width
    return base + amplitude*(gamma / np.pi) / ((x - center)**2 + gamma**2)

# def asymmetric_gaussian(x, A, x0, sigma1, sigma2):
#     return np.where(x < x0,
#                     A * np.exp(-0.5 * ((x - x0) / sigma1) ** 2),
#                     A * np.exp(-0.5 * ((x - x0) / sigma2) ** 2))
def asymmetric_gaussian(x, A, x0, sigma1, sigma2, eps=1e-8):
    # 防止 sigma 过小
    s1 = np.clip(sigma1, eps, None)
    s2 = np.clip(sigma2, eps, None)

    x = np.asarray(x, dtype=float)
    y = np.empty_like(x, dtype=float)
    mask = x < x0

    # 只在需要的分段上做除法，避免 np.where 的“同时计算”问题
    z1 = (x[mask] - x0) / s1
    z2 = (x[~mask] - x0) / s2
    y[mask] = A * np.exp(-0.5 * z1**2)
    y[~mask] = A * np.exp(-0.5 * z2**2)
    return y

def fockstate(n, x):
    cs = np.zeros(n + 1)
    cs[-1] = 1
    # 确保 x 是一个向量
    if x.ndim == 1:
        xs = x
    else:
        xs = x.flatten()
    N = len(cs) - 1
    B = np.zeros((len(xs), 2))  # 初始化 B 数组
    logB = np.zeros(len(xs))  # 用于防止溢出的缩放因子
    for n in range(N, -1, -1):
        a = -xs * np.sqrt(2 / (n + 1))  # 计算 a_n
        b = np.sqrt((n + 1) / (n + 2))  # 计算 b_{n+1}
        B_new = cs[n] - a * B[:, 0] - b * B[:, 1]
        F, E = np.frexp(B_new)  # 使用 frexp 进行缩放
        logB += E
        B = np.column_stack((F, B[:, 0] / np.float_power(2, E)))
    y = np.pi**(-1/4) * np.exp(-xs**2 / 2 + np.log(2) * logB) * B[:, 0]
    y = y.reshape(x.shape)
    return y

def quadratic_func(x,C0,C1,C2):
    x = np.array(x)
    return C0 + C1 * x + C2 * (x ** 2)

def linear_func(x, C0, C1):
    x = np.array(x)
    return C0 + C1 * x