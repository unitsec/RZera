import multiprocessing as mp
from multiprocessing import Process
# import threading
from threading import Thread
from time import sleep
import sys
def run_multiprocess_tasks(tasks, sleepTime):
    """
        基于多进程的任务管理器

        使用场景：
        - CPU密集型任务（数据计算、数值处理、机器学习）
        - 需要真正的并行执行（不受GIL限制）
        - 任务之间需要内存隔离，避免相互影响
        - 处理10-100个独立任务

        适用于：数据降维、科学计算、批量处理等场景

        参数：
        tasks: 任务字典，格式为 {任务名: [函数, 参数]}
        sleepTime: 主循环休眠时间
        """
    if len(tasks) == 0:
        sys.exit(0)
    man = ProcessTaskManager(tasks)
    while True:
        if len(man.processes) == 0:
            man.stopProc()
            break
        sleep(sleepTime)


def run_multithread_tasks(tasks, sleepTime):
    """
        基于多线程的任务管理器

        使用场景：
        - I/O密集型任务（网络请求、文件读写、数据库操作）
        - 任务之间需要共享内存数据
        - 需要快速启动大量任务（100+个）
        - 对GIL限制不敏感的任务

        适用于：网络服务、文件处理、并发请求等场景

        参数：
            tasks: 任务字典，格式为{任务名: [函数, 参数]}
            sleepTime: 主循环休眠时间
        """

    if len(tasks) == 0:
        sys.exit(0)
    man = ThreadTaskManager(tasks)
    while True:
        if len(man.threads) == 0:
            man.stopThread()
            break
        sleep(sleepTime)



class ProcessTaskManager:
    def __init__(self, taskList={}, printProc=False):
        self.active = True
        self.stopped = False
        self.printProc = printProc
        self.queue = mp.Queue()

        self.processes = {}
        for taskName, task in taskList.items():
            self.addActiveProc(taskName, task)

        self.houseKeeper = Thread(target=self.houseKeeping)
        self.houseKeeper.start()

    def __del__(self):
        self.active = False
        if hasattr(self, 'houseKeeper'):
            self.houseKeeper.join()

    def addActiveProc(self, taskName, task):
        if type(task) is list:
            print(task)
            if len(task)==2:
                proc = Process(target=task[0], args=task[1]) #to be expended in a thread
            else:
                raise InputError('task should be a list of two elements')
        else:
            proc = Process(target=task)

        proc.daemon = True #fixme: daemon?
        self.processes[taskName] = (proc, task)
        proc.start()

    def stopProc(self):
        self.active=False
        while not self.stopped:
            sleep(0.1)

        for taskName, v in self.processes.items():
            proc = v[0]
            # task = v[1]
            proc.terminate()
            proc.join()

    def houseKeeping(self):
        """监控进程状态，自动重启异常的进程"""
        while len(self.processes) > 0 and self.active:
            self.stopped=False
            for taskName, v in self.processes.items():
                proc = v[0]
                task = v[1]
                if not proc.is_alive():
                    print(proc, task, "is not alive")
                    if proc.exitcode is None:
                        print(proc, task, "never exists, so has not return an exit code")
                        self.addActiveProc(taskName, task)
                    if proc.exitcode != 0:
                        print("exit code", proc.exitcode)
                        proc.join() # Allow tidyup
                        del self.processes[taskName] # Removed finished items from the dictionary
                        self.addActiveProc(taskName, task)
                        print("new process started")
                        break
                    if not proc.exitcode:
                        print("exit gracefully")
                        proc.join() # Allow tidyup
                        del self.processes[taskName] # Removed finished items from the dictionary
                        break
            sleep(1)
            if self.printProc:
                print(self.processes)
        self.stopped=True





class ThreadTaskManager:
    def __init__(self, taskList={}, printProc=False):
        self.active = True
        self.stopped = False
        self.printProc = printProc
        self.threads = {}
        for taskName, task in taskList.items():
            self.addActiveThread(taskName, task)
        self.houseKeeper = Thread(target=self.houseKeeping)
        self.houseKeeper.start()

    def addActiveThread(self, taskName, task):
        if isinstance(task, list):
            thread = Thread(target=task[0], args=task[1])
        else:
            thread = Thread(target=task)
        thread.daemon = True
        self.threads[taskName] = (thread, task)
        thread.start()

    def stopThread(self):
        self.active = False
        while not self.stopped:
            sleep(0.1)
        for taskName, v in self.threads.items():
            thread = v[0]
            thread.join()

    def houseKeeping(self):
        while len(self.threads) > 0 and self.active:
            self.stopped = False
            for taskName, v in self.threads.items():
                thread = v[0]
                task = v[1]
                if not thread.is_alive():
                    print(thread, task, "is not alive")
                    self.addActiveThread(taskName, task)
                    break
            sleep(1)
            if self.printProc:
                print(self.threads)
        self.stopped = True

