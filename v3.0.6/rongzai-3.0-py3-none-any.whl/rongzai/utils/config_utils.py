import json
import os
def expend_conf(conf):
    data = conf.copy()
    nameList = ["sample","sampleBG","v","vBG"]
    for name in nameList:
        item = name + "_run"
        try:
            fnList = [os.path.join(data["data_path"], run, "detector.nxs") for run in data[item]]
        except:
            fnList = []
        data[name + "_fns"] = fnList
    return data

def expend_conf_sans(conf):
    data = conf.copy()
    nameList = ["sample_trans","sample_scat","cell_trans","cell_scat","air_trans"]
    for name in nameList:
        try:
            fnList = [os.path.join(data["data_path"], run, "detector.nxs") for run in data[name]]
        except:
            fnList = []
        data[name + "_fns"] = fnList
    return data

def expend_conf_offset(conf):
    data = conf.copy()
    runs = conf["sample_run"]
    if not isinstance(runs[0],list):
        raise Exception("error: sample_run 必须是双列表形式")
    data["sample_fns"] = []
    for i in range(len(runs)):
        try:
            fnList = [os.path.join(data["data_path"], run, "detector.nxs") for run in runs[i]]
        except:
            fnList = []
        data["sample_fns"].append(fnList)
    return data

def generate_offset_conf(base_conf,offset_conf):
    with open(base_conf, "r") as jf:
        base_configure = json.load(jf)
    with open(offset_conf, "r") as jf:
        params_configure = json.load(jf)
    params_configure = expend_conf_offset(params_configure)
    configure = {**params_configure, **base_configure}
    return configure

def generate_diffraction_conf(base_json,diffraction_json):
    with open(base_json, "r") as jf:
        base_configure = json.load(jf)
    with open(diffraction_json, "r") as jf:
        params_configure = json.load(jf)
        params_configure = expend_conf(params_configure)
    if not params_configure.get("d_rebin", False):
        ### dict2 will overwrite dict1
        configure = {**params_configure, **base_configure}
    else:
        configure = {**base_configure, **params_configure}
    return configure
def generate_pdf_conf(base_json,diffraction_json):
    with open(base_json, "r") as jf:
        base_configure = json.load(jf)
    with open(diffraction_json, "r") as jf:
        params_configure = json.load(jf)
        params_configure = expend_conf(params_configure)
    configure = {**base_configure, **params_configure}
    return configure

def generate_inelastic_conf(base_json,inelastic_json):
    with open(base_json, "r") as jf:
        base_configure = json.load(jf)
    with open(inelastic_json, "r") as jf:
        params_configure = json.load(jf)
        params_configure = expend_conf(params_configure)
    configure = {**base_configure, **params_configure}
    return configure

def generate_sans_conf(base_json,sans_json):
    with open(base_json, "r") as jf:
        base_configure = json.load(jf)
    with open(sans_json, "r") as jf:
        params_configure = json.load(jf)
        params_configure = expend_conf_sans(params_configure)
    configure = {**base_configure, **params_configure}
    return configure
