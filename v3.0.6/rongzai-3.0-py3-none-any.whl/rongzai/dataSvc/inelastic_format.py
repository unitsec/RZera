from rongzai.utils import change_point_to_boundary
import numpy as np
import h5py
import datetime

def _format_change_for_theta(data):
    res = []
    for i in range(len(data)):
        integer_part = int(data[i])
        if integer_part < 1000:
            res.append(f"{data[i]:.1f}")
        else:
            if integer_part % 2 != 0:
                integer_part += 1
            res.append(integer_part)
    return res

def _format_change_for_energy(data):
    res = []
    for i in range(len(data)):
        formatted = f"{data[i]:.4g}"
        if "." in formatted:
            formatted = formatted.rstrip("0").rstrip(".")
        res.append(formatted)
    return res

def _format_change_for_value(data):
    res = []
    for i in range(data.shape[0]):
        row = []
        for j in range(data.shape[1]):
            num = data[i,j]
            formatted = f"{num:.4g}"
            if "." in formatted:
                formatted = formatted.rstrip("0").rstrip(".")
            row.append(formatted)
        res.append(row)
    return res

def save_spe(filename,dataset):
    x = dataset["xvalue"].values[0]
    energy_axis = change_point_to_boundary(x)
    energy_axis_changed = _format_change_for_energy(energy_axis)

    theta = dataset["positions"].values[:,4]
    theta_axis = np.arange(len(theta)+1) + 0.5
    theta_axis_changed = _format_change_for_theta(theta_axis)

    # theta_axis = change_point_to_boundary(theta)
    data_matrix = dataset["histogram"].values
    data_matrix_changed = _format_change_for_value(data_matrix)
    rows, cols = data_matrix.shape
    print(f"data_matrix shape: {data_matrix.shape}")  # 调试信息

    error_matrix = dataset["error"].values
    error_matrix_changed = _format_change_for_value(error_matrix)

    num_theta = len(theta_axis)
    num_energy = len(energy_axis)-1
    with open(filename, 'w') as f:
        f.write(f"{(num_theta-1):<8}{num_energy:<8}\n")
        # Write the Phi Grid
        f.write("### Phi Grid\n")
        for i in range(0, len(theta_axis_changed), 8):
            row = theta_axis_changed[i:i + 8]
            f.write("".join(f"{x:<10}" for x in row) + "\n")

        # Write the Energy Grid
        f.write("### Energy Grid\n")
        for i in range(0, len(energy_axis_changed), 8):
            row = energy_axis_changed[i:i + 8]
            f.write("".join(f"{x:<10}" for x in row) + "\n")

        for i in range(num_theta-1):
            f.write(f"### S(Phi,w)\n")
            for j in range(0, len(data_matrix_changed[i]), 8):
                row = data_matrix_changed[i][j:j + 8]
                f.write("".join(f"{x:<10}" for x in row) + "\n")

            f.write(f"### Errors\n")
            for j in range(0, len(error_matrix_changed[i]), 8):
                row = error_matrix_changed[i][j:j + 8]
                f.write("".join(f"{x:<10}" for x in row) + "\n")

    print(f"SPE file saved to {filename}")

def save_phx(filename, dataset):
    pixelID = dataset['positions'].coords['pixel'].values
    data = dataset["positions"].values
    if data.shape[1] < 8:
        raise ValueError("data 的列数必须 >= 8")
    if len(pixelID) != data.shape[0]:
        raise ValueError("pixelID 的长度必须与 data 的行数一致")

    # 打开文件并写入
    with open(filename, 'w') as file:
        # 写入第一行：总行数
        file.write(f"{data.shape[0]}\n")
        for i in range(data.shape[0]):
            # 提取当前行的数据
            col1 = data[i, 3]  # 第一列
            col2 = 0  # 第二列，固定为 0
            col3_to_6 = data[i, 4:8]  # 第三到六列
            col7 = pixelID[i]  # 最后一列

            # 格式化每一列
            line = (
                f"{col1:.3f}\t"  # 第一列，保留 6 位小数
                f"{col2:d}\t"  # 第二列，整数
                f"{col3_to_6[0]:.3f}\t"  # 第三列，保留 6 位小数
                f"{col3_to_6[1]:.3f}\t"  # 第四列，保留 6 位小数
                f"{col3_to_6[2]:.3f}\t"  # 第五列，保留 6 位小数
                f"{col3_to_6[3]:.3f}\t"  # 第六列，保留 6 位小数
                f"{col7:d}\n"  # 最后一列，整数
            )
            # 写入当前行
            file.write(line)
    print(f"PHX file saved to {filename}")


def _write_group(parent,name,ntype):
    grp = parent.create_group(name)
    grp.attrs["NX_class"] = ntype
    return grp

def _write_file_attrs(entry,filename):
    entry.attrs["default"] = "entry"
    entry.attrs["file_name"] = filename
    timestamp = str(datetime.datetime.now())
    entry.attrs["file_time"] = timestamp
    entry.attrs["NeXus_Version"] = "4.3.0"
    entry.attrs["HDF5_Version"] = h5py.__version__

def save_nxspe(filename, dataset,ei):
    position = dataset["positions"].values
    x = dataset["xvalue"].values[0]
    energy = change_point_to_boundary(x)
    hist = dataset["histogram"].values
    err = dataset["error"].values

    with h5py.File(filename,"w") as f:
        _write_file_attrs(f,filename)
        root = _write_group(f,"tmp_0","NXentry")
        ### （1） 写public data
        root.create_dataset("definition",data= "NXSPE")
        root.create_dataset("program_name",data="rongzai")

        ### （2）写NXSPE_info
        grp = _write_group(root,"NXSPE_info","NXcollection")
        # ei = dataset["ei"].values

        data = grp.create_dataset("fixed_energy",data = np.array([ei]), dtype=np.float64)
        data.attrs["units"] = "meV"

        grp.create_dataset("ki_over_kf_scaling", data = np.array([1]), dtype=np.int32)
        data = grp.create_dataset("psi",data = np.array([np.nan]), dtype=np.float64)
        data.attrs["units"] = "degrees"

        ### (3)写data
        grp = _write_group(root,"data","NXdata")
        azimuthal = position[:,5]
        azimuthal_width = position[:,7]
        polar = position[:,4]
        polar_width = position[:,6]
        distance = position[:,3]
        grp.create_dataset("azimuthal",data=azimuthal,dtype=np.float64)
        grp.create_dataset("azimuthal_width", data=azimuthal_width, dtype=np.float64)
        grp.create_dataset("polar", data=polar, dtype=np.float64)
        grp.create_dataset("polar_width", data=polar_width, dtype=np.float64)
        grp.create_dataset("distance", data=distance, dtype=np.float64)

        data = grp.create_dataset("energy",data=energy,dtype=np.float64)
        data.attrs["units"] = "meV"

        data =grp.create_dataset("data", data = hist, dtype=np.float64)
        data.attrs["axes"] = "polar:energy"
        data.attrs["signal"] = 1

        grp.create_dataset("error", data = err, dtype=np.float64)

        ### (4)写instrument
        grp = _write_group(root, "instrument", "NXinstrument")
        grp.create_dataset("name", data = "HD")
        grp_2 = _write_group(grp, "fermi", "NXfermi_chopper")
        grp_2.create_dataset("energy", data = np.array([ei]), dtype=np.float64)

        ###(5) 写sample
        grp = _write_group(root,"sample","NXsample")

        print(f"NXSPE 文件已写入： {filename}")






