import h5py
def print_h5_structure(name, obj):
    """
    递归打印 HDF5 文件的结构、类型和属性。
    """
    print(f"Name: {name}")
    print(f"Type: {type(obj)}")

    # 如果是数据集，打印其形状和数据类型
    if isinstance(obj, h5py.Dataset):
        print(f"Shape: {obj.shape}")
        print(f"Data type: {obj.dtype}")

    # 打印属性
    if obj.attrs:
        print("Attributes:")
        for key, value in obj.attrs.items():
            print(f"  {key}: {value}")

    print("-" * 40)


def read_nxspe(filename):
    """
    读取 NXSPE 文件并打印其结构、类型和属性。
    """
    with h5py.File(filename, "r") as f:
        # 递归遍历文件中的所有组和数据集
        f.visititems(print_h5_structure)


def compare_h5_structure(file1, file2, path="/"):
    """
    递归比较两个 HDF5 文件的结构和元数据。
    """
    with h5py.File(file1, "r") as f1, h5py.File(file2, "r") as f2:
        def _compare(name, obj1, obj2):
            # 检查对象类型是否一致
            if type(obj1) != type(obj2):
                print(f"Type mismatch at {name}: {type(obj1)} vs {type(obj2)}")

            # 如果是数据集，检查形状和数据类型
            if isinstance(obj1, h5py.Dataset):
                if obj1.shape != obj2.shape:
                    print(f"Shape mismatch at {name}: {obj1.shape} vs {obj2.shape}")
                if obj1.dtype != obj2.dtype:
                    print(f"Data type mismatch at {name}: {obj1.dtype} vs {obj2.dtype}")

            # 检查属性
            if obj1.attrs != obj2.attrs:
                print(f"Attributes mismatch at {name}:")
                for key in set(obj1.attrs.keys()).union(obj2.attrs.keys()):
                    if key not in obj1.attrs:
                        print(f"  {key} missing in {file1}")
                    elif key not in obj2.attrs:
                        print(f"  {key} missing in {file2}")
                    elif obj1.attrs[key] != obj2.attrs[key]:
                        print(f"  {key}: {obj1.attrs[key]} vs {obj2.attrs[key]}")

            print("-" * 40)

        # 递归比较
        f1[path].visititems(lambda name, obj: _compare(name, obj, f2[path][name]))