import os
def write_diffraction_format(dataset,group,conf,fn):
    runno = conf["sample_run"][0]
    detector = dataset.attrs.get("name")
    focus_info = conf["focus_point"][group]
    if "factor" in focus_info:
        task = DiffractionFormat(dataset, runno, detector, conf["beamline_name"],
                                 0,0,focus_info["factor"],0)
    else:
        task = DiffractionFormat(dataset,runno,detector,conf["beamline_name"],
                                     focus_info["DIFA"],
                                     focus_info["DIFB"],
                                     focus_info["DIFC"],
                                     focus_info["ZERO"])
    task.writeGSAS(fn + ".gsa")
    task.writeZR(fn + ".histogramIgor")
    task.writeFP(fn + ".dat", conf["multiply_factor_fullprof"], conf["focus_point"][group]["2_theta"])


class DiffractionFormat:
    def __init__(self,dataset,runno,bankname,beamline,difa,difb,difc,zero=0):#, usePC, savePath,beamline_name):
        d = dataset["xvalue"].values[0]
        self.tof = difa*d**2 + difc*d + difb/d + zero
        self.counts = dataset["histogram"].values[0]
        self.error = dataset["error"].values[0]
        self.runNo = runno
        self.bankname = bankname
        self.bl = beamline

    def update_suffixes(self, conf):
        if conf["norm_by_pc"]:
            self.suffixes = {k: "pc" + v for k, v in self.suffixes.items()}
        if conf["time_slice"]:
            slice_suffix = f"{conf['slice_series']}"
            self.suffixes = {k: slice_suffix + v for k, v in self.suffixes.items()}

    def create_filenames(self):
        return {k: f"{self.path}_{self.bankname}_{v}" for k, v in self.suffixes.items()}

    def writeMAUD(self,filename):
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_gsas = open(filename, "w")
        strtmp = self.bl + " Diffraction Histogram for " + self.bankname + ", " + str(self.runNo)
        f_gsas.write("%-80s%s" % (strtmp, CRLF))
        n = len(self.tof)
        step = self.tof[1] - self.tof[0]
        istart = 1
        for i in range(n - 1):
            if self.tof[i + 1] - self.tof[i] != step:
                istart = i + 1
                break
        res = (self.tof[istart] - self.tof[istart - 1]) / float(self.tof[istart - 1])
        nch = n - 1
        n = nch
        num = self.bankname[-1]
        strtmp = "%s%s %6d %6d %s %6d %6d %6d %.6f %s" % (
            "BANK ",
            num,
            n,
            nch,
            "RALF",
            int(self.tof[0]) * 32,
            step * 32,
            int(self.tof[istart]) * 32,
            res,
            "FXYE",
        )
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        for i in range(len(self.tof)):
            strtmp = '%15.6f %15.10f %15.10f' % (self.tof[i], self.counts[i], self.error[i])
            f_gsas.write('%s' % strtmp)
            f_gsas.write('%s' % CRLF)
        f_gsas.close()

    def writeGSAS(self,filename):
        # define output filename
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_gsas = open(filename, "w")
        strtmp = self.bl+" Diffraction Histogram for " + self.bankname + ", " + str(self.runNo)
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        n = len(self.tof)
        step = self.tof[1] - self.tof[0]
        istart = 1
        for i in range(n - 1):
            if self.tof[i + 1] - self.tof[i] != step:
                istart = i + 1
                break
        res = (self.tof[istart] - self.tof[istart - 1]) / float(self.tof[istart - 1])
        # write keyword
        # iformat = 2
        num = self.bankname[-1]
        nrec = 1
        nch = n - 1
        n = nch
        strtmp = "%s%s %6d %6d %s %6d %6d %6d %.6f %s" % (
            "BANK ",
            num,
            n,
            nch,
            "RALF",
            int(self.tof[0]) * 32,
            step * 32,
            int(self.tof[istart]) * 32,
            res,
            "FXYE",
        )
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        # write data
        for i in range(nch):
            for j in range(nrec):
                if i * nrec + j == 0:
                    x = self.tof[0]
                else:
                    x = (self.tof[i * nrec + j] + self.tof[i * nrec + j - 1]) * 0.5
                strtmp = "%15.6f %15.10f %15.10f" % (
                    x,
                    self.counts[i * nrec + j] * (self.tof[i * nrec + j + 1] - self.tof[i * nrec + j]),
                    self.error[i * nrec + j] * (self.tof[i * nrec + j + 1] - self.tof[i * nrec + j]),
                )
                f_gsas.write("%s" % strtmp)
            f_gsas.write("%s" % CRLF)
        f_gsas.close()

    def writeGSAS_psd(self, filename):
        # define output filename
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_gsas = open(filename, "w")
        strtmp = self.bl + " Diffraction Histogram for " + self.bankname + ", " + str(self.runNo)
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        n = len(self.tof)
        step = self.tof[1] - self.tof[0]
        istart = 1
        for i in range(n - 1):
            if self.tof[i + 1] - self.tof[i] != step:
                istart = i + 1
                break
        res = (self.tof[istart] - self.tof[istart - 1]) / float(self.tof[istart - 1])
        # write keyword
        # iformat = 2
        num = self.bankname[-1]
        nrec = 1
        nch = n - 1
        n = nch
        strtmp = "%s%s %6d %6d %s %6d %6d %6d %.6f %s" % (
            "BANK ",
            num,
            n,
            nch,
            "RALF",
            int(self.tof[0]) * 32,
            step * 32,
            int(self.tof[istart]) * 32,
            res,
            "FXYE",
        )
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        # write data
        for i in range(nch):
            for j in range(nrec):
                if i * nrec + j == 0:
                    x = self.tof[0]
                else:
                    x = self.tof[i * nrec + j]
                strtmp = "%15.2f %15.6f %15.6f" % (
                    x,
                    self.counts[i * nrec + j],
                    self.error[i * nrec + j],
                )
                f_gsas.write("%s" % strtmp)
            f_gsas.write("%s" % CRLF)
        f_gsas.close()

    def writeFP(self,filename,factor,two_theta):
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_fp = open(filename, "w")

        strtmp = self.bl+" Diffraction Histogram for "+str(two_theta)+"-degree bank, " + str(
                self.runNo)  # +', Rexp is '+str(rexp)
        f_fp.write("%s%s" % (strtmp, CRLF))
        strtmp = "The original intensities and sigmas have been multiplied by "+str(10**(factor))
        f_fp.write("%s%s" % (strtmp, CRLF))
        strtmp = "%s %s %s" % ("TOF", "INT", "ERR")
        f_fp.write("%s%s" % (strtmp, CRLF))
        # write data
        for i in range(len(self.tof)):
            strtmp = "%.2f %.6f %.6f" % (
                self.tof[i],
                self.counts[i] * (10 ** (factor)),
                self.error[i] * (10 ** (factor)),
            )
            f_fp.write("%s" % strtmp)
            f_fp.write("%s" % CRLF)
        f_fp.close()

    def writeZR(self,filename):
        #filename = self.path+"_"+bank+self.suffix_zr
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_zr = open(filename, "w")
        strtmp = "IGOR"
        f_zr.write("%s%s" % (strtmp, CRLF))
        strtmp = "%s %s %s %s" % ("WAVES/O", "tof", "yint", "yerr")
        f_zr.write("%s%s" % (strtmp, CRLF))
        strtmp = "BEGIN"
        f_zr.write("%s%s" % (strtmp, CRLF))
        # write data
        for i in range(len(self.tof)):
            strtmp = "%.2f %.6f %.6f" % (self.tof[i], self.counts[i], self.error[i])
            f_zr.write("%s" % strtmp)
            f_zr.write("%s" % CRLF)
        strtmp = "END"
        f_zr.write("%s" % (strtmp))
