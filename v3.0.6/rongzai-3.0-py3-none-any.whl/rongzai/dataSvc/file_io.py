import numpy as np
import re, os, json, time
'''
####################################
write_ascii：将数据写入 ASCII 格式文件。
write_cal：将数据写入 CAL 格式文件。
read_cal：从 CAL 格式文件读取数据。
read_mask：从文件读取mask数据。
read_instrument_info:从txt文件中读取探测器像素所有信息
modify_json_config: 修改json配置文件并保存到指定目录
save_important_config:保存配置中的重要信息，支持嵌套字典的完整提取
###################################
'''
def write_ascii(fn,*args, format="%.8f"):
    if not args:
        raise ValueError("No data provided to write to the file.")
    # 检查所有输入数组长度是否一致
    length = len(args[0])
    if not all(len(arr) == length for arr in args):
        raise ValueError("All input arrays must have the same length.")
    # 组合所有输入数组到一个大的数组中
    combined_array = np.column_stack(args)
    np.savetxt(fn, combined_array, fmt=format)

def write_cal(info_dict):
    # Ensure correct data types in info_dict
    info_dict["index"] = np.array(info_dict["index"], dtype=int)
    info_dict["pixel"] = np.array(info_dict["pixel"], dtype=int)
    info_dict["c2"] = np.array(info_dict['offset'][:, 2], dtype=float)
    info_dict["c1"] = np.array(info_dict['offset'][:, 1], dtype=float)
    info_dict["c0"] = np.array(info_dict['offset'][:, 0], dtype=float)
    info_dict["mask"] = np.array(info_dict["mask"], dtype=int)
    info_dict["group"] = np.array(info_dict["group"], dtype=int)

    combined_data = np.column_stack((info_dict["index"],
                                    info_dict["pixel"],
                                    info_dict["c2"],
                                    info_dict["c1"],
                                    info_dict["c0"],
                                    info_dict["mask"],
                                    info_dict["group"]))

    formats = ["%d","%d","%.18f","%.18f","%.18f","%d","%d"]
    header = (f"pixels_per_tube: {info_dict['pixels_per_tube']}, " +
              f"group_along_tube_tof: {info_dict['group_along_tube_tof']}, " +
            f"group_cross_tube_tof: {info_dict['group_cross_tube_tof']}, "+
            f"group_along_tube_d: {info_dict['group_along_tube_d']}, " +
            f"group_cross_tube_d: {info_dict['group_cross_tube_d']}\n"
    )
    # header = f"pixels_per_tube: {info_dict["pixels_per_tube"]}, group_along_tube: {info_dict["group_along_tube"]}, group_cross_tube: {info_dict["group_cross_tube"]}\n"
    header += "Format: number    UDET     c2    c1    c0    select    group"

    np.savetxt(info_dict["save_file"],combined_data,fmt=formats,
               comments="#", header=header)


def extract_info_from_file(file_path):
    with open(file_path, 'r') as file:
        first_line = file.readline().strip()
        pattern = r'#pixels_per_tube:\s*(\d+),\s*group_along_tube_tof:\s*(\d+),\s*group_cross_tube_tof:\s*(\d+), \s*group_along_tube_d:\s*(\d+),\s*group_cross_tube_d:\s*(\d+)'
        match = re.match(pattern, first_line)
        if match:
            pixels_per_tube = int(match.group(1))
            group_along_tube_tof = int(match.group(2))
            group_cross_tube_tof = int(match.group(3))
            group_along_tube_d = int(match.group(4))
            group_cross_tube_d = int(match.group(5))
            return {
                'pixels_per_tube': pixels_per_tube,
                'group_along_tube_tof': group_along_tube_tof,
                'group_cross_tube_tof': group_cross_tube_tof,
                'group_along_tube_d': group_along_tube_d,
                'group_cross_tube_d': group_cross_tube_d
            }
        else:
            return {
            'pixels_per_tube': 100,
            'group_along_tube_tof': 1,
            'group_cross_tube_tof': 1,
                'group_along_tube_d': 1,
                'group_cross_tube_d': 1,
            }
def read_cal(fn):
    data = {}
    info = extract_info_from_file(fn)
    cal = np.loadtxt(fn,unpack=False)
    if cal.ndim == 1:
        cal = cal.reshape(1, -1)
    data["mask_list"] = cal[:,5]
    data["c2_list"] = cal[:,2]
    data["c1_list"] = cal[:,3]
    data["c0_list"] = cal[:,4]
    # print(fn, data["c2_list"].shape)
    # print(f"mask rate = {1-cal[:,5].sum()/cal.shape[0]}")
    return {**data, **info}

def read_mask(fn):
    data = {}
    cal = np.loadtxt(fn,unpack=False)
    data["mask_list"] = cal[:,1]
    # print(f"mask rate = {1 - cal[:, 1].sum() / cal.shape[0]}")
    return data

def read_instrument_info(txt_file_path):
    data = np.loadtxt(txt_file_path)
    if data.ndim==1:
        data = np.expand_dims(data,axis=0)
    if data.shape[1] < 8:
        x = data[:,1]
        y = data[:,2]
        z = data[:,3]
        l2 = np.sqrt(x**2 + y**2 + z**2)
        two_theta = np.arccos(z / l2) * 180 / np.pi### degree
        result = np.hstack((data[:,:4],l2[:,np.newaxis], two_theta[:,np.newaxis]))
        padding = np.zeros((data.shape[0], 3))
        result = np.hstack((result,padding))
    else:
        result = data
    pixel_ids = result[:, 0].astype(int)
    positions = result[:, 1:]
    return pixel_ids,positions


def modify_json_config(original_json_path, modifications, output_dir=None):
    """
    Args:
        original_json_path: 原始JSON文件路径
        modifications: 要修改的键值对字典
        output_dir: 输出目录，如果为None则覆盖原文件
    Returns:
        修改后的JSON文件路径
    """
    # 读取原始JSON文件
    with open(original_json_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    # 应用修改
    for key, value in modifications.items():
        keys = key.split('.')
        current = config
        for k in keys[:-1]:
            current = current.setdefault(k, {})
        current[keys[-1]] = value

    # 确定输出路径
    if output_dir is None:
        output_path = original_json_path
    else:
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        filename = os.path.basename(original_json_path)
        output_path = os.path.join(output_dir, filename)

    # 保存修改后的配置
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

    return output_path


# def save_important_config(conf_dict, output_path, important_keys=None):
#     """
#     Args:
#         conf_dict: 完整的配置字典
#         output_path: 输出文件路径
#         important_keys: 需要保存的重要键列表，支持通配符
#     """
#     if important_keys is None:
#         raise Exception("error: No important_keys")
#
#     extracted_config = {}
#
#     for key_path in important_keys:
#         keys = key_path.split('.')
#         try:
#             # 获取值
#             value = conf_dict
#             for k in keys:
#                 value = value[k]
#
#             # 构建嵌套结构
#             current_level = extracted_config
#             for i, key in enumerate(keys[:-1]):
#                 if key not in current_level:
#                     current_level[key] = {}
#                 current_level = current_level[key]
#
#             # 赋值
#             current_level[keys[-1]] = value
#
#         except (KeyError, TypeError):
#             print(f"警告: 配置键 '{key_path}' 不存在")
#             continue
#     # 保存为JSON
#     with open(output_path, 'w', encoding='utf-8') as f:
#         json.dump(extracted_config, f, indent=4, ensure_ascii=False)

def save_important_config(conf_dict, output_path, important_keys=None):
    """
    Args:
        conf_dict: 完整的配置字典
        output_path: 输出文件路径
        important_keys: 需要保存的重要键列表，支持通配符
    """
    if important_keys is None:
        raise Exception("error: No important_keys")

    extracted_config = {}

    for key_path in important_keys:
        keys = key_path.split('.')

        # 获取值，如果路径不存在则设为None
        value = conf_dict
        key_exists = True
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                key_exists = False
                value = None
                break

        if not key_exists:
            print(f"警告: 配置键 '{key_path}' 不存在，将设为None")

        # 构建嵌套结构
        current_level = extracted_config
        for i, key in enumerate(keys[:-1]):
            if key not in current_level:
                current_level[key] = {}
            current_level = current_level[key]

        # 赋值
        current_level[keys[-1]] = value

    # 保存为JSON
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(extracted_config, f, indent=4, ensure_ascii=False)