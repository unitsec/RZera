import numpy as np
def write_rmc(fn,*args,header_custom = "MPI RMC",format="%.5e"):
    if not args:
        raise ValueError("No data provided to write to the file.")

    length = len(args[0])
    if not all(len(arr) == length for arr in args):
        raise ValueError("All input arrays must have the same length.")

    header = f"# {length}\n# {header_custom}"
    combined_array = np.column_stack(args)
    np.savetxt(fn, combined_array, fmt=format, header = header, comments='')
