import re,os
from scipy.interpolate import interp1d
import numpy as np

def load_custom_file(file_path):
    """
    自定义文件读取函数：
    - 如果文件中有以 # 开头的行，跳过接下来的 2 行。
    - 自动判断分隔符是空格还是逗号。
    - 读取文件并返回数据。

    参数:
        file_path (str): 文件路径。

    返回:
        np.ndarray: 加载的数据。
    """
    skip_rows = 0
    delimiter = None

    # 打开文件，检查是否有 # 开头的行
    with open(file_path, 'r') as f:
        lines = f.readlines()

    # 判断是否需要跳过行
    for i, line in enumerate(lines):
        if line.strip().startswith('#'):
            skip_rows = i + 2  # 跳过 # 行和接下来的 2 行
            break

    # 自动判断分隔符
    for line in lines[skip_rows:]:
        if line.strip():  # 跳过空行
            if ',' in line:
                delimiter = ','
            else:
                delimiter = None  # 默认空格分隔
            break
    # 加载数据
    data = np.loadtxt(file_path, delimiter=delimiter, skiprows=skip_rows)
    return data

class HermiteLoader:
    def __init__(self, conf):
        self.config = conf
        self.qstep = (conf["q_rebin"]["merge"][1]-conf["q_rebin"]["merge"][0])/conf["q_rebin"]["merge"][2]
        print(f"qstep = {self.qstep}")
        # self.data = self.load_data_files(base_path)

    def extract_group_name(self, file_name):
        match = re.search(r'group(\d+)', file_name)
        if match:
            return 'group' + match.group(1)
        return None

    def _load_check_data(self,file_path):
        data = load_custom_file(file_path)
        q = data[:, 0]
        iq = data[:, 1]
        if q[-1] > self.config["q_rebin"]["merge"][1]:
            idx = np.where(q > self.config["q_rebin"]["merge"][1])[0][0]
            q = q[:idx - 1]
            iq = iq[:idx - 1]
        if q[0] < self.config["q_rebin"]["merge"][0]:
            idx = np.where(q < self.config["q_rebin"]["merge"][0])[0][0]
            q = q[idx:]
            iq = iq[idx:]

        step_sizes = np.diff(q)
        is_uniform = np.allclose(step_sizes, step_sizes[0], atol=1e-2)
        iterp = False
        if is_uniform:
            if q[1]-q[0] < self.qstep:
                iterp = True
        else:
            iterp = True
        if iterp:
            new_x = np.arange(q[0], q[-1] + self.qstep, self.qstep)
            if iq.ndim == 1:
                interpolator = interp1d(q, iq, kind='linear', fill_value="extrapolate")
                new_y = interpolator(new_x)
            else:
                raise ValueError("y must be either 1D array.")
            q = new_x
            iq = new_y
        if self.config["data_type"].lower() == "s(q)":
            iq = iq - self.config["self_term"]
            qiq = iq * q
        elif self.config["data_type"].lower() == "i(q)":
            qiq = iq * q
        else:
            qiq = iq
        return q,qiq

    def load_data_files(self,base_path):
        data = {}
        qdict = {}
        qiqdict = {}
        group_list = []
        for name in self.config["data_files"]:
            group_name = self.extract_group_name(name)
            group_list.append(group_name)
            file_path = os.path.join(base_path, name)
            q,qiq = self._load_check_data(file_path)
            qdict[group_name] = q
            qiqdict[group_name] = qiq
        data["q"] = qdict
        data["qiq"] = qiqdict
        data["group_order"] = group_list
        return data
