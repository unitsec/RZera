import h5py
from scipy.sparse import coo_matrix
from rongzai.utils.array_utils import change_bytes_to_float
from rongzai.utils.histogram import Hist2D
from . import create_dataset,read_instrument_info
import numpy as np
'''
#####################################
load_redis_data
load_histogram_data
load_event_data
#####################################
'''

def load_array_data(y_data,x_data,txt_file_path,module,l1,t0_offset):
    pixel_ids, positions = read_instrument_info(txt_file_path)
    e_data = np.sqrt(y_data)
    x_data = x_data + t0_offset
    x_data = _process_x_data(x_data, y_data)
    pc = 1
    neutron_data = create_dataset(y_data, e_data, x_data, pixel_ids, positions, pc, l1, module, "tof")
    return neutron_data


def load_redis_data(rds, path, txt_file_path, module, l1, merge_num):
    hist_path = path + "/" + module + "/value"
    tof_path = path + "/" + module + "/tof"

    y_data = rds.readNumpyArray(hist_path)
    x_data = rds.readNumpyArray(tof_path)
    # print(hist_path,y_data.shape,tof_path,x_data.shape)
    if y_data.shape[1] == len(x_data) - 1 or y_data.shape[1] == len(x_data):
        pass
    else:
        y_data = y_data.T
    pixel_ids, positions = read_instrument_info(txt_file_path)
    x_data = rds.readNumpyArray(tof_path)
    e_data = np.sqrt(y_data)
    x_data = _process_x_data(x_data,y_data)
    if merge_num > 1:
        nums = int(len(pixel_ids) / merge_num)
        new_pixel_id = []
        new_positions = []
        start = pixel_ids[0]
        for i in range(nums):
            new_pixel_id.append(start + i)
            new_positions.append(positions[i * merge_num, :])
        positions = np.array(new_positions)
        pixel_ids = np.array(new_pixel_id)
    pc = 1
    neutron_data = create_dataset(y_data, e_data, x_data, pixel_ids, positions, pc, l1, module, "tof")
    return neutron_data

def load_histogram_data(hdf_file_list,txt_file_path,module,l1,x_offset):
    y_data,e_data,x_data,pc = get_data_from_hdf(hdf_file_list,module,x_offset)
    x_data = _process_x_data(x_data, y_data)
    pixel_ids, positions = read_instrument_info(txt_file_path)
    # start_time,end_time = get_experiment_time(hdf_file_list[0])
    neutron_data = create_dataset(y_data, e_data, x_data, pixel_ids, positions, pc, l1, module, "tof")
    return neutron_data

def load_event_data(pids,tofs,tof_step,pc,txt_file_path,module,l1,x_offset):
    pixel_ids, positions = read_instrument_info(txt_file_path)
    pid_nums = pixel_ids.size
    tof_min = np.min(tofs)
    tof_max = np.max(tofs)
    tof_nums = int((tof_max-tof_min)/tof_step)
    histogram = Hist2D(pid_nums,tof_nums, [[-0.5 + pixel_ids[0], pixel_ids[-1]+0.5],
                        [-0.5+tof_min, tof_max-0.5]])
    histogram.fill(pids,tofs)
    y_data = histogram.hist
    x_data = histogram.yedge+x_offset
    e_data = np.sqrt(y_data)
    x_data = _process_x_data(x_data,y_data)
    neutron_data = create_dataset(y_data, e_data, x_data, pixel_ids, positions,pc, l1, module)
    return neutron_data

def get_experiment_time(fn):
    with h5py.File(fn, 'r') as hdf:
        start = hdf["/csns/start_time_utc"][()][0].decode('utf-8')
        end = hdf["/csns/end_time_utc"][()][0].decode('utf-8')
        # print(start, end)
    return start, end

def get_event_data_from_hdf(hdf_file_list,module):
    if len(hdf_file_list)==0:
        raise Exception(f"no nexus files!")
    pids = []
    tofs = []
    for i in range(len(hdf_file_list)):
        with h5py.File(hdf_file_list[i], 'r') as hdf:
            pids.extend(hdf["/csns/instrument/"+module+"/event_pixel_id"][()])
            tofs.extend(hdf["/csns/instrument/"+module+"/event_time_of_flight"][()])
    return np.array(pids),np.array(tofs)

def get_data_from_hdf(hdf_file_list,module,offset):
    if len(hdf_file_list)==0:
        raise Exception(f"no nexus files!")
    pc = 0.0
    for i in range(len(hdf_file_list)):
        with h5py.File(hdf_file_list[i], 'r') as hdf:
            pc_path = "/csns/proton_charge"
            if pc_path not in hdf:
                print(f"no such path {pc_path} in nexus file, pc will be 1.0")
                pc += 1.0
            else:
                tmp_pc = hdf[pc_path][()]
                pc += change_bytes_to_float(tmp_pc)
            prepath = '/csns/instrument/'+module
            if prepath not in hdf:
                raise Exception(f"no such module {prepath} in nexus file")
            tof_data = hdf[prepath +'/time_of_flight'][:]+offset
            num_bins = tof_data.size
            tof_data = tof_data.flatten()[:-1]+(tof_data[1]-tof_data[0])*0.5
            pixel = hdf[prepath + "/pixel_id"][()]
            if i == 0:
                if 'is_sparse' in hdf[prepath].attrs and hdf[prepath].attrs["is_sparse"]:
                    try:
                        histogram_data = _decodeSparse(hdf,prepath,pixel.size,num_bins-1)
                    except:
                        histogram_data = hdf[prepath + "/histogram_data"][()]
                else:
                    histogram_data = hdf[prepath + "/histogram_data"][()]
            else:
                if 'is_sparse' in hdf[prepath].attrs and hdf[prepath].attrs["is_sparse"]:
                    try:
                        tmp = _decodeSparse(hdf,prepath,pixel.size,num_bins-1)
                    except:
                        tmp = hdf[prepath + "/histogram_data"][()]
                    histogram_data +=tmp
                else:
                    histogram_data += hdf[prepath + "/histogram_data"][()]

        idxlist = np.where(tof_data>=0)[0]
        if len(idxlist)<len(tof_data):
            tof_data = tof_data[idxlist]
            histogram_data = histogram_data[:,idxlist]
    return histogram_data,np.sqrt(histogram_data),tof_data,pc

def get_time_from_hdf(fn):
    with h5py.File(fn,"r") as hf:
        start = hf["/csns/start_time_utc"][()]
        end = hf["/csns/end_time_utc"][()]
        start_time = start[0].decode("utf-8").strip()
        end_time = end[0].decode("utf-8").strip()
        return start_time, end_time

def _decodeSparse(f, path,pixelNum,tofNum):
    row_indices = f[path +'/row_indices'][:]
    col_indices = f[path +'/col_indices'][:]
    data = f[path +'/histogram_data'][:]
    data = coo_matrix((data, (row_indices, col_indices)), shape=(pixelNum, tofNum)).toarray()
    return data


def _process_x_data(x_data,y_data):
    len_y = y_data.shape[1]
    len_x = x_data.size
    if len_x != len_y:
        x_data = x_data[:-1] + (x_data[1] - x_data[0]) * 0.5
    return np.tile(x_data, (y_data.shape[0], 1))