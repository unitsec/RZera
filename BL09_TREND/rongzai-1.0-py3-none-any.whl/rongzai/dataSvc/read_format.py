import numpy as np
import re
def extract_info_from_file(file_path):
    with open(file_path, 'r') as file:
        first_line = file.readline().strip()
        pattern = r'#pixels_per_tube:\s*(\d+),\s*group_along_tube_tof:\s*(\d+),\s*group_cross_tube_tof:\s*(\d+), \s*group_along_tube_d:\s*(\d+),\s*group_cross_tube_d:\s*(\d+)'
        match = re.match(pattern, first_line)
        if match:
            pixels_per_tube = int(match.group(1))
            group_along_tube_tof = int(match.group(2))
            group_cross_tube_tof = int(match.group(3))
            group_along_tube_d = int(match.group(4))
            group_cross_tube_d = int(match.group(5))
            return {
                'pixels_per_tube': pixels_per_tube,
                'group_along_tube_tof': group_along_tube_tof,
                'group_cross_tube_tof': group_cross_tube_tof,
                'group_along_tube_d': group_along_tube_d,
                'group_cross_tube_d': group_cross_tube_d
            }
        else:
            return {
            'pixels_per_tube': 100,
            'group_along_tube_tof': 1,
            'group_cross_tube_tof': 1,
                'group_along_tube_d': 1,
                'group_cross_tube_d': 1,
            }

def read_cal(fn):
    data = {}
    info = extract_info_from_file(fn)
    cal = np.loadtxt(fn,unpack=False)
    data["mask_list"] = cal[:,5]
    data["c2_list"] = cal[:,2]
    data["c1_list"] = cal[:,3]
    data["c0_list"] = cal[:,4]
    print(f"mask rate = {1-cal[:,5].sum()/cal.shape[0]}")
    return {**data, **info}


def get_pixel_positions(txt_file_path):
    data = np.loadtxt(txt_file_path)
    if data.ndim==1:
        pixel_ids = np.expand_dims(data[0].astype(int),axis=0)
        positions = np.expand_dims(data[1:4],axis=0)
    else:
        pixel_ids = data[:, 0].astype(int)
        positions = data[:, 1:4]
    return pixel_ids,positions