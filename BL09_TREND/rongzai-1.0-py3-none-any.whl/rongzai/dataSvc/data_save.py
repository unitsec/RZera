class DiffractionFormat:
    def __init__(self,conf,tof,counts,error):#, usePC, savePath,beamline_name):
        self.runNo = conf["current_runno"]
        self.bankname = conf["current_bank"]
        self.focus_point = conf["focus_point"]
        self.bl = conf['beamline_name']
        self.factor = conf["multiply_factor_fullprof"]
        self.tof = tof
        self.counts = counts
        self.error = error

    def update_suffixes(self, conf):
        if conf["norm_by_pc"]:
            self.suffixes = {k: "pc" + v for k, v in self.suffixes.items()}
        if conf["time_slice"]:
            slice_suffix = f"{conf['slice_series']}"
            self.suffixes = {k: slice_suffix + v for k, v in self.suffixes.items()}

    def create_filenames(self):
        return {k: f"{self.path}_{self.bankname}_{v}" for k, v in self.suffixes.items()}

    def writeMAUD(self,filename):
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_gsas = open(filename, "w")
        strtmp = self.bl + " Diffraction Histogram for " + self.bankname + ", " + str(self.runNo)
        f_gsas.write("%-80s%s" % (strtmp, CRLF))
        n = len(self.tof)
        step = self.tof[1] - self.tof[0]
        istart = 1
        for i in range(n - 1):
            if self.tof[i + 1] - self.tof[i] != step:
                istart = i + 1
                break
        res = (self.tof[istart] - self.tof[istart - 1]) / float(self.tof[istart - 1])
        nch = n - 1
        n = nch
        num = self.bankname[-1]
        strtmp = "%s%s %6d %6d %s %6d %6d %6d %.6f %s" % (
            "BANK ",
            num,
            n,
            nch,
            "RALF",
            int(self.tof[0]) * 32,
            step * 32,
            int(self.tof[istart]) * 32,
            res,
            "FXYE",
        )
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        for i in range(len(self.tof)):
            strtmp = '%15.6f %15.10f %15.10f' % (self.tof[i], self.counts[i], self.error[i])
            f_gsas.write('%s' % strtmp)
            f_gsas.write('%s' % CRLF)
        f_gsas.close()

    def writeGSAS(self,filename):
        # define output filename
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_gsas = open(filename, "w")
        strtmp = self.bl+" Diffraction Histogram for " + self.bankname + ", " + str(self.runNo)
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        n = len(self.tof)
        step = self.tof[1] - self.tof[0]
        istart = 1
        for i in range(n - 1):
            if self.tof[i + 1] - self.tof[i] != step:
                istart = i + 1
                break
        res = (self.tof[istart] - self.tof[istart - 1]) / float(self.tof[istart - 1])
        # write keyword
        # iformat = 2
        num = self.bankname[-1]
        nrec = 1
        nch = n - 1
        n = nch
        strtmp = "%s%s %6d %6d %s %6d %6d %6d %.6f %s" % (
            "BANK ",
            num,
            n,
            nch,
            "RALF",
            int(self.tof[0]) * 32,
            step * 32,
            int(self.tof[istart]) * 32,
            res,
            "FXYE",
        )
        f_gsas.write("%-80s%s" % (strtmp, CRLF))

        # write data
        for i in range(nch):
            for j in range(nrec):
                if i * nrec + j == 0:
                    x = self.tof[0]
                else:
                    x = (self.tof[i * nrec + j] + self.tof[i * nrec + j - 1]) * 0.5
                strtmp = "%15.6f %15.10f %15.10f" % (
                    x,
                    self.counts[i * nrec + j] * (self.tof[i * nrec + j + 1] - self.tof[i * nrec + j]),
                    self.error[i * nrec + j] * (self.tof[i * nrec + j + 1] - self.tof[i * nrec + j]),
                )
                f_gsas.write("%s" % strtmp)
            f_gsas.write("%s" % CRLF)
        f_gsas.close()

    def writeFP(self,filename):
        theta2 = self.focus_point[self.bankname]["2_theta"]
        #filename = self.path+"_"+self.bank+self.suffix_fp
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_fp = open(filename, "w")

        strtmp = self.bl+" Diffraction Histogram for "+str(theta2)+"-degree bank, " + str(
                self.runNo)  # +', Rexp is '+str(rexp)
        f_fp.write("%s%s" % (strtmp, CRLF))
        strtmp = "The original intensities and sigmas have been multiplied by "+str(10**(self.factor))
        f_fp.write("%s%s" % (strtmp, CRLF))
        strtmp = "%s %s %s" % ("TOF", "INT", "ERR")
        f_fp.write("%s%s" % (strtmp, CRLF))
        # write data
        for i in range(len(self.tof)):
            strtmp = "%.2f %.6f %.6f" % (
                self.tof[i],
                self.counts[i] * (10 ** (self.factor)),
                self.error[i] * (10 ** (self.factor)),
            )
            f_fp.write("%s" % strtmp)
            f_fp.write("%s" % CRLF)
        f_fp.close()

    def writeZR(self,filename):
        #filename = self.path+"_"+bank+self.suffix_zr
        CR = chr(13)
        LF = chr(10)
        CRLF = LF
        f_zr = open(filename, "w")
        strtmp = "IGOR"
        f_zr.write("%s%s" % (strtmp, CRLF))
        strtmp = "%s %s %s %s" % ("WAVES/O", "tof", "yint", "yerr")
        f_zr.write("%s%s" % (strtmp, CRLF))
        strtmp = "BEGIN"
        f_zr.write("%s%s" % (strtmp, CRLF))
        # write data
        for i in range(len(self.tof)):
            strtmp = "%.2f %.6f %.6f" % (self.tof[i], self.counts[i], self.error[i])
            f_zr.write("%s" % strtmp)
            f_zr.write("%s" % CRLF)
        strtmp = "END"
        f_zr.write("%s" % (strtmp))
