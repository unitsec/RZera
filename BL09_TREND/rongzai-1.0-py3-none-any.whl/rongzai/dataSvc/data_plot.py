import matplotlib.pyplot as plt
from matplotlib.widgets import RectangleSelector

class ScientificPlots:
    def __init__(self, figsize=(10, 6), style='whitegrid', palette=None):
        self.figsize = figsize
        self.style = style
        self.palette = palette if palette else "colorblind"

        plt.rcParams['figure.figsize'] = self.figsize

    def plot_line(self, x, y, title='Line Plot', xlabel='X-axis', ylabel='Y-axis'):
        plt.figure(figsize=self.figsize)
        sns.lineplot(x=x, y=y, palette=self.palette)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.tight_layout()
        plt.show()

    def plot_heatmap(self, data, title='Heatmap', xlabel='X-axis', ylabel='Y-axis'):
        self.fig, self.ax = plt.subplots(figsize=self.figsize)
        heatmap = self.ax.imshow(data, cmap='hot', interpolation='nearest', origin="lower", aspect="auto")
        self.ax.set_title(title)
        self.ax.set_xlabel(xlabel)
        self.ax.set_ylabel(ylabel)
        plt.colorbar(heatmap, ax=self.ax)
        plt.tight_layout()
        # 创建 RectangleSelector
        self.selector = RectangleSelector(self.ax, self.onselect, interactive=True,
                                          button=[1],  # 左键
                                          minspanx=5, minspany=5, spancoords='pixels')
        plt.show()

    def onselect(self, eclick, erelease):
        # 获取选择的范围
        x1, y1 = int(eclick.xdata), int(eclick.ydata)
        x2, y2 = int(erelease.xdata), int(erelease.ydata)
        # 确保 x1, x2 和 y1, y2 是从小到大的顺序
        x1, x2 = sorted([x1, x2])
        y1, y2 = sorted([y1, y2])
        self.selected_range = ((x1, x2), (y1, y2))


    def get_selected_range(self):
        if self.selected_range is None:
            raise ValueError("No range has been selected yet.")
        return self.selected_range


    def save_figure(self, filename):
        plt.savefig(filename)


