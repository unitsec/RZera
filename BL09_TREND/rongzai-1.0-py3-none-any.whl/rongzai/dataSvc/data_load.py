import h5py
from scipy.sparse import coo_matrix

from rongzai.utils.array_utils import change_bytes_to_float
from rongzai.utils.histogram import Hist2D

from rongzai.dataSvc.data_creator import *
from rongzai.dataSvc.read_format import get_pixel_positions

def load_neutron_data(hdf_file_list,txt_file_path,module,l1,x_offset=0):
    y_data,e_data,x_data,pc = get_data_from_hdf(hdf_file_list,module,x_offset)
    len_y = y_data.shape[1]
    len_x = x_data.size
    if len_x != len_y:
        x_data = x_data[:-1] + (x_data[1] - x_data[0]) * 0.5
    x_data = np.tile(x_data, (y_data.shape[0], 1))
    pixel_ids, positions = get_pixel_positions(txt_file_path)
    # print(txt_file_path,pixel_ids.shape)
    # print(f"assemble={module} ")
    neutron_data = create_dataset(y_data, e_data, x_data, pixel_ids, positions, pc, l1, module,"tof")
    return neutron_data

def load_evt_neutron_data(pids,tofs,tof_step,pc,txt_file_path,module,l1,x_offset=0):
    pixel_ids, positions = get_pixel_positions(txt_file_path)
    pid_nums = pixel_ids.size
    tof_min = np.min(tofs)
    tof_max = np.max(tofs)
    tof_nums = int((tof_max-tof_min)/tof_step)
    histogram = Hist2D(pid_nums,tof_nums, [[-0.5 + pixel_ids[0], pixel_ids[-1]+0.5],
                        [-0.5+tof_min, tof_max-0.5]])
    histogram.fill(pids,tofs)
    y_data = histogram.hist
    x_data = histogram.yedge+x_offset
    #print(f"x_data={x_data}")
    e_data = np.sqrt(y_data)
    len_y = y_data.shape[1]
    len_x = x_data.size
    if len_x != len_y:
        x_data = x_data[:-1] + (x_data[1] - x_data[0]) * 0.5
    x_data = np.tile(x_data, (y_data.shape[0], 1))
    #print(f"x_data={x_data}")
    pixel_ids, positions = get_pixel_positions(txt_file_path)
    # print(f"assemble={module} ")
    neutron_data = create_dataset(y_data, e_data, x_data, pixel_ids, positions, pc, l1, module)
    return neutron_data


# def load_trans_data(hdf_file_list,txt_file_list,l1,x_offset=0,monitor_list=["monitor2","monitor3"]):
#     data_pixel_id = np.zeros(2)
#     data_positions = np.zeros([2,3])
#     #data_histogram = []
#     for i in range(len(monitor_list)):
#         name = monitor_list[i]
#         txt_file_path = txt_file_list[i]
#         y_data,e_data,x_data,pc = get_data_from_hdf(hdf_file_list,name,x_offset)
#         pos_data = np.loadtxt(txt_file_path,unpack=False)
#         if y_data.shape[0]>1:
#             y_data = np.sum(y_data,axis = 0)
#             pos_data = pos_data[0,:]
#         #print(pos_data)
#         data_pixel_id[i] = pos_data[0]
#         data_positions[i]= pos_data[1:]
#         #pixel_ids,positions = get_pixel_positions(txt_file_path)
#         if i == 0:
#             data_histogram = y_data.copy()
#         else:
#             data_histogram = np.vstack((data_histogram,y_data))
#
#     data_error = np.sqrt(data_histogram)
#     len_y = data_histogram.shape[1]
#     len_x = x_data.size
#     if len_x != len_y:
#         x_data = x_data[:-1]+(x_data[1]-x_data[0])*0.5
#     x_data = np.tile(x_data,(2,1))
#     data_pixel_id = data_pixel_id.astype(int)
#     neutron_data = create_dataset(data_histogram,data_error,x_data,data_pixel_id,data_positions,pc,l1)
#     return neutron_data

def assemble_neutron_data(x_data,y_data,e_data,pc,txt_file_path,module,l1,x_offset=0):
    #when use it for redis: pc=1.0, e_data = np.sqrt(y_data),x_data is tof, y_data is value
    len_y = y_data.shape[1]
    len_x = x_data.size
    if len_x != len_y:
        x_data = x_data[:-1]+(x_data[1]-x_data[0])*0.5
    x_data = np.tile(x_data,(y_data.shape[0],1))
    pixel_ids,positions = get_pixel_positions(txt_file_path)  # 从 txt_file_path 中读取探测器位置数据
    # print(f"assemble={module} ")
    neutron_data = create_dataset(y_data,e_data,x_data,pixel_ids,positions,pc,l1,module)
    return neutron_data








def get_data_from_hdf(hdf_file_list,module,offset):
    if len(hdf_file_list)==0:
        raise Exception(f"no nexus files!")
    for i in range(len(hdf_file_list)):
        with h5py.File(hdf_file_list[i], 'r') as hdf:
            pc_path = "/csns/proton_charge"
            if pc_path not in hdf:
                raise Exception(f"no such path {pc_path} in nexus file")
            pc = hdf[pc_path][()]
            pc = change_bytes_to_float(pc)
            prepath = '/csns/instrument/'+module
            if prepath not in hdf:
                raise Exception(f"no such module {prepath} in nexus file")
            tof_data = hdf[prepath +'/time_of_flight'][:]+offset
            num_bins = tof_data.size
            tof_data = tof_data.flatten()[:-1]+(tof_data[1]-tof_data[0])*0.5
            pixel = hdf[prepath + "/pixel_id"][()]
            if i == 0:
                if 'is_sparse' in hdf[prepath].attrs and hdf[prepath].attrs["is_sparse"]:
                    try:
                        histogram_data = decodeSparse(hdf,prepath,pixel.size,num_bins-1)
                    except:
                        histogram_data = hdf[prepath + "/histogram_data"][()]
                else:
                    histogram_data = hdf[prepath + "/histogram_data"][()]
            else:
                if 'is_sparse' in hdf[prepath].attrs and hdf[prepath].attrs["is_sparse"]:
                    try:
                        tmp = decodeSparse(hdf,prepath,pixel.size,num_bins-1)
                    except:
                        tmp = hdf[prepath + "/histogram_data"][()]
                    histogram_data +=tmp
                else:
                    histogram_data += hdf[prepath + "/histogram_data"][()]
                pc+= change_bytes_to_float(hdf[pc_path][()])

        idxlist = np.where(tof_data>=0)[0]
        if len(idxlist)<len(tof_data):
            tof_data = tof_data[idxlist]
            histogram_data = histogram_data[:,idxlist]
    return histogram_data,np.sqrt(histogram_data),tof_data,pc

def decodeSparse(f, path,pixelNum,tofNum):
    row_indices = f[path +'/row_indices'][:]
    col_indices = f[path +'/col_indices'][:]
    data = f[path +'/histogram_data'][:]
    data = coo_matrix((data, (row_indices, col_indices)), shape=(pixelNum, tofNum)).toarray()
    return data

# 使用示例
# txt_file_path = '/Users/kobude/gitlab/redonline/BL16/pidInfo/module10701.txt'
# # positions_da = load_pixel_positions(txt_file_path)
# # print(positions_da)
# import time
# be = time.time()
# hdf_file_path = ['/Users/kobude/RUN0020851/detector.nxs']
# #hdf_file_path = '/Users/kobude/RUN0026925/detector.nxs' #test sans
#
# #test = load_neutron_data_from_hdf(hdf_file_path,"module10701")
# neutron_data = load_neutron_data(hdf_file_path,txt_file_path,"module10701")
# #print(neutron_data)
# # import sys
# # dataset_memory = sum(array.nbytes for array in neutron_data.data_vars.values())
# # cvt = dataset_memory/1024/1024
# # print(f"Dataset memory usage: {dataset_memory} bytes, equal {cvt} MB")
# # total_memory = sys.getsizeof(neutron_data)+dataset_memory
# # print(f"Total memory usage including the Dataset object: {total_memory} bytes")
# print(time.time()-be," seconds")
