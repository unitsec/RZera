import numpy as np

# def write_cal(info_dict):
#     combined_data = np.column_stack((info_dict["index"],
#                                     info_dict["pixel"],
#                                     info_dict["offset"],
#                                     info_dict["mask"],
#                                     info_dict["group"]))
#     formats = ["%d","%d","%.7f","%d","%d"]
#     np.savetxt(info_dict["save_file"],combined_data,fmt=formats, comments="#",
#                 header="Format: number    UDET     offset    select    group")

def write_cal(info_dict):
    # Ensure correct data types in info_dict
    info_dict["index"] = np.array(info_dict["index"], dtype=int)
    info_dict["pixel"] = np.array(info_dict["pixel"], dtype=int)
    info_dict["c2"] = np.array(info_dict['offset'][:, 2], dtype=float)
    info_dict["c1"] = np.array(info_dict['offset'][:, 1], dtype=float)
    info_dict["c0"] = np.array(info_dict['offset'][:, 0], dtype=float)
    info_dict["mask"] = np.array(info_dict["mask"], dtype=int)
    info_dict["group"] = np.array(info_dict["group"], dtype=int)

    combined_data = np.column_stack((info_dict["index"],
                                    info_dict["pixel"],
                                    info_dict["c2"],
                                    info_dict["c1"],
                                    info_dict["c0"],
                                    info_dict["mask"],
                                    info_dict["group"]))

    formats = ["%d","%d","%.18f","%.18f","%.18f","%d","%d"]
    header = (f"pixels_per_tube: {info_dict['pixels_per_tube']}, " +
              f"group_along_tube_tof: {info_dict['group_along_tube_tof']}, " +
            f"group_cross_tube_tof: {info_dict['group_cross_tube_tof']}, "+
            f"group_along_tube_d: {info_dict['group_along_tube_d']}, " +
            f"group_cross_tube_d: {info_dict['group_cross_tube_d']}\n"
    )
    # header = f"pixels_per_tube: {info_dict["pixels_per_tube"]}, group_along_tube: {info_dict["group_along_tube"]}, group_cross_tube: {info_dict["group_cross_tube"]}\n"
    header += "Format: number    UDET     c2    c1    c0    select    group"

    np.savetxt(info_dict["save_file"],combined_data,fmt=formats,
               comments="#", header=header)

def write_ascii(fn,*args, format="%.8f"):
    if not args:
        raise ValueError("No data provided to write to the file.")
    # 检查所有输入数组长度是否一致
    length = len(args[0])
    if not all(len(arr) == length for arr in args):
        raise ValueError("All input arrays must have the same length.")
    # 组合所有输入数组到一个大的数组中
    combined_array = np.column_stack(args)
    np.savetxt(fn, combined_array, fmt=format)
