import xarray as xr
from rongzai.utils.constants import *
def create_dataArray(data, dim_names, coords=None,name=None, unit=None):
    # 创建一个DataArray，适应一维或二维输入，并根据提供的坐标值设置坐标。
    if data.ndim == 1:
        dims = (dim_names[0],)
        coords_dict = {dim_names[0]: coords[dim_names[0]]} if coords else None
    elif data.ndim == 2:
        dims = (dim_names[0], dim_names[1])
        coords_dict = {
            dim_names[0]: coords[dim_names[0]],
            dim_names[1]: coords[dim_names[1]]
        } if coords else None
    else:
        raise ValueError("Input data must be 1D or 2D.")

    da = xr.DataArray(data, dims=dims, coords=coords_dict, name=name)
    if unit:
        da.attrs['unit'] = unit
    return da

def create_dataset(hist, error, x, pixel, pos, pc, l1, module, unit="tof"):
    #must be 2D
    if hist.ndim == 1:
        hist = np.expand_dims(hist,axis=0)
        error = np.expand_dims(error,axis=0)
        x = np.expand_dims(x,axis=0)
    if pixel.ndim == 0:
        pixel = np.expand_dims(pixel,axis=0)
    if pos.ndim ==1:
        pos = np.expand_dims(pos,axis=0)
    histogram_dataArray = create_dataArray(hist, ['pixel', 'xaxis'],coords=None,
                                        name="histogram", unit="counts")
    x_dataArray = create_dataArray(x, ["pixel","xboundry"], coords=None,
                                    name="xvalue",unit=units_match[unit])#['pixel', 'xboundry'], coords=None,

    error_dataArray = create_dataArray(error,['pixel', 'xaxis'],coords=None,
                                        name="error", unit=None)
    positions_dataArray = create_dataArray(pos, ['pixel', 'coordinate'],
                                           coords={'pixel': pixel,'coordinate':['x','y','z']},
                                           name="positions", unit="meter")
    # print("create_dataset: ",histogram_dataArray,positions_dataArray)
    # print("create dataset: ",pixel.shape,pos.shape)
    # print("y_data shape:", hist.shape)
    # print("e_data shape:", error.shape)
    # print("x_data shape:", x.shape)
    # print("pixel_ids shape:", pixel.shape)
    da_set = xr.Dataset({
        'histogram': histogram_dataArray,
        'error': error_dataArray,
        'xvalue': x_dataArray,
        "positions": positions_dataArray,
        "l1": l1,
        "proton_charge": pc
    })
    # print(f"set attrs name {module}")
    da_set.attrs["name"] = module
    da_set.attrs["x_unit"] = unit
    return da_set