from scipy.optimize import curve_fit
from rongzai.dataSvc import write_cal
from rongzai.algSvc.base import (auto_extract_peak_data,smooth,fit_gaussian,
                         rebin,baseline_alg,goodness_of_fit,get_l_theta)
from rongzai.utils.defined_functions import gaussian, asymmetric_gaussian,linear_func,quadratic_func
from rongzai.utils.file_utils import check_dir
from rongzai.utils.constants import *
from rongzai.algSvc.neutron.group_nd import GroupNeutronData
from rongzai.algSvc.neutron.unit_convert_nd import UnitConvertNeutronData

import matplotlib.pyplot as plt
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
class PixelOffsetCalNeutronData():
    def tof2d(self, tof, C0, C1, C2):
        if C2 != 0:
            d = (- C1 + np.sqrt(C1 ** 2 - 4 * C2 * (C0 - tof))) / (2 * C2)
        else:
            d = (tof - C0) / C1
        return d

    def correct_tof_to_d(self,dataset,cal_dict):

        task_grp = GroupNeutronData()
        if cal_dict["group_along_tube_tof"] > 1 or cal_dict["group_cross_tube_tof"] > 1:
            dataset = task_grp.group_nd(dataset, cal_dict["pixels_per_tube"],
                                                cal_dict["group_along_tube_tof"], cal_dict["group_cross_tube_tof"])

        if cal_dict["group_along_tube_d"] > 1 or cal_dict["group_cross_tube_d"] > 1:
            task_cvt = UnitConvertNeutronData()
            dataset = task_cvt.run(dataset, "dspacing")
            dataset = task_grp.group_nd(dataset, cal_dict["pixels_per_tube"],
                                                cal_dict["group_along_tube_d"], cal_dict["group_cross_tube_d"])
            dataset = task_cvt.run(dataset,"tof")
        #dataset in tof
        c2 = np.array(cal_dict["c2_list"])
        c1 = np.array(cal_dict["c1_list"])
        c0 = np.array(cal_dict["c0_list"])
        x = dataset["xvalue"].values
        # Identify indices where c2 is zero and non-zero
        c2_zero_indices = (c2 == 0)
        c2_nonzero_indices = ~c2_zero_indices
        # Initialize the result array with NaNs or an appropriate default value
        a = np.full((len(c2), x.shape[1]), np.nan)
        if np.any(c2_zero_indices):
            a[c2_zero_indices] = (x[c2_zero_indices, :] - c0[c2_zero_indices, np.newaxis]) / c1[c2_zero_indices, np.newaxis]
        # Calculate for c2 != 0
        if np.any(c2_nonzero_indices):
            c2_nonzero = c2[c2_nonzero_indices, np.newaxis]
            c1_nonzero = c1[c2_nonzero_indices, np.newaxis]
            c0_nonzero = c0[c2_nonzero_indices, np.newaxis]
            x_nonzero = x[c2_nonzero_indices, :]
            a[c2_nonzero_indices] = (-c1_nonzero + np.sqrt(
                    c1_nonzero ** 2 - 4 * c2_nonzero * (c0_nonzero - x_nonzero))) / (2 * c2_nonzero)
        dataset["xvalue"].values = a
        dataset["xvalue"].attrs.update({"units":units_match["dspacing"]})
        dataset.attrs["x_unit"] = "dspacing"
        return dataset

    def get_I_d(self,dataset):
        # dataset.attrs.get("x_unit", None)
        # if dataset.attrs.get("x_unit",None) == "dspacing":
        if True:
            x = dataset["xvalue"].values
            y = dataset["histogram"].values
            e = dataset["error"].values
            y = y.astype(np.float64)
            for i in range(x.shape[0]):
                if i == 0:
                    x_final = x[0]
                    y_final = y[0]
                else:
                    y_tmp, _ = rebin(x[i,:], y[i,:], e[i,:], x_final)
                    y_final +=y_tmp
            return x_final, y_final
        else:
            pass

    def check_anchor(self, anchor_point, std, threshold=0.1):
        for i, d in enumerate(std):
            res = np.abs(anchor_point - d)
            if res < threshold:
                return True, i
        print(
            f'the anchor point {anchor_point} does not exist with the threshold {threshold}.')
        return False, None

    def __group_data_to_d(self, pixels_per_tube, group_along_tube_tof, group_cross_tube_tof,
                                group_along_tube_d, group_cross_tube_d):
        #return dspacing
        dataset = self.nd.copy()
        task_grp = GroupNeutronData()
        task_unit = UnitConvertNeutronData()
        if group_along_tube_tof>1 or group_cross_tube_tof>1:
            dataset = task_grp.group_nd(dataset, pixels_per_tube, group_along_tube_tof,group_cross_tube_tof)

        dataset = task_unit.run(dataset,"dspacing")
        if group_along_tube_d > 1 or group_cross_tube_d > 1:
            dataset = task_grp.group_nd(dataset, pixels_per_tube, group_along_tube_d,group_cross_tube_d)

        return dataset


    def __smooth_data(self, y, is_smooth, smooth_para):
        if is_smooth and smooth_para is not None:
            return smooth(y, smooth_para[0], smooth_para[1])
        return y

    def __fit_peaks(self,x, smoothed_y, peaks_position, high_width_para,
                    fit_function, goodness_bottom):
        #d_peak and I_peak can plot extract peak
        #peak includes [d_peak,y_fitted]
        peak = []
        d_position_exp = []
        all_d_peak = []
        all_I_peak = []
        for idx, d in enumerate(peaks_position):
            is_peak, d_peak, I_peak = auto_extract_peak_data(x, smoothed_y, d,
                                                             high_width_para[idx][0],
                                                             high_width_para[idx][1],high_width_para[idx][2])
            # plt.plot(d_peak,I_peak,label=str(d))
            # plt.legend()
            # plt.title("extract peaks")
            # plt.show()

            d_exp, popt = self.__fit_peak(d_peak, I_peak, fit_function)

            if popt is None or d_exp <= d_peak.min() or d_exp >= d_peak.max():
                d_position_exp.append(0)
                continue

            y_fitted = asymmetric_gaussian(d_peak, *popt) if fit_function == 'asymmetric_gaussian' else gaussian(
                d_peak, *popt)
            peak.append([d_peak, y_fitted])
            all_d_peak.append(d_peak)
            all_I_peak.append(I_peak)
            #print(goodness_of_fit(y_fitted, I_peak))
            if goodness_of_fit(y_fitted, I_peak) > goodness_bottom:
                d_position_exp.append(d_exp)
            else:
                d_position_exp.append(0)

        return d_position_exp, peak, all_d_peak, all_I_peak

    def __fit_peak(self, d_peak, I_peak, fit_function):
        #return d position of experiment, and fit parameters(popt)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            try:
                if fit_function == 'asymmetric_gaussian':
                    A_guess = max(I_peak)
                    x0_guess = d_peak[np.argmax(I_peak)]
                    sigma1_guess = (x0_guess - d_peak[np.where(I_peak > A_guess / 2)[0][0]]) / 2
                    sigma2_guess = (d_peak[np.where(I_peak > A_guess / 2)[0][-1]] - x0_guess) / 2
                    initial_guess = [A_guess, x0_guess, sigma1_guess, sigma2_guess]
                    popt, _ = curve_fit(asymmetric_gaussian, d_peak, I_peak, p0=initial_guess, maxfev=10000)
                    d_exp = popt[1]
                else:
                    is_fit, popt = fit_gaussian(d_peak, I_peak)
                    d_exp = popt[0]
                if len(w) > 0:
                    return 0, None
            except Exception as e:
                # print(f"An error occurred during fitting: {e}, so skip this peak")
                return 0, None
        return d_exp, popt

    def __plot_check(self,name, x, y, smoothed_y, peak, all_d_peak, all_I_peak, peaks_position):
        fig, ax = plt.subplots()
        ax.plot(x, y, 'g-', label='intensity')
        ax.plot(x, smoothed_y, 'b-', label='smoothed_intensity')
        for i in range(len(peak)):
            ax.plot(peak[i][0], peak[i][1], 'r-', label='Fitted Gaussian')
            ax.plot(all_d_peak[i], all_I_peak[i], 'rx')
        for j in peaks_position:
            ax.axvline(x=j, color='black', linestyle='--', linewidth=1,
                       label='Standard Peak Position' if j == peaks_position[0] else "")
        plt.grid(True)
        plt.title(name)
        plt.legend()
        plt.show()

    def __filter_valid_peaks(self,tof_position_exp, peaks_position):
        # return peak position in tof, and standard peak position in dspacing
        exp = []
        std = []
        for idx, value in enumerate(tof_position_exp):
            if value != 0.0:
                exp.append(value)
                std.append(peaks_position[idx])
        return exp, std

    def __mask_pixel(self, idx, c1_unoffset):
        print("mask pixel index: ", str(idx))
        self.info["offset"][idx] = [0.0, c1_unoffset[idx], 0.0]
        self.info["mask"][idx] = 0

    def __fit_offset(self, idx,order, exp, std, x,y,smoothed_y, c1_unoffset,
                     anchor_point, mode, check_point, peaks_position):
        plot_list = []
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            warnings.filterwarnings("ignore", "Covariance of the parameters could not be estimated",
                                    category=UserWarning)  # 两点进行线性拟合时该警告必弹出，因此忽略
            try:
                if order == 'linear':
                    plot_list = self.__fit_linear_offset(idx, exp, std, x,y,smoothed_y, c1_unoffset, anchor_point, mode, check_point,
                                      peaks_position)
                elif order == 'quadratic':
                    plot_list = self.__fit_quadratic_offset(idx, exp, std, x,y,smoothed_y, c1_unoffset, anchor_point, mode, check_point,
                                         peaks_position)
            except Exception as e:
                print(f"An error occurred during fitting: {e}")
                self.__mask_pixel(idx,c1_unoffset)
            if len(w) > 0:
                print(f'checked warnings in offset fit, so masked this pixel {str(idx).zfill(4)}')
                # for warning in w:
                #     print(f'Warning: {warning.message}')
                self.__mask_pixel(idx,c1_unoffset)
        return plot_list

    def __fit_linear_offset(self, idx, exp, std, x,y,smoothed_y, c1_unoffset, anchor_point,
                                mode, check_point, peaks_position):
        initial_guess = [1, 1]
        if anchor_point is not None and isinstance(anchor_point, float):
            isanchor, anchor_id = self.check_anchor(anchor_point, std, threshold=0.1)
            if isanchor is False:
                self.__mask_pixel(idx, c1_unoffset)
                return []
            popt, _ = curve_fit(lambda d, C1: exp[anchor_id] + C1 * (d - std[anchor_id]), std, exp, p0=initial_guess[1])
            C1 = popt[0]
            C0 = exp[anchor_id] - C1 * std[anchor_id]
        else:
            popt, _ = curve_fit(lambda d, C0, C1: C0 + C1 * d, std, exp, p0=initial_guess)
            C0, C1 = popt
        tof = x * c1_unoffset[idx]
        d_offset = self.tof2d(tof, C0, C1, 0)
        self.info["offset"][idx] = [C0, C1, 0.0]
        return [x, y, smoothed_y, d_offset, peaks_position]
        # if mode == 'check' and idx == check_point:
        #     self.__plot_fitted_curve(std, exp, idx, self.info, 'linear')
        #     self.__plot_offset_data(x, y, smoothed_y, d_offset, peaks_position)

    def __fit_quadratic_offset(self, idx,exp, std, x,y,smoothed_y, c1_unoffset, anchor_point,
                               mode, check_point, peaks_position):
        initial_guess = [1, 40000, 1]
        if anchor_point is not None and isinstance(anchor_point, float):
            isanchor, anchor_id = self.check_anchor(anchor_point, std, threshold=0.1)
            if isanchor is False:
                mask_pixel(self, idx, pixels_per_tube, group_along_tube, group_cross_tube, c1_unoffset)
                return []
            popt, _ = curve_fit(
                lambda d, c1, c2: exp[anchor_id] + c1 * (d - std[anchor_id]) + c2 * (d - std[anchor_id]) ** 2, std, exp,
                p0=initial_guess[1:3], maxfev=100000)
            C2 = popt[1]
            C1 = popt[0] - 2 * C2 * std[anchor_id]
            C0 = exp[anchor_id] + C2 * (std[anchor_id] ** 2) - C1 * std[anchor_id]
        else:
            popt, _ = curve_fit(lambda d, C0, C1, C2: C0 + C1 * d + C2 * (d ** 2), std, exp, p0=initial_guess)
            C0, C1, C2 = popt
        tof = x * c1_unoffset[idx]
        d_offset = self.tof2d(tof, C0, C1, C2)
        self.info["offset"][idx] = [C0, C1, C2]
        return [x, y, smoothed_y, d_offset, peaks_position]
        # if mode == 'check' and idx == check_point:
        #     self.__plot_fitted_curve(std, exp, idx, self.info, 'quadratic')
        #     self.__plot_offset_data(x, y, smoothed_y, d_offset, peaks_position)

    def __plot_fitted_curve(self, std, exp, idx, info, order):
        C0 = info['offset'][idx][0]
        C1 = info['offset'][idx][1]
        C2 = info['offset'][idx][2]
        if order == 'linear':
            tof_fitted = linear_func(std, C0, C1)
            plt.title('Linear Fit: tof = C0 + C1 * d')
        elif order == 'quadratic':
            tof_fitted = quadratic_func(std, C0, C1, C2)
            plt.title('Quadratic Fit: tof = C0 + C1 * d + C2 * d^2')
        plt.scatter(std, exp, color='blue', label='Original Data')
        plt.plot(std, tof_fitted, color='red', label='Fitted Curve')
        plt.xlabel('d_std')
        plt.ylabel('Time-of-Flight (tof_exp)')
        plt.legend()
        plt.show()

    def __plot_offset_data(self,x, y, smoothed_y, d_offset, peaks_position):
        fig, ax = plt.subplots()
        ax.plot(x, y, 'g-', label='Original Data')
        ax.plot(x, smoothed_y, 'b-', label='Original Data (smoothed)')
        ax.plot(d_offset, smoothed_y, 'r-', label='Offset Data (smoothed)')
        for j in peaks_position:
            ax.axvline(x=j, color='black', linestyle='--', linewidth=1,
                       label='Standard Peak Position' if j == peaks_position[0] else "")
        # ax.legend()
        plt.grid(True)
        plt.legend()
        plt.show()




    # def fit_one_peak(self, peak_position, high_width_para=None, fit_function='gaussian', gof_standard=0.95, group=1, group_mode='direct', is_smooth=False, smooth_para=None, mode='cal', check_point=0):
    #     if high_width_para is None:
    #         high_width_para = [0.95, 0.01]
    #     d_arr = (self.UnitConverter.tof_to_dspacing(self.nd["xvalue"])).values
    #     y_arr = self.nd["histogram"].values
    #     #be = time.time()
    #     for idx in range(y_arr.shape[0]):
    #         if (idx + 1) % group == 0:
    #             self.info["group"][idx] = group
    #             # print(f"start with index: {idx}")
    #             if group_mode == 'direct':
    #                 tof_arr = self.nd['xvalue'].values
    #                 x = tof_arr[idx]
    #                 y = y_arr[idx].astype(np.float64)
    #                 for i in range(idx + 1 - group, idx):
    #                     y += y_arr[i]
    #                 grouped_x = np.sum(self.nd['positions'][(idx + 1 - group):(idx + 1), 0]) / group
    #                 grouped_y = np.sum(self.nd['positions'][(idx + 1 - group):(idx + 1), 1]) / group
    #                 grouped_z = np.sum(self.nd['positions'][(idx + 1 - group):(idx + 1), 2]) / group
    #                 grouped_l, grouped_theta = get_l_theta(self.nd['l1'], grouped_x,grouped_y,grouped_z,False)
    #                 # print(grouped_l,grouped_theta)
    #                 x = x / (505.4 * grouped_l.values * np.sin(grouped_theta.values))
    #             elif group_mode == 't2d':
    #                 x = d_arr[idx]
    #                 y = y_arr[idx].astype(np.float64)
    #                 for i in range(idx + 1 - group, idx):
    #                     x_old = d_arr[i]
    #                     y_old = y_arr[i]
    #                     e_old = np.full(y_old.shape, 10)
    #                     y_new,_ = rebin(x_old,y_old,e_old,x)
    #                     y += y_new
    #             if is_smooth is True and smooth_para is not None:
    #                 smoothed_y = smooth(y, smooth_para[0], smooth_para[1])
    #             else:
    #                 smoothed_y = y
    #
    #             is_peak, d_peak, I_peak = auto_extract_peak_data(x, smoothed_y, peak_position, high_width_para[0], high_width_para[1])
    #             # print(is_peak)
    #             if is_peak:
    #                 try:
    #                     if fit_function == 'asymmetric_gaussian':
    #                         # 设置初始猜测
    #                         A_guess = max(I_peak)  # 峰值
    #                         x0_guess = d_peak[np.argmax(I_peak)]  # 峰位置
    #                         sigma1_guess = (x0_guess - d_peak[np.where(I_peak > A_guess / 2)[0][0]]) / 2  # 左侧宽度估计
    #                         sigma2_guess = (d_peak[np.where(I_peak > A_guess / 2)[0][-1]] - x0_guess) / 2  # 右侧宽度估计
    #
    #                         initial_guess = [A_guess, x0_guess, sigma1_guess, sigma2_guess]
    #                         popt, pcov = curve_fit(self.asymmetric_gaussian, d_peak, I_peak, p0=initial_guess, maxfev=10000)
    #                         if popt is None:
    #                             for i in range(idx + 1 - group, idx + 1):
    #                                 self.info["mask"][i] = 0
    #                             continue
    #                         elif popt[1] <= d_peak.min() or popt[1] >= d_peak.max():
    #                             for i in range(idx + 1 - group, idx + 1):
    #                                 self.info["mask"][i] = 0
    #                             continue
    #                         d_exp = popt[1]
    #                     else:
    #                         is_fit, popt = fit_gaussian(d_peak, I_peak)
    #                         if popt is None:
    #                             for i in range(idx + 1 - group, idx + 1):
    #                                 self.info["mask"][i] = 0
    #                             continue
    #                         elif popt[0] <= d_peak.min() or popt[0] >= d_peak.max():
    #                             for i in range(idx + 1 - group, idx + 1):
    #                                 self.info["mask"][i] = 0
    #                             continue
    #                         d_exp = popt[0]
    #                 except Exception as e:
    #                     print(f"An error occurred during peak fitting: {e}, so mask it")
    #                     for i in range(idx + 1 - group, idx + 1):
    #                         self.info["mask"][i] = 0
    #                     continue
    #                 if fit_function == 'asymmetric_gaussian':
    #                     y_fitted = self.asymmetric_gaussian(d_peak, *popt)
    #                 else:
    #                     y_fitted = gaussian(d_peak, *popt)
    #
    #                 if mode == 'check' and (idx + 1) // group == check_point:
    #                     # 绘制原始数据和检测到的峰
    #                     fig, ax = plt.subplots()
    #                     ax.plot(x, y, 'g-', label='intensity')
    #                     ax.plot(x, smoothed_y, 'b-', label='smoothed_intensity')
    #                     ax.plot(d_peak, y_fitted, 'r-', label='Fitted Gaussian')
    #                     ax.plot(d_peak, I_peak, 'rx')
    #                     ax.axvline(x=peak_position, color='black', linestyle='--', linewidth=1,
    #                                    label='Standard Peak Position')  # Add label only to the first line for legend
    #                     ax.legend()
    #                     plt.grid(True)
    #                     plt.show()
    #                     return
    #
    #                 rr = goodness_of_fit(y_fitted, I_peak)
    #                 if rr > gof_standard:
    #                     self.info["offset"][idx] = peak_position / d_exp - 1
    #                 else:
    #                     print(f'the goodness of peak fit is {rr}, less than {gof_standard}, mask it.')
    #                     for i in range(idx + 1 - group, idx + 1):
    #                         self.info["mask"][i] = 0
    #                     continue
    #             else:
    #                 print(f'the peak finding in pixel{idx + 1} failed, mask it')
    #                 for i in range(idx + 1 - group, idx + 1):
    #                     self.info["mask"][i] = 0
    #         else:
    #             self.info["offset"][idx] = 0
    #             self.info["mask"][idx] = 1
    #             self.info['group'][idx] = 0
    #     write_cal(self.info)
    #     print(f'offset file has been saved in {self.info["save_file"]} successfully')
    #     print('the number of masked pixels:', np.sum(self.info["mask"] == 0))
    #     print('the masking rate:', np.sum(self.info["mask"] == 0) / len(self.info["mask"]))
    #
    # def check_fit(self,peak_position,idx,rel_height=0.95,manual_width=0.05,gof_standard=0.95):
    #     xarr = (self.UnitConverter.tof_to_dspacing(self.nd["xvalue"])).values
    #     yarr = self.nd["histogram"].values
    #     x = xarr[idx]
    #     y = yarr[idx]
    #     y = smooth(y,21,3)
    #     plt.plot(x,y)
    #     plt.show()
    #     res, x_extract,y_extract = auto_extract_peak_data(x,y,peak_position,rel_height,manual_width)
    #     if res:
    #         res,params = fit_gaussian(x_extract,y_extract)
    #         if res:
    #             y_fit = gaussian(x_extract,*params)
    #             gof = goodness_of_fit(y_fit,y_extract)
    #             print(gof,peak_position/params[0]-1)
    #             plt.plot(x_extract,y_extract,"o")
    #             plt.plot(x_extract,y_fit)
    #         else:
    #             plt.plot(x_extract,y_extract,"o")
    #         plt.show()
    #     #print("finish time: ",time.time()-be)
    #     #print(errList)
    def __process_pixel(self, idx, x_matrix, y_matrix, c1_unoffset, peaks_position, high_width_para,
                        fit_function, goodness_bottom, anchor_point, mode, check_point, sub_background,
                        is_smooth, smooth_para, least_peaks_num, order, name,ui=False):
        if mode == 'check' and idx != check_point:
            return []
        x = x_matrix[idx]
        y = y_matrix[idx]
        y = y.astype(np.float64)
        x = x.astype(np.float64)
        if sub_background:
            background = baseline_alg(y, lam=1e5, p=0.01)
            y -= background
        if y.max() > 0:
            y /= y.max()
        smoothed_y = self.__smooth_data(y, is_smooth, smooth_para)

        d_position_exp, peak, all_d_peak, all_I_peak = self.__fit_peaks(x, smoothed_y, peaks_position,
                                                                        high_width_para, fit_function,
                                                                        goodness_bottom)
        plot_info = []
        if mode == 'check' and idx == check_point:
            print('pixel:' + str(idx))
            if ui is True:
                plot_info.append([name, x, y, smoothed_y, peak, all_d_peak, all_I_peak, peaks_position])
            else:
                self.__plot_check(name, x, y, smoothed_y, peak, all_d_peak, all_I_peak, peaks_position)

        tof_position_exp = np.array(d_position_exp) * c1_unoffset[idx]
        exp, std = self.__filter_valid_peaks(tof_position_exp, peaks_position)
        if len(exp) < least_peaks_num:
            self.__mask_pixel(idx, c1_unoffset)
        else:
            plot_list = self.__fit_offset(idx, order, exp, std, x, y, smoothed_y, c1_unoffset,
                              anchor_point, mode, check_point, peaks_position)

            if mode == 'check' and idx == check_point:
                if ui is True:
                    plot_info.append([std, exp, self.info["offset"][idx], order])
                    plot_info.append(plot_list)
                else:
                    self.__plot_fitted_curve(std, exp, idx, self.info, order)
                    self.__plot_offset_data(x, y, smoothed_y, plot_list[3], peaks_position)
        return plot_info

    def fit_multiple_peaks(self, dataset, save_path, peaks_position, high_width_para, pixels_per_tube,
                                                  sub_background=True, fit_function='gaussian', goodness_bottom=0.95,
                                                  is_smooth=False, smooth_para=None, least_peaks_num=3,
                                                    group_along_tube_tof=1, group_cross_tube_tof=1,
                                                    group_along_tube_d=1, group_cross_tube_d=1,
                                                    order='linear', mode='cal',
                                                  check_point=1, anchor_point=None, parallel=False, max_workers=4, ui=False):
        #be = time.time()
        check_dir(save_path)
        save_file = save_path + "/" + dataset.attrs["name"] + "_offset.cal"
        self.nd = dataset
        self.info = {}
        self.info["save_file"] = save_file
        self.info["group_along_tube_tof"] = group_along_tube_tof
        self.info["group_cross_tube_tof"] = group_cross_tube_tof
        self.info["group_along_tube_d"] = group_along_tube_d
        self.info["group_cross_tube_d"] = group_cross_tube_d
        self.info["pixels_per_tube"] = pixels_per_tube
        self.nd = self.__group_data_to_d(pixels_per_tube, group_along_tube_tof, group_cross_tube_tof,
                                         group_along_tube_d, group_cross_tube_d)

        l, theta = get_l_theta(self.nd['l1'].item(), self.nd['positions'].values[:, 0],
                              self.nd['positions'].values[:, 1],
                              self.nd['positions'].values[:, 2], False)
        c1_unoffset = l * np.sin(theta) * FACTOR_MP

        self.info["pixel"] = self.nd.coords["pixel"].values
        self.info["index"] = np.arange(0, len(self.info["pixel"]))
        self.info["group"] = np.ones(len(self.info["pixel"]))
        self.info["mask"] = np.ones(len(self.info["pixel"]))
        self.info['offset'] = np.zeros((len(self.info["pixel"]), 3))
        name = self.nd.attrs["name"]
        if mode == 'check':
           print(name)
        x_matrix = self.nd["xvalue"].values
        y_matrix = self.nd["histogram"].values
        all_plot_info = []
        if parallel:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(self.__process_pixel, idx, x_matrix, y_matrix, c1_unoffset, peaks_position,
                                           high_width_para, fit_function, goodness_bottom, anchor_point, mode,
                                           check_point, sub_background, is_smooth, smooth_para, least_peaks_num,
                                           order, name) for idx in range(len(c1_unoffset))]
                for future in as_completed(futures):
                    future.result()

        else:
           for idx in range(len(c1_unoffset)):
               plot_info = self.__process_pixel(idx, x_matrix, y_matrix, c1_unoffset, peaks_position,
                                           high_width_para, fit_function, goodness_bottom, anchor_point, mode,
                                           check_point, sub_background, is_smooth, smooth_para, least_peaks_num,
                                           order, name,ui)
               all_plot_info.append(plot_info)
        #print(time.time()-be,"seconds")
        if ui is True:
            return all_plot_info
        else:
            write_cal(self.info)
            print(f'offset file has been saved in {self.info["save_file"]} successfully')
            print('the number of masked pixels:', np.sum(self.info["mask"] == 0))
            print('the masking rate:', np.sum(self.info["mask"] == 0) / len(self.info["mask"]))
            return all_plot_info

    def __get_pixel_data(self, idx, x_matrix, y_matrix, c1_unoffset, peaks_position, high_width_para,
                        fit_function, goodness_bottom, anchor_point, check_point, sub_background,
                        is_smooth, smooth_para, least_peaks_num, order, name):
        if idx != check_point:
            pass
        else:
            x = x_matrix[idx]
            y = y_matrix[idx]
            y = y.astype(np.float64)
            x = x.astype(np.float64)
            if sub_background:
                background = baseline_alg(y, lam=1e5, p=0.01)
                y -= background
            if y.max() > 0:
                y /= y.max()
            smoothed_y = self.__smooth_data(y, is_smooth, smooth_para)

            d_position_exp, peak, all_d_peak, all_I_peak = self.__fit_peaks(x, smoothed_y, peaks_position,
                                                                        high_width_para, fit_function,
                                                                        goodness_bottom)

            print('pixel:' + str(idx))
            self.__plot_check(name, x, y, smoothed_y, peak, all_d_peak, all_I_peak, peaks_position)
            tof_position_exp = np.array(d_position_exp) * c1_unoffset[idx]
            exp, std = self.__filter_valid_peaks(tof_position_exp, peaks_position)
            std = std[::-1]
            exp = exp[::-1]
            print("results: ", std,exp)
            # plt.plot(std,exp,'o')
            # plt.xlabel("dspacing")
            # plt.ylabel("tof")
            # plt.show()

    def get_multiple_peaks(self, dataset, peaks_position, high_width_para, pixels_per_tube,
                           sub_background=True, fit_function='gaussian', goodness_bottom=0.95,
                           is_smooth=False, smooth_para=None, least_peaks_num=3, group_along_tube=1,
                           group_cross_tube=1, group_mode='direct', order='linear',
                           check_point=1, anchor_point=None):
        self.nd = dataset
        self.info = {}
        self.nd = self.__group_data_to_d(pixels_per_tube, group_along_tube_tof, group_cross_tube_tof,
                                         group_along_tube_d, group_cross_tube_d)

        l, theta = get_l_theta(self.nd['l1'].item(), self.nd['positions'].values[:, 0],
                              self.nd['positions'].values[:, 1],
                              self.nd['positions'].values[:, 2], False)
        c1_unoffset = l * np.sin(theta) * FACTOR_MP
        name = self.nd.attrs["name"]
        print(name)
        x_matrix = self.nd["xvalue"].values
        y_matrix = self.nd["histogram"].values

        for idx in range(len(c1_unoffset)):
            self.__get_pixel_data(idx, x_matrix, y_matrix, c1_unoffset, peaks_position,
                              high_width_para, fit_function, goodness_bottom, anchor_point,
                              check_point, sub_background, is_smooth, smooth_para, least_peaks_num,
                               order, name)
