import numpy as np
from rongzai.dataSvc import create_dataset
from rongzai.algSvc.base import rebin,rebin_2D
def rebin_neutron_data(dataset,x_new):
    xarr = dataset["xvalue"].values
    yarr = dataset["histogram"].values
    earr = dataset["error"].values
    #print("raw x:",xarr)
    xnew,ynew,enew = rebin_2D(xarr,yarr,earr,x_new)
    #print("rebin_neutron_data:",xnew,ynew.sum())
    pos = dataset["positions"].values
    pixel = dataset['positions'].coords['pixel'].values
    data = create_dataset(ynew,enew,xnew,pixel,pos,
                        dataset['proton_charge'],dataset['l1'])
    return data

def mask_neutron_data(dataset,mask_list):
    dataset["histogram"].values[mask_list==0,:] = 0
    return dataset

def crop_neutron_data(dataset,xmin,xmax):
    ##crop后不要置0，而是直接切掉吧
    xarr = dataset["xvalue"].values
    # print(xmin,xmax,xarr)
    indices = [np.argmax(row > xmin) for row in xarr]
    # 取这些序列号的最大值
    idx1 = max(indices)
    indices = [np.argmax(row > xmax) if np.any(row > xmax) else len(row) for row in xarr]
    idx2 = min(indices)
    # xvalue_data = dataset["xvalue"].values
    histogram_data = dataset["histogram"].values
    error_data = dataset["error"].values
    new_xvalue_data = xarr[:, idx1:idx2]
    new_histogram_data = histogram_data[:, idx1:idx2]
    new_error_data = error_data[:,idx1:idx2]
    # xvalue_dims = dataset["xvalue"].dims
    # histogram_dims = dataset["histogram"].dims
    # error_dims = dataset["error"].dims
    pos = dataset["positions"].values
    pixel = dataset['positions'].coords['pixel'].values
    module = dataset.attrs.get("name",None)
    unit = dataset.attrs.get("x_unit",None)
    # print(module,unit)
    data = create_dataset(new_histogram_data,new_error_data,new_xvalue_data,
                        pixel,pos,dataset['proton_charge'],dataset['l1'],module=module,unit=unit)

    # dataset["xvalue"] = (xvalue_dims, new_xvalue_data)
    # dataset["histogram"] = (histogram_dims, new_histogram_data)
    # dataset["error"] = (error_dims, new_error_data)
    return data


def focus_neutron_data_int(dataset):
    if dataset["histogram"].values.ndim != 2:
        raise ValueError("input data histogram must be 2D")
    x = dataset["xvalue"].values
    x_min = np.min(x[:,0])
    x_max = np.max(x[:,-1])
    step = x[0,1] - x[0,0]
    xnew = np.arange(x_min,x_max,step)
    pos = dataset["positions"].values[0]
    pixel = dataset['positions'].coords['pixel'].values[0]
    name = dataset.attrs.get("name")
    for i in range(dataset["histogram"].values.shape[0]):
        xold = x[i, :]
        if np.all(xold == 0) or xold[-1]<=xnew[0]:
            continue
        y = dataset['histogram'].values[i, :]
        # e = dataset['error'].values[i, :]
        if i == 0:
            ds_data,_ = np.histogram(xold,weights=y,bins=xnew)
            # ds_error = np.sqrt(ds_data)
            #ds_data, ds_error = rebin(xold, y, e, xnew)
        else:
            ytmp,_ = np.histogram(xold,weights=y,bins=xnew)
            ds_data += ytmp
            # ds_error = np.sqrt(ds_error ** 2 + etmp ** 2)
    #print(xnew.size, ds_data.size)
    ds_error = np.sqrt(ds_data)
    if ds_data.sum()<100:
        ds_data = np.zeros(xnew.size)
        ds_error = np.zeros(xnew.size)
    data = create_dataset(ds_data,ds_error,xnew[:-1],pixel,pos,
                        dataset['proton_charge'],dataset['l1'],name)
    return data
def focus_neutron_data(dataset):

    if dataset["histogram"].values.ndim != 2:
        raise ValueError("input data histogram must be 2D")
    x = dataset["xvalue"].values
    x_min = np.min(x[:,0])
    x_max = np.max(x[:,-1])
    step = x[0,1] - x[0,0]
    xnew = np.arange(x_min,x_max,step)
    pos = dataset["positions"].values[0]
    pixel = dataset['positions'].coords['pixel'].values[0]
    name = dataset.attrs.get("name")
    unit = dataset.attrs.get("x_unit")
    for i in range(dataset["histogram"].values.shape[0]):
        xold = x[i, :]
        if np.all(xold == 0) or xold[-1]<=xnew[0]:
            continue
        y = dataset['histogram'].values[i, :]
        e = dataset['error'].values[i, :]
        if i == 0:
            ds_data, ds_error = rebin(xold, y, e, xnew)
        else:
            ytmp,etmp = rebin(xold,y,e,xnew)
            ds_data += ytmp
            ds_error = np.sqrt(ds_error ** 2 + etmp ** 2)
    #print(xnew.size, ds_data.size)
    if ds_data.sum()<100:
        ds_data = np.zeros(xnew.size)
        ds_error = np.zeros(xnew.size)
    data = create_dataset(ds_data,ds_error,xnew,pixel,pos,
                        dataset['proton_charge'],dataset['l1'],name,unit=unit)
    return data

def divide_dataset(dataset_left,dataset_right):
    unit = dataset_left.attrs.get("x_unit")
    name = dataset_left.attrs.get("name")
    yleft = dataset_left["histogram"].values
    yright = dataset_right["histogram"].values
    eleft = dataset_left["error"].values
    # eright = dataset_right["error"].values
    #eleft = dataset_left["error"].values
    xleft = dataset_left["xvalue"].values
    # xright = dataset_right["xvalue"].values
    xnew = dataset_left["xvalue"].values[0]
    datanew = np.zeros((yleft.shape[0],xnew.size))
    errnew = np.zeros((datanew.shape))
    xarrnew = np.zeros((datanew.shape))
    for i in range(xleft.shape[0]):
        xold = xleft[i,:]
        yold = yleft[i,:]
        eold = eleft[i,:]
        #xnew = xright[i,:]
        ynew,enew = rebin(xold,yold,eold,xnew)
        tmp = yleft/ynew
        datanew[i,:]=tmp
        xarrnew[i,:]=xnew
        errnew[i,:]=tmp*np.sqrt((enew/ynew)**2+(eleft/yleft)**2)
    #dataset = dataset_left.copy()

    pos = dataset_left["positions"].values
    pixel = dataset_left['positions'].coords['pixel'].values
    dataset = create_dataset(datanew,errnew,xarrnew,pixel,pos,
                    dataset_left['proton_charge'],dataset_left['l1'],name,unit=unit)
    # dataset["histogram"] = datanew
    # dataset["error"]=errnew
    # dataset["xvalue"]=xarrnew
    return dataset

def filter_dataset_by_pixels(dataset, pixel_numbers):
    hist = dataset['histogram'].values
    error = dataset['error'].values
    x = dataset['xvalue'].values
    pos = dataset['positions'].values
    pixel = dataset['positions'].coords['pixel'].values
    pixel_indices = [np.where(pixel == p)[0][0] for p in pixel_numbers if p in pixel]

    hist_filtered = hist[pixel_indices, :]
    error_filtered = error[pixel_indices, :]
    x_filtered = x[pixel_indices, :]
    pos_filtered = pos[pixel_indices, :]
    pixel_filtered = pixel[pixel_indices]

    new_dataset = create_dataset(
        hist_filtered,
        error_filtered,
        x_filtered,
        pixel_filtered,
        pos_filtered,
        dataset['proton_charge'].values,
        dataset['l1'].values,
        module=dataset.attrs.get("name"),
        unit=dataset.attrs.get("x_unit")
    )
    return new_dataset

def get_position_by_pixel_id(dataset,target_pixel_id):
    try:
        position = dataset["positions"].sel(pixel=target_pixel_id).values
        l1 = dataset["l1"].values
        return l1,position
    except:
        raise Exception("error in neutron_data")