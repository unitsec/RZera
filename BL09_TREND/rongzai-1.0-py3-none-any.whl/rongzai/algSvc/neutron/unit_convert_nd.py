
from rongzai.utils.constants import *
from rongzai.algSvc.base import get_l_theta
from rongzai.algSvc.neutron import check_reverse_neutron_data

class UnitConvertNeutronData():
    def __init__(self):
        # FACTOR_MP = 505.5568
        self.h_m_n = 2/FACTOR_MP

    def __get_l_theta_nd(self,dataset):
        pos = dataset["positions"].values
        dr = dataset.attrs.get("name",None)
        if dr is None:
            print("================")
            print(dataset)
        if dataset.attrs.get('name', None)[:7] == "monitor":
            l, theta = get_l_theta(dataset["l1"].values, pos[:, 0],
                                             pos[:, 1], pos[:, 2], True)
        else:
            l, theta = get_l_theta(dataset["l1"].values, pos[:, 0],
                                             pos[:, 1], pos[:, 2], False)
        return l,theta
    def run(self, dataset, unit_out):
        self.l,self.theta = self.__get_l_theta_nd(dataset)
        unit_in = dataset.attrs.get("x_unit",None)
        if unit_in == unit_out:
            raise Exception("Error: same units")
        method_name = f"{unit_in}_to_{unit_out}"
        method = getattr(self,method_name)
        x_old = dataset["xvalue"].values
        x_new = method(x_old)
        dataset["xvalue"].values = x_new
        dataset.attrs["x_unit"] = unit_out
        dataset["xvalue"].attrs.update({"unit": units_match[unit_out]})
        return check_reverse_neutron_data(dataset)

    def tof_to_dspacing(self,x):
        return x/FACTOR_MP/self.l[:,np.newaxis]/np.sin(self.theta[:,np.newaxis])
    def dspacing_to_tof(self,x):
        return x*FACTOR_MP*self.l[:,np.newaxis]*np.sin(self.theta[:,np.newaxis])
    # def tof_to_velocity(self, time_of_flight):
    #     """将飞行时间转换为速度。"""
    #     return self.flight_distance / time_of_flight
    def tof_to_wavelength(self,x):
        # flight_time (us)
        return self.h_m_n * x / self.l[:,np.newaxis]

    def wavelength_to_tof(self,x):
        return self.l[:,np.newaxis]*x/self.h_m_n

    def wavelength_to_dspacing(self, x):
        ## 波长到d-spacing的转换，使用布拉格定律
        ## wavelength (m)
        ## theta (rad), 散射角的一半
        return x / (2 * np.sin(self.theta[:,np.newaxis]))
    #
    def dspacing_to_q(self,x):
        return 2*np.pi/x
    # def tof_to_q(self,time_of_flight):
    #     wave = self.h_m_n * time_of_flight / self.flight_distance
    #     return self.wavelength_to_q(wave)
    #
    # def wavelength_to_q(self,wavelength):
    #     return 4*np.pi/wavelength*np.sin(self.theta)
    #
    # def dspacing_to_tof(self,dspacing):
    #     wavelength = self.dspacing_to_wavelength(dspacing)
    #     return self.wavelength_to_tof(wavelength)
    #
    # def tof_to_dspacing(self, time_of_flight):
    #     # 飞行时间到d-spacing的转换，结合上面两个转换
    #     # return time_of_flight/(FACTOR_MP)
    #     wavelength = self.tof_to_wavelength(time_of_flight)
    #     return self.wavelength_to_dspacing(wavelength)
    #
    # def dspacing_to_wavelength(self,dspacing):
    #     return dspacing*2*np.sin(self.theta)
    #

    #
    # def tof_to_energy(self,time_of_flight):
    #     #unit is meV
    #     #print(time_of_flight,self.flight_distance)
    #     tof = time_of_flight/1000
    #     #for i in range()
    #     return 10*1.675/3.2*(self.flight_distance/tof)**2
    #     #return 10*neutron_mass*1e27/3.2*(self.flight_distance/tof)**2
    #
    # def velocity_to_wavelength(self, velocity):
    #     """将速度转换为波长。"""
    #     return self.h_m_n / velocity
