import numpy as np
import ctypes
from rongzai.dataSvc import create_dataset
from rongzai.utils.helper import getRZeraLib

class GroupNeutronData():
    def group_nd(self,dataset,pixels_per_tube,group_along_tube,group_cross_tube):
        rzlib = getRZeraLib()
        group_data = rzlib.group_nd
        group_data.argtypes = [
            ctypes.c_size_t, ctypes.c_size_t,
            np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),
            ctypes.c_int, ctypes.c_int, ctypes.c_int,ctypes.POINTER(ctypes.c_size_t),
            np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS'),
            np.ctypeslib.ndpointer(dtype=np.double, flags='C_CONTIGUOUS')
        ]
        position = dataset["positions"].values.astype(np.float64, order='C')
        pixels = dataset["positions"].coords["pixel"].values.astype(np.float64, order='C')
        x_array = dataset["xvalue"].values.astype(np.float64, order='C')
        y_array = dataset["histogram"].values.astype(np.float64, order='C')
        e_array = dataset["error"].values.astype(np.float64, order='C')
        name = dataset.attrs.get('name', None)
        x_unit = dataset.attrs.get("x_unit", None)
        l1 = dataset["l1"]
        pc = dataset["proton_charge"]

        rows, cols = x_array.shape
        final_x = np.zeros((rows, cols), dtype=np.float64, order='C')
        final_y = np.zeros((rows, cols), dtype=np.float64, order='C')
        final_e = np.zeros((rows, cols), dtype=np.float64, order='C')
        final_pos = np.zeros((rows, 3), dtype=np.float64, order='C')
        final_pixel = np.zeros(rows, dtype=np.float64, order='C')
        final_size = ctypes.c_size_t(0)
        group_data(rows,cols,
            x_array,y_array, e_array, position, pixels,
           pixels_per_tube, group_along_tube, group_cross_tube,ctypes.byref(final_size),
            final_x, final_y, final_e, final_pos, final_pixel
        )

        final_x = final_x[:final_size.value, :]
        final_y = final_y[:final_size.value, :]
        final_e = final_e[:final_size.value, :]
        final_pos = final_pos[:final_size.value, :]
        final_pixel = final_pixel[:final_size.value]

        dataset = create_dataset(final_y, final_e, final_x, final_pixel, final_pos, pc, l1, module=name, unit=x_unit)
        return dataset