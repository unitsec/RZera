import numpy as np
from rongzai.dataSvc.data_plot import ScientificPlots
class Show2DNeutronData(ScientificPlots):
    def __init__(self):
        super().__init__()

    def __get_data_from_dataset(self,dataset,pixel_info):
        hist = dataset["histogram"].values
        module=dataset.attrs.get("name")
        data = hist.sum(axis=1)
        x = pixel_info[module]["xpixels"]
        y = pixel_info[module]["ypixels"]
        IDstart = pixel_info[module]["start"]
        pixelData = np.arange(IDstart,int(IDstart+x*y))
        if pixel_info[module]["stepbyrow"] == "y":
            data = data.reshape((y, x), order="F")
            pixelData = pixelData.reshape((y,x),order="F")
        else:
            data = data.reshape((y, x), order="C")
            pixelData = pixelData.reshape((y, x), order="C")
        return data,pixelData
    # def __merge_data_for_bank(self,modules,bl):
    #     arrays = []
    #     arrays_pid = []
    #     for module in modules:
    #         data,pixel = self.__get_data_from_module(module)
    #         arrays.append(data)
    #         arrays_pid.append(pixel)
    #
    #     if bl == "BL09":
    #         arrays = arrays[::-1]
    #         arrays_pid = arrays_pid[::-1]
    #         result = np.hstack(arrays)
    #         result_pid = np.hstack(arrays_pid)
    #     if bl == "BL15":
    #         result = np.hstack(arrays)
    #     return result, result_pid

    def get_roi_from_dataset(self,dataset,pixel_info):
        name = dataset.attrs.get("name")
        data, pids = self.__get_data_from_dataset(dataset,pixel_info)
        self.plot_heatmap(data,title=name, xlabel='X-axis', ylabel='Y-axis')
        try:
            selected_range = self.get_selected_range()
            x1, x2, y1, y2 = selected_range[0][0], selected_range[0][1], selected_range[1][0], selected_range[1][1]
            print(f"Selected x1, x2: {x1}, {x2}")
            print(f"Selected y1, y2: {y1}, {y2}")
            roi = pids[y1:y2+1,x1:x2+1].flatten()
            if roi is None:
                raise ValueError("No roi has been selected yet.")
            return roi
        except ValueError as e:
            print(e)
