import matplotlib.pyplot as plt
import numpy as np
from rongzai.dataSvc import create_dataset
from rongzai.utils.helper import getRZeraLib
from rongzai.algSvc.base import get_l_theta
from ctypes import *
#import xarray as xr
#
class AbsMsCorrNeutronData():
    def __init__(self,dataset):
        position = dataset["positions"].values
        self.l,self.theta = get_l_theta(dataset["l1"].values,position[:,0],
                            position[:,1],position[:,2],False)
        self.nd = dataset
        self.rzlib = getRZeraLib()

    def run_carpenter(self,conf):
        #print("start carpenter: ",self.nd["xvalue"].values.shape[0])
        # new_data2 = self.nd["histogram"].values.copy()
        # err_data2 = self.nd["error"].values.copy()
        new_abs = np.zeros(self.nd["histogram"].shape)
        new_ms = np.zeros(self.nd["histogram"].shape)
        if self.nd["xvalue"].values.ndim == 2:
            for i in range(self.nd["xvalue"].values.shape[0]):

                wave_arr = self.nd["xvalue"].values[i,:]
                input_size = len(wave_arr)
                input_array = (c_double * input_size)(*wave_arr)
                output_abs =  (c_double * input_size)()
                output_ms =  (c_double * input_size)()

                self.rzlib.calculate_abs_correction(
                    c_double(2*self.theta[i]), c_double(conf["radius"]),
                    c_double(conf['atten_xs']), c_double(conf['density_num']),
                    c_double(conf['scatt_xs']),input_array,
                    c_size_t(input_size), output_abs)
                yabs = np.array(output_abs)
                new_abs[i,:]=yabs
                self.rzlib.calculate_ms_correction(
                    c_double(2*self.theta[i]), c_double(conf["radius"]),
                    c_double(conf['atten_xs']), c_double(conf['density_num']),
                    c_double(conf['scatt_xs']),input_array,
                    c_size_t(input_size), output_ms)
                yms = np.array(output_ms)

                new_ms[i,:]=yms
                #new_data2[i,:] = self.nd["histogram"].values[i,:]*(1/yabs-yms)
                #err_data2[i,:] = self.nd["error"].values[i,:]*(1/yabs-yms)
                # new_data2[i] = self.nd["histogram"].values[i] * (1 / yabs - yms)
                # err_data2[i] = self.nd["error"].values[i] * (1 / yabs - yms)
        # print("yms type:",yms.dtype)
        # print((new_data2.dtype))
        new_data = self.nd["histogram"].values*(1/new_abs-new_ms)
        err_data = self.nd["error"].values * (1 / new_abs - new_ms)
        # print((new_data.dtype))
        module = self.nd.attrs.get("name", None)
        unit = self.nd.attrs.get("x_unit", None)
        dataset = create_dataset(new_data,err_data,self.nd["xvalue"].values,
                                self.nd["positions"].coords["pixel"].values,
                                self.nd["positions"].values,
                                self.nd['proton_charge'],self.nd['l1'],module,unit)
        # dataset2 = create_dataset(new_data2, err_data2, self.nd["xvalue"].values,
        #                          self.nd["positions"].coords["pixel"].values,
        #                          self.nd["positions"].values,
        #                          self.nd['proton_charge'], self.nd['l1'], module, unit)
        # dataset_abs = create_dataset(new_abs,err_data,self.nd["xvalue"].values,
        #                         self.nd["positions"].coords["pixel"].values,
        #                         self.nd["positions"].values,
        #                         self.nd['proton_charge'],self.nd['l1'],module,unit)
        # dataset_ms = create_dataset(new_ms,err_data,self.nd["xvalue"].values,
        #                         self.nd["positions"].coords["pixel"].values,
        #                         self.nd["positions"].values,
        #                         self.nd['proton_charge'],self.nd['l1'],module,unit)
        return dataset#,dataset2,dataset_abs,dataset_ms
