from rongzai.algSvc.neutron import (mask_neutron_data,crop_neutron_data,
                            focus_neutron_data,divide_dataset,
                            filter_dataset_by_pixels,
                            Show2DNeutronData)
from rongzai.algSvc.neutron.unit_convert_nd import UnitConvertNeutronData
from rongzai.algSvc.neutron.abs_ms_nd import AbsMsCorrNeutronData
from rongzai.algSvc.neutron.pixel_offset_nd import PixelOffsetCalNeutronData
from rongzai.dataSvc import read_cal

class Diffraction():
    def __init__(self,conf):
        self.pc_factor = 1E7
        self.conf = conf

    def process_tof_to_d(self,dataset,info=None):
        module = dataset.attrs.get("name")
        unit_cvt = UnitConvertNeutronData()
        data = unit_cvt.run(dataset, "wavelength")
        data = crop_neutron_data(data,self.conf["wave_min"],self.conf["wave_max"])
        if info is None:
            pass
        else:
            task = AbsMsCorrNeutronData(data)
            data = task.run_carpenter(info)
            # print(info)
        if self.conf["has_cal"]:
            data =  unit_cvt.run(data,"tof")
            cal_fn = self.conf["cal_path"]+"/"+module+"_offset.cal"
            cal_dict = read_cal(cal_fn)
            task = PixelOffsetCalNeutronData()
            data = task.correct_tof_to_d(data,cal_dict)
            data = mask_neutron_data(data, cal_dict["mask_list"])
        else:
            data = unit_cvt.run(data, "dspacing")
        return data

    def get_sample_roi(self,dataset):
        roi = Show2DNeutronData()
        return roi.get_roi_from_dataset(dataset, self.conf["pixel_info"])

    def calculate_pattern_roi(self,dataset,pixels):
        data = filter_dataset_by_pixels(dataset, pixels)
        data = focus_neutron_data(data)
        return data

    def calculate_pattern(self,dataset,info = None):
        data = self.process_tof_to_d(dataset,info)
        data = focus_neutron_data(data)
        return data

    def get_wavelength_data(self,dataset):
        unit_cvt = UnitConvertNeutronData()
        data = unit_cvt.run(dataset, "wavelength")
        data = focus_neutron_data(data)
        return data

    def time_focusing_sample_AbsMs_roi(self,dataset,info,pixels=None):
        data = self.process_tof_to_d_AbsMs(dataset,info)
        if pixels is None:
            roi = Show2DNeutronData()
            pixels = roi.get_roi_from_dataset(data, self.conf["pixel_info"])
        data = filter_dataset_by_pixels(data, pixels)
        data = focus_neutron_data(data)
        return data, pixels

    def get_monitor_wave(self,dataset,wavemin,wavemax):
        unit_cvt = UnitConvertNeutronData()
        data =  unit_cvt.run(dataset,"wavelength")
        data = crop_neutron_data(data,wavemin,wavemax)
        data = focus_neutron_data(data)
        return data

    def get_monitor_nc(self,dataset):
        data = self.get_monitor_wave(dataset,self.conf["wave_min"],self.conf["wave_max"])
        return data["histogram"].values.sum()

    def normalization_by_wave(self,detdataset,mondataset):
        ###bug
        unit_cvt = UnitConvertNeutronData()
        detdata =  unit_cvt.run(detdataset,"wavelength")
        detdata = divide_dataset(detdata,mondataset)
        detdata =  unit_cvt.run(detdata,"dspacing")
        return detdata
