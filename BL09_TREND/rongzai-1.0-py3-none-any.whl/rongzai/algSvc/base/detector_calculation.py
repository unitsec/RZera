import numpy as np

def get_l_theta(l1,x,y,z,isMonitor):
    #theta is half of scattering angle
    l2 = np.sqrt(x**2+y**2+z**2)
    if isMonitor:
        l = l1-l2
    else:
        l = l1+l2
    theta = 0.5*np.arccos(z/l2)
    return l, theta

def get_solid_angle(x,y,z,theta,px,py):
    return px*py*np.cos(theta)/(x**2+y**2+z**2)