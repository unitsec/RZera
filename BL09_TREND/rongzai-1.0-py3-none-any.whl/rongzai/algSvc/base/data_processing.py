from rongzai.utils.array_utils import mask_nan
from scipy.signal import savgol_filter
import numpy as np

# def strip_peaks(x,y,peaks,left,right):
#     data = y.copy()
#     for peak in peaks:
#         index = np.argmin(np.abs(x - peak))
#         x0,y0 = x[index-left],y[index-left]
#         x1,y1 = x[index+right],y[index+right]
#         m = (y1 - y0) / (x1 - x0)
#         b = y0 - m * x0
#         x_interp = x[index-left:index+right+1]
#         y_interp = m * x_interp + b
#         data[index-left:index+right+1] = y_interp
#     return data

def strip_peaks(x,y,peaks,range):
    data = y.copy()
    for i, peak in enumerate(peaks):
        index = np.argmin(np.abs(x - peak))
        left_edge = x[index] - range[i][0] #确定左侧边缘的d值
        right_edge = x[index] + range[i][1] #确定右侧边缘的d值

        # 找到数据点中离左侧边缘值最近的数据点
        left = np.argmin(np.abs(x - left_edge))
        x0, y0 = x[left], y[left]
        # 找到数据点中离右侧边缘值最近的数据点
        right = np.argmin(np.abs(x - right_edge))
        x1, y1 = x[right], y[right]

        m = (y1 - y0) / (x1 - x0)
        b = y0 - m * x0
        x_interp = x[left:right+1]
        y_interp = m * x_interp + b
        data[left:right+1] = y_interp
    return data

def smooth(data,npoint,order):
    return savgol_filter(data, window_length=npoint, polyorder=order)
def linear_fit(x,y):
    x_filtered,y_filtered = mask_nan(x,y)
    coefficients = np.polyfit(x_filtered, y_filtered, 1)
    polynomial = np.poly1d(coefficients)
    y_fit = polynomial(x_filtered)
    return x_filtered,y_fit

def cal_PDF(r, q, sq,PDF_type,rho0=1,lorch=True):
    dq = q[1]-q[0]
    qcut = q.max()
    #print(qcut)
    mat = np.sin(np.outer(r,  q))
    qiq = (sq - 1.0) * q * dq
    #if True:
    if lorch:
        factor = np.sin(np.pi*q / qcut)/(np.pi * q / qcut)
        qiq = qiq * factor
    integral = np.inner(mat, qiq)

    if PDF_type=="G_r":
        return integral
    if PDF_type=="gr":
        return integral/(4*np.pi*r*rho0)+1
    if PDF_type=="RDF":
        return r*integral+4*np.pi*rho0*r**2