from .data_processing import linear_fit,smooth,strip_peaks, cal_PDF
from .rebin import rebin,rebin_2D,interpolate
from .peak_analysis import baseline_alg,auto_extract_peak_data,fit_gaussian
from .calculate_sample import CalSampleProperty
from .goodness_fit import goodness_of_fit
from .detector_calculation import get_l_theta,get_solid_angle
