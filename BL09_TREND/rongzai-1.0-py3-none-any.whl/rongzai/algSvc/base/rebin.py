from rongzai.utils.helper import getRZeraLib
from rongzai.utils.array_utils import (check_boundaries,mask_nan,
                               change_point_to_boundary, change_boundary_to_point)
from scipy.interpolate import interp1d
import numpy as np
import ctypes
from ctypes import c_double, c_size_t, POINTER


def rebin_2D(x_old, y_old, e_old, x_new):
    rzlib = getRZeraLib()
    rebin_2D = rzlib.rebin_2D
    print("start rebin 2D")
    # 定义C++函数的参数和返回类型
    rebin_2D.argtypes = [
        ctypes.c_size_t,  # rows
        ctypes.c_size_t,  # old_cols
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # x_old
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # y_old
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # e_old
        ctypes.c_size_t,  # new_cols
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # x_new
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS'),  # y_new
        np.ctypeslib.ndpointer(dtype=np.double, ndim=2, flags='C_CONTIGUOUS')  # e_new
    ]

    rows = len(y_old)
    old_cols = len(x_old[0])
    new_cols = len(x_new)
    print("newcols:",new_cols)
    # 确保所有输入数组都是float64类型并且是C连续的
    x_old = np.ascontiguousarray(x_old, dtype=np.float64)
    y_old = np.ascontiguousarray(y_old, dtype=np.float64)
    e_old = np.ascontiguousarray(e_old, dtype=np.float64)
    x_new = np.ascontiguousarray(x_new, dtype=np.float64)

    # 初始化输出数组
    y_new = np.zeros((rows, new_cols), dtype=np.float64)
    e_new = np.zeros((rows, new_cols), dtype=np.float64)
    print("ynew = ",y_new)
    # 调用rebin_2D
    rebin_2D(
        ctypes.c_size_t(rows),
        ctypes.c_size_t(old_cols),
        x_old,
        y_old,
        e_old,
        ctypes.c_size_t(new_cols),
        x_new,
        y_new,
        e_new
    )
    print("finsih rebin_2D")
    x = np.tile(x_new, (rows, 1))
    return x, y_new, e_new
# def rebin_2D(x_old, y_old, e_old, x_new):
#     rzlib = getRZeraLib()
#     rebin_2D = rzlib.rebin_2D
#     rebin_2D.argtypes = [
#         c_size_t,                    # rows
#         c_size_t,                    # old_cols
#         POINTER(POINTER(c_double)),  # x_old
#         POINTER(POINTER(c_double)),  # y_old
#         POINTER(POINTER(c_double)),  # e_old
#         c_size_t,                    # new_cols
#         POINTER(c_double),           # x_new
#         POINTER(POINTER(c_double)),  # y_new
#         POINTER(POINTER(c_double))   # e_new
#     ]
#
#     rows = len(y_old)
#     old_cols = len(x_old[0])
#     new_cols = len(x_new)
#     # Create the ctypes arrays for x_old, y_old, and e_old
#     x_old_ptrs = (POINTER(c_double) * rows)(*[ctypes.cast((c_double * old_cols)(*row), POINTER(c_double)) for row in x_old])
#     y_old_ptrs = (POINTER(c_double) * rows)(*[ctypes.cast((c_double * old_cols)(*row), POINTER(c_double)) for row in y_old])
#     e_old_ptrs = (POINTER(c_double) * rows)(*[ctypes.cast((c_double * old_cols)(*row), POINTER(c_double)) for row in e_old])
#
#     # Create the ctypes arrays for y_new and e_new
#     y_new_ptrs = (POINTER(c_double) * rows)()
#     e_new_ptrs = (POINTER(c_double) * rows)()
#     for i in range(rows):
#         y_new_ptrs[i] = (c_double * new_cols)()
#         e_new_ptrs[i] = (c_double * new_cols)()
#
#     x_new_array = (c_double * new_cols)(*x_new)
#     # 调用rebin_2D
#     rebin_2D(
#         c_size_t(rows),
#         c_size_t(old_cols),
#         x_old_ptrs,
#         y_old_ptrs,
#         e_old_ptrs,
#         c_size_t(new_cols),
#         x_new_array,
#         y_new_ptrs,
#         e_new_ptrs
#     )
#     # 将结果转换为numpy数组
#     y_new = np.array([np.ctypeslib.as_array(ptr, shape=(new_cols,)) for ptr in y_new_ptrs])
#     e_new = np.array([np.ctypeslib.as_array(ptr, shape=(new_cols,)) for ptr in e_new_ptrs])
#     x = np.tile(x_new,(rows,1))
#     return x, y_new, e_new

def rebin(x_old, y_old, e_old, x_new):
    rzlib = getRZeraLib()

    # 定义C++函数的参数和返回类型
    rzlib.rebin.argtypes = [
        ctypes.c_size_t,  # input_size
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # input_x
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # input_y
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # input_e
        ctypes.c_size_t,  # output_size
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # output_x
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS'),  # output_y
        np.ctypeslib.ndpointer(dtype=np.double, ndim=1, flags='C_CONTIGUOUS')  # output_e
    ]

    x_old_boundary = change_point_to_boundary(x_old)
    input_size = len(x_old_boundary)
    input_x = np.ascontiguousarray(x_old_boundary, dtype=np.float64)
    input_y = np.ascontiguousarray(y_old, dtype=np.float64)
    input_e = np.ascontiguousarray(e_old, dtype=np.float64)

    x_new_boundary = change_point_to_boundary(x_new)
    output_size = len(x_new_boundary)
    output_x = np.ascontiguousarray(x_new_boundary, dtype=np.float64)
    output_y = np.zeros(output_size - 1, dtype=np.float64)
    output_e = np.zeros(output_size - 1, dtype=np.float64)

    rzlib.rebin(
        ctypes.c_size_t(input_size),
        input_x,
        input_y,
        input_e,
        ctypes.c_size_t(output_size),
        output_x,
        output_y,
        output_e
    )

    return np.array(output_y), np.sqrt(np.array(output_e))
# def rebin(x_old,y_old,e_old,x_new):
#     x_old_boundry = change_point_to_boundry(x_old)
#     input_size = len(x_old_boundry)
#     input_x = (c_double * input_size)(*x_old_boundry)
#     input_y = (c_double * (input_size-1))(*y_old)
#     input_e = (c_double * (input_size-1))(*e_old)
#     x_new_boundry = change_point_to_boundry(x_new)
#     output_size = len(x_new_boundry)
#     output_x = (c_double * output_size)(*x_new_boundry)
#     output_y =  (c_double * (output_size-1))()
#     output_e =  (c_double * (output_size-1))()
#     rzlib = getRZeraLib()
#     rzlib.rebin(c_size_t(input_size),input_x,input_y,input_e,
#                 c_size_t(output_size),output_x,output_y,output_e)
#     #print("xnew size:",x_new.size,"output_size:",output_size,"esize:",np.array(output_e).size)
#     return np.array(output_y),np.sqrt(np.array(output_e))

def interpolate(x_old,y_old,e_old,x_new):
    check_boundaries(x_old,x_new[0])
    check_boundaries(x_old,x_new[1])
    f = interp1d(x_old, y_old, kind='linear')  # kind 参数可以是 'linear', 'cubic', 'quadratic', 等
    #x_new = np.arange(configure["q_rebin"][0],configure["q_rebin"][1],0.01)
    #print(x_new,x_new.size)
    # 使用插值函数计算新的 y 值
    y_new = f(x_new)
    y_new_err = []
    for x in x_new:
        # 找到最接近插值点的两个数据点
        idx = np.searchsorted(x_old, x) - 1
        x0, x1 = x_old[idx], x_old[idx + 1]
        y0_err, y1_err = e_old[idx], e_old[idx + 1]
        # 计算权重
        w0 = (x1 - x) / (x1 - x0)
        w1 = (x - x0) / (x1 - x0)
        # 通过权重线性组合数据点的误差来估计插值点的误差
        y_err_interp = np.sqrt((w0 * y0_err) ** 2 + (w1 * y1_err) ** 2)
        y_new_err.append(y_err_interp)

    e_new = np.array(y_new_err)
    return y_new,e_new