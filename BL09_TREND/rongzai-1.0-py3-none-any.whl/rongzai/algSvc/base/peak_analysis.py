from rongzai.utils.defined_functions import gaussian
from scipy.optimize import curve_fit
from scipy.signal import find_peaks
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve
import numpy as np
def baseline_alg(y, lam=1e5, p=0.01, niter=10):
    L = len(y)
    D = diags([1, -2, 1], [0, -1, -2], shape=(L, L-2))
    w = np.ones(L)
    for i in range(niter):
        W = diags(w, 0, shape=(L, L))
        Z = W + lam * D.dot(D.transpose())
        z = spsolve(Z, w * y)
        w = p * (y > z) + (1 - p) * (y < z)
    return z
def auto_extract_peak_data(x, y, peak_center_approx, rel_height,manual_width,search_range):
    peaks, properties = find_peaks(y, height=rel_height)
    kept_peaks = []
    for peak in peaks:
        if np.abs(x[peak] - peak_center_approx) < search_range:
            kept_peaks.append(peak)
    if len(kept_peaks) == 0:
        return False, np.array([]), np.array([])

    target_peak = kept_peaks[np.argmax(y[kept_peaks])] # find the highest peak
    left_ips = x[target_peak]-manual_width
    right_ips = x[target_peak]+manual_width
    peak_indices =  (x >= left_ips) & (x <= right_ips)
    x_peak = x[peak_indices]
    y_peak = y[peak_indices]
    return True, x_peak, y_peak


def fit_gaussian(x_peak, y_peak):
    # 初始参数估计：中心位置，标准偏差,振幅，基线
    initial_guess = [x_peak[np.argmax(y_peak)], np.std(x_peak),max(y_peak)-min(y_peak),min(y_peak)]
    try:
        popt, _ = curve_fit(gaussian, x_peak, y_peak, p0=initial_guess)
        return True, popt
    except:
        return False,None