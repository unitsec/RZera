import json
import os
def expend_conf(conf):
    data = conf.copy()
    nameList = ["sam","samBG","v","vBG"]
    for name in nameList:
        item = name + "_run"
        try:
            fnList = [os.path.join(data["data_path"], run, "detector.nxs") for run in data[item]]
        except:
            fnList = []
        data[name + "_fn"] = fnList
    return data

def generate_offset_conf(base_conf,offset_conf):
    with open(base_conf, "r") as jf:
        base_configure = json.load(jf)
    with open(offset_conf, "r") as jf:
        params_configure = json.load(jf)
    params_configure = expend_conf(params_configure)
    configure = {**params_configure, **base_configure}
    return configure

def generate_diffraction_conf(base_json,diffraction_json):
    with open(base_json, "r") as jf:
        base_configure = json.load(jf)
    with open(diffraction_json, "r") as jf:
        params_configure = json.load(jf)
        params_configure = expend_conf(params_configure)
    if not params_configure["d_rebin"]:
        configure = {**params_configure, **base_configure}
    else:
        configure = {**base_configure, **params_configure}
    return configure
def generate_pdf_conf(base_json,diffraction_json):
    with open(base_json, "r") as jf:
        base_configure = json.load(jf)
    with open(diffraction_json, "r") as jf:
        params_configure = json.load(jf)
        params_configure = expend_conf(params_configure)
    configure = {**base_configure, **params_configure}
    return configure