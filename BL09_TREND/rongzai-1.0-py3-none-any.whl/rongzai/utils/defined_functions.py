import numpy as np

def gaussian(x,center,sigma,height,base):
        #p[0]: center of peak
        #p[1]: sigma
        #p[2]: maximum of peak
        # FWHM = 2*np.sqrt(2*math.log(2))*sigma = 2.35482*sigma
    return (base+height*np.exp(-(x-center)**2.0/(2*sigma**2)))

def lorentzian(x, center, gamma,amplitude, base):
    #gamma is half width
    return base + amplitude*(gamma / np.pi) / ((x - x0)**2 + gamma**2)

def asymmetric_gaussian(x, A, x0, sigma1, sigma2):
    return np.where(x < x0,
                    A * np.exp(-0.5 * ((x - x0) / sigma1) ** 2),
                    A * np.exp(-0.5 * ((x - x0) / sigma2) ** 2))


def quadratic_func(x,C0,C1,C2):
    x = np.array(x)
    return C0 + C1 * x + C2 * (x ** 2)

def linear_func(x, C0, C1):
    x = np.array(x)
    return C0 + C1 * x