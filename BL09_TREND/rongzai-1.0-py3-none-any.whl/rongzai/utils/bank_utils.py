class BankGenerator:
    def __generate_module_list(self,bl,bank, start_k, end_k, xpixels, ypixels, stepbyrow):
        module_list = []
        pixel_dict = {}
        for k in range(start_k, end_k + 1):
            if bl[:4]=="BL15" or bl[:4]=="BL16" or bl[:4]=="BL09":
                name = f"module1{bank[-2:]}{str(k).zfill(2)}"
            else:
                name = f"module1{bank[-1].zfill(2)}{str(k).zfill(2)}"
            module_list.append(name)
            tmp = {
                "xpixels": xpixels,
                "ypixels": ypixels,
                "stepbyrow": stepbyrow,
                "start": int(name[6:] + "0001")
            }
            pixel_dict[name] = tmp
        return module_list, pixel_dict

    def __generate_module_list_BL13(self,bank, start_row, end_row, col_list, xpixels, ypixels, stepbyrow):
        module_list = []
        pixel_dict = {}
        for k in range(start_row, end_row + 1):
            if bank=="bank1" or bank=="bank6":
                if k in [5,6,7,8]:
                    for j in col_list:
                        name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                        module_list.append(name)
                        tmp = {
                            "xpixels": xpixels,
                            "ypixels": ypixels,
                            "stepbyrow": stepbyrow,
                            "start": int(name[6:] + "000")
                        }
                        pixel_dict[name] = tmp
                else:
                    j = 2
                    name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                    module_list.append(name)
                    tmp = {
                        "xpixels": xpixels,
                        "ypixels": ypixels,
                        "stepbyrow": stepbyrow,
                        "start": int(name[6:] + "000")
                        }
                    pixel_dict[name] = tmp
            elif bank=="bank3":
                if k ==3 or k==10:
                    j=2
                    name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                    module_list.append(name)
                    tmp = {
                        "xpixels": xpixels,
                        "ypixels": ypixels,
                        "stepbyrow": stepbyrow,
                        "start": int(name[6:] + "000")
                    }
                    pixel_dict[name] = tmp
                else:
                    for j in col_list:
                        name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                        module_list.append(name)
                        tmp = {
                            "xpixels": xpixels,
                            "ypixels": ypixels,
                            "stepbyrow": stepbyrow,
                            "start": int(name[6:] + "000")
                        }
                        pixel_dict[name] = tmp
            elif bank=="bank4":
                if k == 3 or k ==10:
                    j=2
                    name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                    module_list.append(name)
                    tmp = {
                        "xpixels": xpixels,
                        "ypixels": ypixels,
                        "stepbyrow": stepbyrow,
                        "start": int(name[6:] + "000")
                    }
                    pixel_dict[name] = tmp
                elif k == 4:
                    for j in range(1,3):
                        name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                        module_list.append(name)
                        tmp = {
                            "xpixels": xpixels,
                            "ypixels": ypixels,
                            "stepbyrow": stepbyrow,
                            "start": int(name[6:] + "000")
                        }
                        pixel_dict[name] = tmp
                else:
                    for j in col_list:
                        name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                        module_list.append(name)
                        tmp = {
                            "xpixels": xpixels,
                            "ypixels": ypixels,
                            "stepbyrow": stepbyrow,
                            "start": int(name[6:] + "000")
                        }
                        pixel_dict[name] = tmp
            else:
                for j in col_list:
                    name = f"module1{bank[-1]}{str(k).zfill(2)}{str(j)}"
                    module_list.append(name)
                    tmp = {
                        "xpixels": xpixels,
                        "ypixels": ypixels,
                        "stepbyrow": stepbyrow,
                        "start": int(name[6:] + "000")
                    }
                    pixel_dict[name] = tmp
        return module_list, pixel_dict

    def __generate_module_list_BL18(self,bank, start_row, end_row, start_col,end_col, xpixels, ypixels, stepbyrow):
        module_list = []
        pixel_dict = {}
        for k in range(start_row, end_row + 1):
            for j in range(start_col,end_col+1):
                name = f"module{bank[-1]}{str(k)}{str(j)}"
                module_list.append(name)
                tmp = {
                    "xpixels": xpixels,
                    "ypixels": ypixels,
                    "stepbyrow": stepbyrow,
                    "start": int(name[6:] + "0001")
                    }
                pixel_dict[name] = tmp
        return module_list, pixel_dict
    def generateBank_BL13(self):
        bank_dict = {}
        pixel_dict = {}
        bank_configs = {
            "bank1":{"rows":(5,10),"cols":[1,3]},
            "bank2": {"rows": (5, 8), "cols": [1, 2]},
            "bank3": {"rows": (3, 10), "cols": [1, 2, 3]},
            "bank4": {"rows": (3, 10), "cols": [1, 2, 3]},
            "bank5": {"rows": (5, 8), "cols": [1, 2]},
            "bank6": {"rows": (5, 11), "cols": [1, 3]}
        }
        group_dict={
            "group1":["bank1"],
            "group2": ["bank2"],
            "group3": ["bank3"],
            "group4": ["bank4"],
            "group5": ["bank5"],
            "group6": ["bank6"]
        }
        for n in range(1, 7):
            bank = f"bank{n}"
            start_row, end_row = bank_configs[bank]["rows"]
            col_list = bank_configs[bank]["cols"]
            if bank == "bank2" or bank=="bank5":
                module_list, module_pixel_dict = self.__generate_module_list_BL13(bank, start_row, end_row, col_list,192, 2, "x")
            else:
                module_list, module_pixel_dict = self.__generate_module_list_BL13(bank, start_row, end_row, col_list, 128, 2, "x")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict, bank_dict, pixel_dict

    def generateBank_BL15_small(self):
        bank_dict = {}
        pixel_dict = {}
        bank_configs = {
            "bank12": (1, 11),
            "bank15": (1, 11),
            "bank13": (1, 12),
            "bank14": (2, 13),
            "bank11": (1, 13),
            "bank16": (1, 13)
        }
        group_dict={
            "groupSA":["bank11","bank16"],
            "groupMA":["bank12","bank15"],
            "groupHA":["bank13","bank14"]
        }
        for n in range(1, 7):
            bank = f"bank1{n}"
            start_k, end_k = bank_configs[bank]
            module_list, module_pixel_dict = self.__generate_module_list("BL15",bank, start_k, end_k, 8, 180, "y")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict, bank_dict, pixel_dict

    def generateBank_BL15_big(self): #this is for whole detector
        bank_dict = {}
        pixel_dict = {}
        group_dict = {"groupMAB":["bank21","bank22","bank23",
                                 "bank24","bank25","bank26"]}
        for n in range(1, 7):
            bank = f"bank2{n}"
            start_k, end_k = 1, 7
            module_list, module_pixel_dict = self.__generate_module_list("BL15",bank, start_k, end_k, 125, 8, "x")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict,bank_dict, pixel_dict

    # def generateBank_BL15_big(self):#this is for current detector
    #     bank_dict = {}
    #     pixel_dict = {}
    #     group_dict = {"groupMA":["bank21","bank22","bank23","bank24","bank25","bank26"]}
    #     for bank in ["bank21","bank22","bank23","bank24","bank25","bank26"]:
    #         start_k, end_k = 1, 7
    #         module_list, module_pixel_dict = self.__generate_module_list("BL15",bank, start_k, end_k, 125, 8, "x")
    #         bank_dict[bank] = module_list
    #         pixel_dict.update(module_pixel_dict)
    #     return group_dict,bank_dict, pixel_dict

    def generateBank_BL05(self):
        bank_dict = {}
        pixel_dict = {}
        group_dict = {"groupSA":["bank01","bank02","bank03",
                                "bank04"]}
        bank_configs = {
            "bank01": (1, 4)
        }
        for n in range(1, 5):
            bank = f"bank{str(n).zfill(2)}"
            if bank in bank_configs:
                start_k, end_k = bank_configs[bank]
            else:
                start_k, end_k = 1,5
            if bank=="bank02":
                module_list, module_pixel_dict = self.__generate_module_list("BL05", bank, 1, 2,
                                                                             8, 300, "y")
                tmp, tmp2 = self.__generate_module_list("BL05", bank, 3, 4,
                                                                             8, 120, "y")
                module_list.extend(tmp)
                module_pixel_dict.update(tmp2)
                tmp, tmp2 = self.__generate_module_list("BL05", bank, 5, 5,
                                                        8, 300, "y")
                module_list.extend(tmp)
                module_pixel_dict.update(tmp2)
            else:
                module_list, module_pixel_dict = self.__generate_module_list("BL05", bank, start_k, end_k,
                                                                  8, 300, "y")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict, bank_dict, pixel_dict

    def generateBank_BL09(self):
        bank_dict = {}
        pixel_dict = {}
        group_dict = {"groupBS":["bank01","bank02","bank03",
                                "bank04","bank05","bank06"],
                      "groupHA":["bank07","bank14"],
                      "groupSE":["bank08","bank13"],
                      "groupMA":["bank09","bank12"],
                      "groupSA":["bank10","bank11"]}
        bank_configs = {
            "bank02": (1, 14),
            "bank05": (1, 14)
        }
        for n in range(1, 15):
            bank = f"bank{str(n).zfill(2)}"
            if bank in bank_configs:
                start_k, end_k = bank_configs[bank]
            else:
                start_k, end_k = 1,12
            if n > 6:
                module_list, module_pixel_dict = self.__generate_module_list("BL09", bank, start_k, end_k,
                                                                             150, 8, "x")
            else:
                module_list, module_pixel_dict = self.__generate_module_list("BL09", bank, start_k, end_k,
                                                                  8, 150, "y")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict, bank_dict, pixel_dict

    def generateBank_BL16(self):
        bank_dict = {}
        pixel_dict = {}
        bank_configs = {
            "bank02": (3,3),
            "bank13":(3,3),
            "bank03":(3,4),
            "bank12":(3,4),
            "bank04":(3,5),
            "bank05":(2,5),
            "bank06":(2,3),
            "bank07":(1,4),
            "bank08":(1,4),
            "bank09":(2,3),
            "bank10":(2,5),
            "bank11":(4,5)
        }
        group_dict={
            "group2":["bank02","bank13"],
            "group3": ["bank03", "bank12"],
            "group4": ["bank04", "bank11"],
            "group5": ["bank05", "bank10"],
            "group6": ["bank06", "bank09"],
            "group7": ["bank07", "bank08"],
        }
        for n in range(2, 14):
            bank = f"bank{str(n).zfill(2)}"
            start_k, end_k = bank_configs[bank]
            if bank == "bank07" or bank=="bank08":
                module_list, module_pixel_dict = self.__generate_module_list("BL16", bank, start_k, end_k,
                                                                      60, 8, "x")
            else:
                module_list, module_pixel_dict = self.__generate_module_list("BL16", bank, start_k, end_k,
                                                                  100, 8, "x")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict, bank_dict, pixel_dict

    def generateBank_BL08(self):
        bank_dict = {}
        pixel_dict = {}
        bank_configs = {
            "bank1": (1,7),
            "bank2":(1,7)
        }
        group_dict={
            "group1":["bank1"],
            "group2": ["bank2"]
                }
        for n in range(1,3):
            bank = f"bank{str(n).zfill(1)}"
            start_k, end_k = bank_configs[bank]
            module_list, module_pixel_dict = self.__generate_module_list(
                                            "BL08", bank, start_k, end_k,
                                             320, 1, "x")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict, bank_dict, pixel_dict

    def generateBank_BL18(self):
        bank_dict = {}
        pixel_dict = {}
        bank_configs = {
            "bank1": {"rows":(2,4),"cols":(1,3)},
            "bank2": {"rows":(2,4),"cols":(1,3)},
            "bank3": {"rows":(2,4),"cols":(1,3)},
            "bank4": {"rows":(2,4),"cols":(1,3)},
            "bank5": {"rows":(2,4),"cols":(1,3)},
            "bank6": {"rows":(2,4),"cols":(1,3)}
        }
        group_dict={
            "group1":["bank5","bank6"],
            "group2": ["bank3","bank4"],
            "group3": ["bank1","bank2"]
                }
        for n in range(1, 7):
            bank = f"bank{n}"
            start_row, end_row = bank_configs[bank]["rows"]
            start_col, end_col = bank_configs[bank]["cols"]
            module_list, module_pixel_dict = self.__generate_module_list_BL18(bank, start_row, end_row, start_col,end_col,111, 48, "x")
            bank_dict[bank] = module_list
            pixel_dict.update(module_pixel_dict)
        return group_dict, bank_dict, pixel_dict
    #
    # def generateBank(self, bl):
    #     if bl in self.function_map:
    #         return self.function_map[bl]()
    #     else:
    #         raise ValueError(f"No such function for: {bl}")


function_map = {
    "BL05": BankGenerator().generateBank_BL05,
    "BL09": BankGenerator().generateBank_BL09,
    "BL15_small": BankGenerator().generateBank_BL15_small,
    "BL15_big": BankGenerator().generateBank_BL15_big,
    "BL16": BankGenerator().generateBank_BL16,
    "BL13": BankGenerator().generateBank_BL13,
    "BL08": BankGenerator().generateBank_BL08,
    "BL18": BankGenerator().generateBank_BL18
}
def generateBank(bl):
    if bl in function_map:
        return function_map[bl]()
    else:
        raise ValueError(f"No such function for: {bl}")