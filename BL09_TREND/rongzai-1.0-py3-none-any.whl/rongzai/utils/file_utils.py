import os
def check_file(filepath):
    if os.path.isfile(filepath):
        return True
    else:
        return False

def check_dir(path):
    if os.path.exists(path):
        pass
    else:
        #os.mkdir(path)#create single folder
        os.makedirs(path)#create path