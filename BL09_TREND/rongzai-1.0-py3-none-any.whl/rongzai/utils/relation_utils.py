
def find_bank_from_module(module_name, bank_info):
    for bank, modules in bank_info.items():
        if module_name in modules:
            return bank
    raise Exception(f"{module_name}: name is wrong!")

def find_group_from_bank(bank_name,group_info):
    for group, banks in group_info.items():
        if bank_name in banks:
            return group
    raise Exception(f"{bank_name}: name is wrong!")

def find_modules_from_group(group_name,group_info,bank_info):
    banks = group_info[group_name]
    modules = []
    for bank in banks:
        modules.extend(bank_info[bank])
    return modules

def get_all_from_detector(detector,group_info,bank_info):
    if detector[:5] == "group":
        modules = find_modules_from_group(detector,group_info,bank_info)
        return detector,modules
    elif detector[:4] == "bank":
        group = find_group_from_bank(detector,group_info)
        # modules = find_modules_from_group(group,group_info,bank_info)
        return group, bank_info[detector]
    elif detector[:6] == "module":
        bank = find_bank_from_module(detector,bank_info)
        group = find_group_from_bank(bank,group_info)
        return group, [detector]
    else:
        raise Exception(f"{detector}: name is wrong")
def get_all_modules_from_instrument(group_info,bank_info):
    moduleList = []
    for group in group_info.keys():
        for bank in group_info[group]:
            moduleList.extend(bank_info[bank])
    return moduleList
