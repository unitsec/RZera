from rongzai.utils.constants import *
class BaseConfig:
    @classmethod
    def get_d_std(cls, group):
        return cls.D_STD.get(group, [])

    @classmethod
    def get_high_width_para(cls, group):
        return cls.HIGH_WIDTH_PARA.get(group, [])

    @classmethod
    def get_fit_para(cls, group):
        return cls.FIT_PARA.get(group, {})

    @classmethod
    def get_group_para_tof(cls, group):
        return cls.GROUP_PARA_TOF.get(group, {})

    @classmethod
    def get_group_para_d(cls, group):
        return cls.GROUP_PARA_D.get(group, {})

    @classmethod
    def get_smooth_para(cls, group):
        return cls.SMOOTH_PARA.get(group, {})

    @classmethod
    def get_d_rebin(cls, group):
        return cls.D_REBIN.get(group, [])

    @classmethod
    def get_focus_point(cls, group):
        return cls.FOCUS_POINT.get(group, {})

    @classmethod
    def get_vanadium_peaks(cls, group):
        return cls.VANADIUM_PEAKS.get(group, {})

    def get_vanadium_smooth(cls, group):
        return cls.VANADIUM_SMOOTH.get(group, {})

    @classmethod
    def get_first_flight_distance(cls):
        return cls.FIRST_FLIGHT_DISTANCE

    @classmethod
    def get_v_type(cls):
        return cls.V_TYPE

    @classmethod
    def get_instrument_name(cls):
        return cls.INSTRUMENT_NAME

    @classmethod
    def get_monitor(cls):
        return cls.MONITOR_NAME


class BL05(BaseConfig):
    V_TYPE = "V"
    FIRST_FLIGHT_DISTANCE = 18
    INSTRUMENT_NAME = "HD"
    MONITOR_NAME = "monitor01"
    D_REBIN = {
        "groupMA": [0.1, 5, 4000],
    }
    FOCUS_POINT = {"groupSA": {"factor": 3920.82,"pixel":101010001,"2_theta":43.54}}
    D_STD = {
        "groupSA": SILICON_PEAKS_MP[:10]
            }
    FIT_PARA = {
        'groupSA': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True}
    }

    HIGH_WIDTH_PARA = {
        'groupSA': [[0.05, 0.05, 0.05],[0.3, 0.05, 0.05], [0.3, 0.05, 0.05], [0.1, 0.03, 0.05], [0.1, 0.02, 0.05],
                    [0.05, 0.02, 0.05],[0.05, 0.01, 0.05],[0.05, 0.01, 0.02],[0.05, 0.01, 0.02],[0.05, 0.01, 0.02]]
    }
    SMOOTH_PARA = {'groupSA': {"is_smooth": True, "smooth_para": [50, 4]}}
    GROUP_PARA_D = {
        'groupSA': {"group_along_tube": 3, "group_cross_tube": 1}
    }
    GROUP_PARA_TOF = {
        'groupSA': {"group_along_tube": 3, "group_cross_tube": 1}
    }

    VANADIUM_SMOOTH = {
        "groupSA": {"npoint": 21, "order": 3}
    }
    VANADIUM_PEAKS = {}


class BL08(BaseConfig):
    V_TYPE = "V"
    FIRST_FLIGHT_DISTANCE = 49.5
    INSTRUMENT_NAME = "EMD"
    MONITOR_NAME = "monitor02"
    D_REBIN = {
                "group1": [0.2,4,2000],
                "group2": [0.2, 4, 2000]
                }
    FOCUS_POINT = { "group1": {"factor": 40431.87478,"pixel":102140061,"2_theta":177},
                    "group2": {"factor": 40431.87478,"pixel":102140061,"2_theta":177}}
    D_STD = {'group1': SILICON_PEAKS_MP[:8],
             'group2': SILICON_PEAKS_MP[:8]}
    HIGH_WIDTH_PARA = {'group1': [[0.4,0.008, 0.008], [0.4, 0.007, 0.008], [0.2, 0.005, 0.008], [0.2, 0.005, 0.005], [0.1, 0.005, 0.005], [0.1, 0.005, 0.005], [0.1, 0.005, 0.005], [0.1, 0.005, 0.005]],
                       'group2': [[0.4,0.008, 0.008], [0.4, 0.007, 0.008], [0.2, 0.005, 0.008], [0.2, 0.005, 0.005], [0.1, 0.005, 0.005], [0.1, 0.005, 0.005], [0.1, 0.005, 0.005], [0.1, 0.005, 0.005]]}
    SMOOTH_PARA = {'group1': {"is_smooth": True, "smooth_para": [21, 3]},
                   'group2': {"is_smooth": True, "smooth_para": [21, 3]}}

    FIT_PARA = {
        'group1': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True},
        'group2': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True}
    }
    GROUP_PARA = {
        'group1': {"group_along_tube": 1, "group_cross_tube": 1},
        'group2': {"group_along_tube": 1, "group_cross_tube": 1}
    }

    VANADIUM_SMOOTH = {
        "group1": {"npoint": 21, "order": 3},
        "group2": {"npoint": 21, "order": 3}
    }
    VANADIUM_PEAKS = {
        "group1": {"peaks": VANADIUM_PEAKS,
                   "left": 7, "right": 11},
        "group2": {"peaks": VANADIUM_PEAKS,
                   "left": 7, "right": 11}
    }

class BL09(BaseConfig):
    V_TYPE = "VNi"
    FIRST_FLIGHT_DISTANCE = 78
    INSTRUMENT_NAME = "HRD"
    MONITOR_NAME = "monitor01"
    D_REBIN = {
                "groupBS": [0.2,4,26000],
        "groupHA": [0.2, 4, 26000],
        "groupSE": [0.2, 6, 26000],
        "groupMA": [0.2, 7, 26000],
        "groupLA": [0.2, 15, 26000]
    }
    FOCUS_POINT = { "groupBS": {"factor": 40431.87478,"pixel":102140061,"2_theta":177},
                    "groupHA": {"factor": 35975.98500, "pixel": 107070076, "2_theta": 127.8},
                    "groupSE": {"factor":28327.430886 ,"pixel":108070076,"2_theta":90},
                    "groupMA": {"factor": 16466.70688,"pixel":109070076,"2_theta":48.6},
                    "groupLA": {"factor": 4366.123058,"pixel":110070076,"2_theta":12.5}}
    D_STD = {'groupBS': SILICON_PEAKS_MP[:10]}
    FIT_PARA = {
        "groupBS":{"least_peaks_num":3,"fit_function":"gaussian","order":"linear","goodness_bottom":0.95,"sub_background":True},
        "groupHA": {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                    "sub_background": True},
        "groupSE": {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                    "sub_background": True},
        "groupMA": {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                    "sub_background": True},
        "groupLA": {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                    "sub_background": True}

    }
    GROUP_PARA_D = {
        'groupBS': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupHA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupSE': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupMA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupLA': {"group_along_tube": 1, "group_cross_tube": 1}
    }
    GROUP_PARA_TOF = {
        'groupBS': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupHA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupSE': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupMA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupLA': {"group_along_tube": 1, "group_cross_tube": 1}
    }
    HIGH_WIDTH_PARA = {'groupBS': [[0.8,0.008, 0.008], [0.8, 0.007, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005]],
                       'groupHA': [[0.8,0.008, 0.008], [0.8, 0.007, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005]],
                       'groupSE': [[0.8,0.008, 0.008], [0.8, 0.007, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005]],
                       'groupMA': [[0.8,0.008, 0.008], [0.8, 0.007, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005]],
                       'groupLA': [[0.8,0.008, 0.008], [0.8, 0.007, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005], [0.8, 0.005, 0.005]]}
    SMOOTH_PARA = {'groupBS': {"is_smooth": True, "smooth_para": [50, 4]},
                   'groupHA': {"is_smooth": True, "smooth_para": [50, 4]},
                   'groupSE': {"is_smooth": True, "smooth_para": [50, 4]},
                   'groupMA': {"is_smooth": True, "smooth_para": [50, 4]},
                   'groupLA': {"is_smooth": True, "smooth_para": [50, 4]}}
    VANADIUM_SMOOTH = {
        "groupBS": {"npoint": 21, "order": 3},
        "groupHA": {"npoint": 21, "order": 3},
        "groupSE": {"npoint": 21, "order": 3},
        "groupMA": {"npoint": 21, "order": 3},
        "groupLA": {"npoint": 21, "order": 3}
    }
    VANADIUM_PEAKS = {}

class BL13(BaseConfig):
    V_TYPE ="V"
    FIRST_FLIGHT_DISTANCE = 35
    INSTRUMENT_NAME = "ERNI"
    MONITOR_NAME = "monitor01"
    D_REBIN = {
                "group6": [0.8,13,500],
                "group5": [0.4,3.8,500],
                "group4": [0.2, 2.4, 800],
                "group3": [0.2,2.4,800],
                "group2": [0.2,2,1500],
                "group1": [0.2,2.,2000]
    }
    FOCUS_POINT = {
        "group6": {"factor": 15630.28, "pixel": 107030270, "2_theta": 163},
        "group5": {"factor": 14460.68, "pixel": 106030450, "2_theta": 133},
        "group4": {"factor": 11385.43, "pixel": 105030450, "2_theta": 93},
        "group3": {"factor": 7799.17, "pixel": 104030450, "2_theta": 59},
        "group2": {"factor": 5006.04, "pixel": 103030450, "2_theta": 36},
        "group1": {"factor": 2139.82, "pixel": 102030450, "2_theta": 15}
    }
    D_STD = {
        'group6': SILICON_PEAKS_MP[:4],
        'group5': SILICON_PEAKS_MP[:6],
        'group4': SILICON_PEAKS_MP[:6],
        'group3': SILICON_PEAKS_MP[:6],
        'group2': SILICON_PEAKS_MP[:6],
        'group1': SILICON_PEAKS_MP[:6]
    }

    FIT_PARA = {
        'group6': {"least_peaks_num":2,"fit_function":"gaussian","order":"linear", "goodness_bottom":0.95,"sub_background":True},
        'group5': {"least_peaks_num":3,"fit_function":"gaussian","order":"linear", "goodness_bottom":0.95,"sub_background":True},
        'group4': {"least_peaks_num":3,"fit_function":"gaussian","order":"linear", "goodness_bottom":0.95,"sub_background":True},
        'group3': {"least_peaks_num":3,"fit_function":"gaussian","order":"linear", "goodness_bottom":0.95,"sub_background":True},
        'group2': {"least_peaks_num":3,"fit_function":"gaussian","order":"linear","goodness_bottom":0.95,"sub_background":True},
        'group1': {"least_peaks_num":3,"fit_function":"gaussian","order":"linear","goodness_bottom":0.95,"sub_background":True}
    }
    GROUP_PARA = {
        'group6':  {"group_along_tube":64,"group_cross_tube":1},
        'group5':  {"group_along_tube":64,"group_cross_tube":1},
        'group4':  {"group_along_tube":64,"group_cross_tube":1},
        'group3':  {"group_along_tube":64,"group_cross_tube":1},
        'group2':  {"group_along_tube":64,"group_cross_tube":1},
        'group1':  {"group_along_tube":64,"group_cross_tube":1}
    }
    HIGH_WIDTH_PARA = {
        'group6': [[0.5, 0.08, 0.1], [0.05, 0.08,0.1], [0.05, 0.05,0.1], [0.05, 0.05,0.08]],
        'group5': [[0.5, 0.08, 0.05], [0.05, 0.05, 0.05], [0.05, 0.02, 0.05], [0.05, 0.02, 0.05], [0.05, 0.01, 0.05], [0.05, 0.01, 0.05]],
        'group4': [[0.4, 0.01, 0.05], [0.4, 0.006, 0.05], [0.04, 0.006, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05]],
        'group3': [[0.4, 0.01, 0.05], [0.4, 0.006, 0.05], [0.04, 0.006, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05]],
        'group2': [[0.4, 0.01, 0.05], [0.4, 0.006, 0.05], [0.04, 0.006, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05]],
        'group1': [[0.4, 0.01, 0.05], [0.4, 0.006, 0.05], [0.04, 0.006, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05], [0.04, 0.005, 0.05]]
    }
    SMOOTH_PARA = {
        'group6': {"is_smooth": True, "smooth_para": [21, 3]},
        'group5': {"is_smooth": True, "smooth_para": [21, 3]},
        'group4': {"is_smooth": True, "smooth_para": [11, 3]},
        'group3': {"is_smooth": True, "smooth_para": [11, 3]},
        'group2': {"is_smooth": True, "smooth_para": [11, 3]},
        'group1': {"is_smooth": True, "smooth_para": [11, 3]}
    }

    VANADIUM_SMOOTH = {
        "group6":{"npoint": 21, "order": 3},
        "group5":{"npoint": 21, "order": 3},
        "group4": {"npoint": 21, "order": 3},
        "group3": {"npoint": 51, "order": 3},
        "group2": {"npoint": 51, "order": 3},
        "group1": {"npoint": 51, "order": 3}
    }
    VANADIUM_PEAKS = {
        "group6":{ "peaks":[2.138489],
                        "left":20,"right":20},
        "group5": { "peaks":[1.232831, 1.516578,2.138489],
                        "left":20,"right":20},
        "group4": {"peaks":[0.809731, 0.959275, 1.072195,1.236998,
                    1.514722,2.137311],
                "left":13,"right":11},
        "group3": {
                   "peaks":[0.712326, 0.754484, 0.808687,
                            0.874934, 0.955235,1.067655,
                        1.234278, 1.513321, 2.137655],
                   "left":11,"right":11},
        "group2": {"peaks":[0.617991, 0.64534, 0.713206, 0.756761,
                            0.809433, 0.87426, 0.958333, 1.070767,
                            1.235873, 1.513414,2.1385],
                     "left":9,"right":11},
        "group1": {"peaks": [0.491458, 0.553213, 0.593559, 0.618261, 0.645433,
                        0.713775, 0.7568, 0.809288, 0.874336, 0.957499,
                        1.070304, 1.235806, 1.51329,2.1396],
                    "left":7,"right":11}
    }

class BL15_small(BaseConfig):
    V_TYPE = "VNi"
    FIRST_FLIGHT_DISTANCE = 22.5
    INSTRUMENT_NAME = "HP"
    MONITOR_NAME = "monitor01"
    D_REBIN = {
        "groupSA": [0.1, 13, 6450],
        "groupMA": [0.1, 5, 4000],
        "groupHA": [0.002, 3.46, 4300]
    }
    FOCUS_POINT = {"groupSA": {"factor": 4804.2, "pixel":111070631,"2_theta":47.3},
                   "groupMA": {"factor": 8454.3,"pixel":112060631,"2_theta":89.8},
                   "groupHA": {"factor": 10901.5,"pixel":114071351,"2_theta":131}
                   }
    D_STD = {
        'groupSA': SILICON_PEAKS_MP[:8],
        "groupMA": SILICON_PEAKS_MP[:10],
        "groupHA": SILICON_PEAKS_MP[:10]
            }
    FIT_PARA = {
        'groupSA': {"least_peaks_num": 3, "fit_function": "asymmetric_gaussian", "order": "quadratic", "goodness_bottom": 0.9,
                   "sub_background": True},
        'groupMA': {"least_peaks_num": 3, "fit_function": "asymmetric_gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True},
        'groupHA': {"least_peaks_num": 3, "fit_function": "asymmetric_gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True}
    }
    GROUP_PARA_TOF = {
        'groupSA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupMA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupHA': {"group_along_tube": 1, "group_cross_tube": 1}
    }
    GROUP_PARA_D = {
        'groupSA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupMA': {"group_along_tube": 1, "group_cross_tube": 1},
        'groupHA': {"group_along_tube": 1, "group_cross_tube": 1}
    }
    HIGH_WIDTH_PARA = {
        'groupSA': [[0.2, 0.03, 0.03], [0.2, 0.03, 0.02], [0.1, 0.03, 0.02], [0.05, 0.02, 0.02],
                    [0.05, 0.02, 0.02], [0.01, 0.015, 0.01], [0.01, 0.015, 0.01], [0.01, 0.015, 0.01]],
        'groupMA': [[0.01, 0.01, 0.05],[0.03, 0.02, 0.05], [0.1, 0.015, 0.01], [0.03, 0.01, 0.02], [0.05, 0.015, 0.05],
                    [0.05, 0.01, 0.02], [0.05, 0.01, 0.01], [0.05, 0.01, 0.02], [0.05, 0.008, 0.008], [0.05, 0.008, 0.02]],
        'groupHA': [ [0.03, 0.005, 0.02],[0.03, 0.01, 0.02], [0.1, 0.01, 0.02], [0.1, 0.01, 0.02], [0.05, 0.01, 0.02],
                    [0.05, 0.01, 0.02], [0.05, 0.008, 0.008], [0.05, 0.008, 0.01], [0.05, 0.008, 0.01], [0.05, 0.006, 0.01]]
    }

    SMOOTH_PARA = {'groupSA': {"is_smooth": True, "smooth_para": [41, 8]},
                   'groupMA': {"is_smooth": True, "smooth_para": [31, 8]},
                   'groupHA': {"is_smooth": True, "smooth_para": [31, 8]}}

    VANADIUM_SMOOTH = {
        "groupSA": {"npoint": 21, "order": 3},
        "groupMA": {"npoint": 21, "order": 3},
        "groupHA": {"npoint": 51, "order": 3}
    }
    VANADIUM_PEAKS = {}

class BL15_big(BaseConfig):
    V_TYPE = "VNi"
    FIRST_FLIGHT_DISTANCE = 29
    INSTRUMENT_NAME = "HP"
    MONITOR_NAME = "monitor01"
    D_REBIN = {
        "groupMA": [0.1, 5, 4000],
    }
    FOCUS_POINT = {"groupMA": {"factor": 10903.22,"pixel":122040563,"2_theta":90}}
    D_STD = {
        "groupMA": SILICON_PEAKS_MP[:10]
            }
    FIT_PARA = {
        'groupMA': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True}
    }
    GROUP_PARA = {
        'groupMA': {"group_along_tube": 1, "group_cross_tube": 1}
    }
    HIGH_WIDTH_PARA = {
        'groupMA': [[0.05, 0.05, 0.05],[0.3, 0.05, 0.05], [0.3, 0.05, 0.05], [0.1, 0.03, 0.05], [0.1, 0.02, 0.05],
                    [0.05, 0.02, 0.05],[0.05, 0.01, 0.05],[0.05, 0.01, 0.02],[0.05, 0.01, 0.02],[0.05, 0.01, 0.02]]
    }

    SMOOTH_PARA = {'groupMA': {"is_smooth": True, "smooth_para": [51, 8]}}

    VANADIUM_SMOOTH = {
        "groupMA": {"npoint": 21, "order": 3}
    }
    VANADIUM_PEAKS = {}

class BL16(BaseConfig):
    V_TYPE ="V"
    FIRST_FLIGHT_DISTANCE = 30
    INSTRUMENT_NAME = "MPI"
    MONITOR_NAME = "monitor01"
    D_REBIN = {
                "group2": [0.4,14,2000],
                "group3": [0.23,6,3000],
                "group4": [0.12,3.95,1600],
                "group5": [0.1,2.82,1600],
                "group6": [0.08,2.3,2400],
                "group7": [0.06,2.19,2600]
    }
    FOCUS_POINT = {
        # "group7": {"factor": 15630.28, "pixel": 107030270, "2_theta": 163},
        # "group6": {"factor": 14460.68, "pixel": 106030450, "2_theta": 133},
        # "group5": {"factor": 11385.43, "pixel": 105030450, "2_theta": 93},
        # "group4": {"factor": 7799.17, "pixel": 104030450, "2_theta": 59},
        # "group3": {"factor": 5006.04, "pixel": 103030450, "2_theta": 36},
        # "group2": {"factor": 2139.82, "pixel": 102030450, "2_theta": 15}
        "group7": {"factor": 15523.1, "pixel": 107030270, "2_theta": 163},
        "group6": {"factor": 13771.5, "pixel": 106030450, "2_theta": 133},
        "group5": {"factor": 10290.5, "pixel": 105030450, "2_theta": 93},
        "group4": {"factor": 6886.58, "pixel": 104030450, "2_theta": 59},
        "group3": {"factor": 4303.66, "pixel": 103030450, "2_theta": 36},
        "group2": {"factor": 1775.3, "pixel": 102030450, "2_theta": 15}
    }
    D_STD = {
        'group2': SILICON_PEAKS_MP[:6],
        'group3': SILICON_PEAKS_MP[:6],
        'group4': SILICON_PEAKS_MP[:10],
        'group5': SILICON_PEAKS_MP[:6],
        'group6': SILICON_PEAKS_MP[:6],
        'group7': SILICON_PEAKS_MP[:6]
    }
    FIT_PARA = {
        'group2': {"least_peaks_num": 2, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.9,
                   "sub_background": True},
        'group3': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True},
        'group4': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True},
        'group5': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True},
        'group6': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True},
        'group7': {"least_peaks_num": 3, "fit_function": "gaussian", "order": "linear", "goodness_bottom": 0.95,
                   "sub_background": True}
    }
    GROUP_PARA_D = {
        'group6': {"group_along_tube": 1, "group_cross_tube": 1},
        'group5': {"group_along_tube": 1, "group_cross_tube": 1},
        'group4': {"group_along_tube": 1, "group_cross_tube": 1},
        'group3': {"group_along_tube": 1, "group_cross_tube": 1},
        'group2': {"group_along_tube": 10, "group_cross_tube": 1},
        'group7': {"group_along_tube": 1, "group_cross_tube": 1}
    }

    GROUP_PARA_TOF = {
        'group6': {"group_along_tube": 1, "group_cross_tube": 1},
        'group5': {"group_along_tube": 1, "group_cross_tube": 1},
        'group4': {"group_along_tube": 1, "group_cross_tube": 1},
        'group3': {"group_along_tube": 1, "group_cross_tube": 1},
        'group2': {"group_along_tube": 1, "group_cross_tube": 1},
        'group7': {"group_along_tube": 1, "group_cross_tube": 1}
    }
    HIGH_WIDTH_PARA = {
        'group2': [[0.3, 0.1, 0.1], [0.2, 0.05, 0.05], [0.1, 0.05, 0.05], [0.1, 0.05, 0.05],[0.05, 0.05, 0.05],[0.05, 0.05, 0.05]],
        'group3': [[0.3, 0.05, 0.05], [0.3, 0.05, 0.05], [0.3, 0.05, 0.05], [0.05, 0.05, 0.05], [0.05, 0.05, 0.05], [0.05, 0.05, 0.05]],
        'group4': [[0.3, 0.05, 0.05], [0.3, 0.05, 0.05], [0.3, 0.05, 0.05], [0.05, 0.05, 0.05], [0.05, 0.05, 0.05], [0.05, 0.05, 0.05],
                   [0.05, 0.05, 0.05],[0.05, 0.05, 0.05],[0.05, 0.05, 0.05],[0.05, 0.05, 0.05]],
        'group5': [[0.3, 0.05, 0.05], [0.3, 0.05, 0.05], [0.3, 0.03, 0.05], [0.05, 0.02, 0.05], [0.05, 0.02, 0.05], [0.05, 0.02, 0.05]],
        'group6': [[0.4, 0.05, 0.05], [0.3, 0.05, 0.05], [0.2, 0.03, 0.05], [0.04, 0.02, 0.05], [0.04, 0.02, 0.05],[0.04, 0.01, 0.05]],
        'group7': [[0.4, 0.01, 0.05], [0.3, 0.008, 0.05], [0.2, 0.008, 0.05], [0.2, 0.008, 0.05], [0.2, 0.008, 0.05],[0.2, 0.008, 0.05]]
    }
    SMOOTH_PARA = {
        'group2': {"is_smooth": True, "smooth_para": [51, 6]},
        'group3': {"is_smooth": True, "smooth_para": [51, 8]},
        'group4': {"is_smooth": True, "smooth_para": [30, 8]},
        'group5': {"is_smooth": True, "smooth_para": [51, 8]},
        'group6': {"is_smooth": True, "smooth_para": [51, 8]},
        'group7': {"is_smooth": True, "smooth_para": [40, 8]}
    }

    VANADIUM_SMOOTH = {
        "group2":{"npoint": 21, "order": 3},
        "group3":{"npoint": 21, "order": 3},
        "group4": {"npoint": 21, "order": 3},
        "group5": {"npoint": 51, "order": 3},
        "group6": {"npoint": 51, "order": 3},
        "group7": {"npoint": 51, "order": 3}
    }
    VANADIUM_PEAKS = {
        "group2":{ "peaks":[2.138489],
                        "left":20,"right":20},
        "group3": { "peaks":[1.232831, 1.516578,2.138489],
                        "left":20,"right":20},
        "group4": {"peaks":[0.809731, 0.959275, 1.072195,1.236998,
                    1.514722,2.137311],
                "left":13,"right":11},
        "group5": {
                   "peaks":[0.712326, 0.754484, 0.808687,
                            0.874934, 0.955235,1.067655,
                        1.234278, 1.513321, 2.137655],
                   "left":11,"right":11},
        "group6": {"peaks":[0.617991, 0.64534, 0.713206, 0.756761,
                            0.809433, 0.87426, 0.958333, 1.070767,
                            1.235873, 1.513414,2.1385],
                     "left":9,"right":11},
        "group7": {"peaks": [0.491458, 0.553213, 0.593559, 0.618261, 0.645433,
                        0.713775, 0.7568, 0.809288, 0.874336, 0.957499,
                        1.070304, 1.235806, 1.51329,2.1396],
                    "left":7,"right":11}
    }
