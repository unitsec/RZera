from ctypes import *
import os
import platform
import rongzai.utils.config_instrument as config
import sys

def instantiate_class_by_name(class_name):
    try:
        class_ = getattr(config, class_name)
        instance = class_()
        return instance
    except AttributeError:
        raise ValueError(f"Class {class_name} not found in module {config.__name__}")

def getRZeraLib():
    # 获取当前脚本所在的目录
    if getattr(sys, 'frozen', False):  # 当使用 PyInstaller 打包时
        # _MEIPASS 是 PyInstaller 提供的临时目录（包含所有资源）
        script_dir = sys._MEIPASS
        if platform.system() == 'Windows':
            rzlib_path = os.path.join(script_dir, "libs", "libRZ.dll")
        elif platform.system() == 'Darwin':  # macOS 的系统名称是 'Darwin'
            rzlib_path = os.path.join(script_dir, "libs", "libRZ-x86_64.dylib")
        elif platform.system() == 'Linux':
            rzlib_path = os.path.join(script_dir, "libs", "libRZ.so")
        else:
            raise OSError("Unsupported operating system")
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        if platform.system() == 'Windows':
            rzlib_path = os.path.join(script_dir, "..","libs", "libRZ.dll")
        elif platform.system() == 'Darwin':  # macOS 的系统名称是 'Darwin'
            rzlib_path = os.path.join(script_dir, "..","libs", "libRZ-x86_64.dylib")
        elif platform.system() == 'Linux':
            rzlib_path = os.path.join(script_dir, "..","libs", "libRZ.so")
        else:
            raise OSError("Unsupported operating system")

    # 加载动态库
    rzlib = CDLL(rzlib_path)

    return rzlib