import numpy as np
import math
def replace_value(arr, nan_value=0.0, inf_neg=None, inf_pos=None):
    arr = np.nan_to_num(arr,nan=nan_value)
    if inf_neg is None:
        arr[np.isneginf(arr)] = np.min(arr[np.isfinite(arr)])
    else:
        arr[np.isneginf(arr)] = inf_neg
    if inf_pos is None:
        arr[np.isposinf(arr)] = np.max(arr[np.isfinite(arr)])
    else:
        arr[np.isposinf(arr)] = inf_pos
    return arr

def mask_nan(x,y):
    mask = ~np.isnan(x) & ~np.isnan(y)  # 创建一个布尔掩码，标记非NaN值的位置
    x_filtered = x[mask]  # 应用掩码，排除NaN值
    y_filtered = y[mask]
    return x_filtered,y_filtered

# 定义一个函数来检查Y中0的分布
def check_zeros(x_data,y_data,name):
    # 获取Y数据集中0的索引位置
    zero_indices = [index for index, value in enumerate(y_data) if value <= 0]
    if not zero_indices:
        return True
    # 检查0是否集中在开头或结尾
    #print(zero_indices,x_data[zero_indices])
    if zero_indices[0] == 0:
        # 检查0是否连续出现在开头或结尾
        start_zeros = sum(1 for i in zero_indices if i == zero_indices[0] + len(zero_indices[:zero_indices.index(i)]))
    else:
        start_zeros = 0
    if zero_indices[-1] == len(y_data) - 1:
        end_zeros = sum(1 for i in zero_indices[::-1] if i == zero_indices[-1] - len(zero_indices[:zero_indices.index(i) + 1:-1]))
    else:
        end_zeros = 0
    # 如果开头或结尾的连续0数量与总0数量相同，说明0集中在一侧
    if 0 in y_data[start_zeros:-end_zeros if end_zeros > 0 else None]:
        raise RuntimeError(f"please reset scale factor for {name}")
    if start_zeros > 0:
        new_start = x_data[start_zeros]
        raise RuntimeError(f"please reset x-range start with: {new_start} for {name}")
    if end_zeros > 0:
        new_end = x_data[-(end_zeros+1)]
        raise RuntimeError(f"please reset x-range end with: {new_end} for {name}")

def change_bytes_to_float(value):
    # 如果 value 是 numpy.array 类型
    if isinstance(value, np.ndarray):
        # 如果数组里是字节类型，先解码
        if value.dtype.type is np.bytes_:
            value = value.astype(str)
        # 取数组中的第一个元素
        value = value.item(0)
    # 如果 value 是列表或元组，尝试获取第一个元素
    elif isinstance(value, (list, tuple)) and len(value) > 0:
        value = value[0]
    # 如果 value 是字节类型，将其解码为字符串
    if isinstance(value, bytes):
        value = value.decode('utf-8')
    # 将字符串转换为 float 类型
    return float(value)

def change_point_to_boundary(arr):
    # print(arr)
    if len(arr) < 2:
        raise ValueError("Array must contain at least two elements.")
    # 判断是等差数列还是等比数列
    if np.allclose(np.diff(np.log(arr)), np.diff(np.log(arr))[0]):
        # 等比数列
        ratio = arr[1] / arr[0]
        data = arr / np.sqrt(ratio)
        return np.append(data, data[-1] * ratio)
    else:
        #if np.allclose(np.diff(arr), np.diff(arr)[0]):
        # 等差数列
        step = arr[1] - arr[0]
        data = arr - 0.5 * step
        return np.append(data, data[-1] + step)
        #raise ValueError("Array is neither arithmetic nor geometric.")

def change_boundary_to_point(arr):
    step = arr[1]-arr[0]
    data = arr+0.5*step
    return data[:-1]

def check_boundaries(x, value):
    idx = np.searchsorted(x, value)
    if idx == 0 or idx == len(x) or x[idx-1] > value or x[idx] < value:
        raise ValueError(f"The value {value} is not within the bounds")
    return idx

def merge(x1, y1, e1,x2, y2,e2, start, end):
    idx1_start = check_boundaries(x1, start)
    idx1_end = check_boundaries(x1, end)
    idx2_start = check_boundaries(x2, start)
    idx2_end = check_boundaries(x2, end)

    # 计算两个数据集在指定区间内的平均值
    y1_ave = np.mean(y1[idx1_start:idx1_end])
    y2_ave = np.mean(y2[idx2_start:idx2_end])
    # 调整 y2 的比例
    factor = y1_ave / y2_ave
    #print("factor:",factor)
    y2_new = y2 * factor
    e2_new = e2 * factor
    # 合并 x 和 y
    xfinal = np.concatenate((x1[:idx1_start], x2[idx2_start:]))
    yfinal = np.concatenate((y1[:idx1_start], y2_new[idx2_start:]))
    efinal = np.concatenate((e1[:idx1_start], e2_new[idx2_start:]))
    return xfinal, yfinal, efinal

def merge_all_curves(data_pairs, start_end_pairs):
    # 假设第一组数据是起始曲线
    # data_pairs=[(x1,y1),(x2,y2),(x3,y3)]
    # start_end_pairs=[(s1,e1),(s2,e2)]
    x_merged, y_merged, e_merged = data_pairs[0]
    # 顺序合并剩余的曲线
    for i in range(1, len(data_pairs)):
        x2, y2, e2 = data_pairs[i]
        start, end = start_end_pairs[i-1]
        x_merged, y_merged, e_merged = merge(x_merged, y_merged, e_merged, x2, y2, e2,start, end)
    return x_merged, y_merged, e_merged


def generate_x(start,stop,param,mode):
    if mode == 'log_10':
        start_exp = math.log(start,10)
        stop_exp = math.log(stop,10)
        return np.logspace(start=start_exp,stop=stop_exp,num=param,base=10)
    elif mode == 'log_e':
        start_exp = math.log(start, np.e)
        stop_exp = math.log(stop, np.e)
        return np.logspace(start=start_exp, stop=stop_exp, num=param, base=np.e)
    elif mode == "uniform":
        return np.linspace(start,stop,param)
    elif mode == "deltaX_X":
        k = param+1
        num = int(np.log(stop/start)/np.log(param+1)+1)
        #k = (stop / start) ** (1 / (num - 1))
        x = np.zeros(num)
        x[0] = start
        for i in range(1, num):
            x[i] = k * x[i - 1]
        return x
    else:
        raise Exception(f"error {mode} mode for generate X")




